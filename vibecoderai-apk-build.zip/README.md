# VibeCoderAI

Offline Android AI coding assistant. A local GGUF model runs on the phone through llama.cpp (JNI, CPU). It writes web apps (HTML/CSS/JS) into a project, previews them in-app and packages them into an installable APK. No cloud inference, no paid APIs.

## Build (GitHub Actions, no PC needed)
1. Repo root contains exactly one `vibecoderai*.zip` and `.github/workflows/build.yml` (copy of `.github/workflows/build-apk.yml` from this zip).
2. Push. The workflow unzips, clones llama.cpp tag b12020, builds the WebView shell, then `:app:assembleDebug`.
3. Download the `VibeCoderAI-debug-apk` artifact.

Local: `git clone --depth 1 --branch b12020 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp`, then `gradle :webshell:assembleDebug`, copy its APK to `app/src/main/assets/webshell.apk`, then `gradle :app:assembleDebug`.

## Features
- Chat with streaming output, markdown, syntax-highlighted code blocks with Copy, multi-chat history (History button), OLED black dark mode, liquid-glass dock, agent skills (Settings), auto-linked preview, project templates, a new project per new build chat, RAM fit hints for models, undo (project versions), regenerate, copy, quick actions, preview console, autonomous agent mode (plan, build steps, headless test, self-repair), output levels (Low to Max), redesigned chat, agent team (Builder, Debugger, Reviewer, Designer with tools), optional remote OpenAI-compatible backend (Ollama, llama-server, LM Studio), grouped Settings with sub-pages, animated glass output-level picker.
- Agent file protocol: the model emits `<file path="...">` blocks; new files apply automatically, overwrites need approval. Paths are validated against the project root.
- Models tab: Hugging Face GGUF search, download with pause/resume/progress, import from storage, select, unload.
- Web preview with console-error capture and "Fix with AI".
- Build APK from a web project, on device (prebuilt WebView shell + apksig signing, install after approval).
- Terminal with approval, project manager, settings (threads, context, output tokens, sampling).
- Cupertino-style UI: light/dark adaptive, Inter typeface (SIL OFL, bundled in res/font), floating tab bar with real backdrop blur on Android 12+ (translucent fallback below), haptics and spring press animations.
- Editor: file tabs, syntax highlighting, line numbers, undo/redo, find and replace, save.
- Chat input: attach a text/code file (6000 chars max) and voice input through the phone's speech recognizer (offline only if the phone has an offline speech pack).
- Token-lean prompts: stateless, short system prompt, project snapshot limited to the context budget.

## Known limits (blockers, not hidden)
- Nothing here was compiled on Android in the authoring sandbox; the first CI run may need small fixes. The C++ was compile- and link-checked on a host against llama.cpp b12020.
- No GPU acceleration (llama.cpp Vulkan backend is not built).
- Gradle / Android-project builds on the phone are not possible; on-device APKs are web apps only, and all share package `com.vibecoder.webapp`.
- Chat history and projects use JSON/files, not Room.
- Source is not split into the spec's module layout; no multi-tab editor or undo/redo; the Tests screen still holds legacy sample tests.
- Speed: expect a few tokens/sec for 1.5B-3B Q4_K_M models on a mid-range phone.

## UI refinements v1.1
- Global: shared design tokens (`ui/theme/Tokens.kt`: 16 dp card radius, 44 dp minimum touch target, Medium-weight secondary text); brighter, higher-contrast secondary/muted label colours; app-wide press feedback in `PressIndication.kt` (spring scale + opacity dip + light haptic tick on confirmed taps); new `ActionIconButton` (44 dp target); animated tab bar (brighter inactive icons, glow + scale on the active tab, uniform icon/label alignment); fade + slight directional slide between tabs.
- Chat: header always shows the current model and context size (e.g. `qwen2.5-coder-1.5b-instruct-q4_k_m · 4096 ctx`, or `No model`); roomier input area; Builder/Think/level pills with accent fill, rim and soft glow when active; tighter template/suggestion spacing.
- Projects/Editor: folders vs files clearly distinguished (amber folder icons, item count, expand arrow); coloured language badges (KT, KTS, JS, TS, HTML, CSS, JSON, MD, XML, JAVA, PY, ...); ellipsized long names; larger 44 dp toolbar actions; new empty state with a Compose-drawn illustration plus **New File** (creates a file, folders included, inside the project) and **Open Recent** (session-wide recent files list).
- Models: pulsing status dot while a model loads; 8 dp rounded progress bars with percentage (loading progress is an estimate from file size, since llama.cpp reports none); filled primary vs outlined/tonal secondary buttons; separate Search button with more spacing; larger red delete buttons.
- Terminal: workspace path shortened to `~/vibecoder_projects/...`; empty state shows recent commands (re-run or tap to edit) or tips; quick commands stay above the keyboard (imePadding); compact run button; Go key runs the command.
- Settings: larger right-side values, 16 dp cards, app version (`VibeCoder v<versionName>`) at the bottom and in Data and diagnostics.
- Build fix: the tab bar gesture now imports `awaitEachGesture` (a package-qualified extension call does not compile).


## v1.1.1
- Dock swipe no longer lags: while sliding a finger across the dock the lens follows the finger and only the highlight changes (with a haptic tick per tab); the screen switches once when the finger lifts. Before, every tab crossed loaded a full screen under the blurred glass.

## v1.2
- Press feedback everywhere: every `clickable` now gets the Material ripple **plus** a spring press-down scale to 0.97 and a light haptic tick (`PressIndication.kt`, ripple delegated inside the indication node). Material buttons and chips (`Button`, `TextButton`, `OutlinedButton`, `FilledTonalButton`, `IconButton`, `FilterChip`) go through drop-in wrappers in `ui/components/Buttons.kt` that keep the ripple and add the same 0.97 scale (graphicsLayer only, driven by the button's `InteractionSource`) and a haptic tick. Duplicate manual haptic calls were removed so a tap buzzes once.
- Sub-screens (web preview, test runner) now fade in/out like the tabs.
- Dock: inactive tab icons/labels a step brighter; active glow unchanged; v1.1.1 drag logic untouched.
- Chat header shows a friendly model alias (`qwen2.5-coder-7b-instruct-q5_k_m` -> `Qwen 7B Coder`, see `ModelAlias.kt`); the full file name stays on the Models screen.
- Chat empty state: 12 dp between template-card rows, 10 dp between "Or try" suggestions.
- Projects: long file names are shortened in the middle with the extension kept visible (`MiddleEllipsisText.kt`, TextMeasurer + binary search, compound extensions such as `.gradle.kts`, `.d.ts`, `.min.js` kept whole).
- Editor empty state: "Create JS, HTML, CSS…" hint under **New File**.
- Models: unselected installed models sit on a slightly darker card with a faint 1 dp rim, so the selected one (blue border + check) stands out.
- Terminal: tighter Tips card (less padding and line spacing) to leave room for recent commands.
- Settings: the value on the right of each row (Memory, Agent skills, Output, Agent, Appearance, version) is its own tap target and opens a bottom sheet with quick details (memory breakdown: PSS, JVM heap, native heap, model file, device free RAM; skills list with on/off switches; a summary for the others) and a button to open the full page. Tapping the rest of the row still navigates as before.

## v1.2.1
- Liquid-glass popups: every floating menu, dropdown, sheet and dialog is now a readable dark frosted panel (~#202023 at 90–96% in dark mode, white ~86–96% in light mode) with a 1 dp specular rim (brighter on top, fading toward the bottom), a soft large shadow and 24–28 dp corners. Before, the chat menus were almost fully transparent over the chat.
- Real backdrop blur for menus on Android 12+ with blur on (`Modifier.glassPopupSurface`, `ui/components/Glass.kt`): the popup window draws a blurred, saturated copy of the main screen's existing glass layer (shared through `LocalGlassState`), shifted by the popup's on-screen position. Nothing extra is recorded per frame, nothing exists while no popup is open, and the blur only runs while the popup is drawing. Without blur (older Android, blur off, while generating or typing) the panel uses the 96% frosted tint.
- Chat menus (role, output level, "more"): 14 dp rows, 16 sp titles, 12.5 sp muted descriptions, 18 dp rounded selection with a subtle accent fill, accent text and a check.
- Motion (`ui/components/GlassPopup.kt`, graphicsLayer only): menus open with a 140 ms fade + 0.9 → 1 scale from the anchor corner on a gentle spring (no overshoot) and a 6 dp drift, and close with a 120 ms fade + scale to 0.94. Every close path (outside tap, back, item tap) plays the exit before the menu is removed. Project dropdowns use the same glass popup. Dialogs fade + scale in from 0.95 and fade + scale out through a window animation. The settings quick sheet keeps Material's slide and scrim fade, with a frosted container, a top rim and a subtle handle.

## v1.3
- Chat history is a left **push drawer** (Claude style) instead of the centered History sheet. The drawer is ~82% of the screen width (max 340 dp), full height, pure black in dark mode. The whole app (header, chat, composer, dock) slides right by the drawer width and scales to 0.98 under a 0→45% black scrim. One `Animatable` (0..1, spring damping 1 / stiffness 400, ~300 ms) drives it, applied only through `graphicsLayer` (no recomposition while it moves).
- Opening: the clock button in the Chat header, or a swipe right from the left 24 dp edge on the Chat screen (outside the dock area). On gesture navigation a 200 dp band in the middle of the left edge is excluded from the system back gesture so the swipe can reach the app (Android allows at most 200 dp). Closing: tap the scrim, drag the drawer or the pushed screen left, or press Back. Drags follow the finger and settle by fling velocity or position. Haptic tick on open. Open state survives rotation.
- Drawer content: "History" title with search (filters by title), **New chat** pill, "Recents" list (chat icon, one-line title, delete), empty state "No saved chats yet. Send a message and it shows up here." Same open / delete / new chat logic as before (`ui/screens/HistoryOverlay.kt` now holds the drawer).
- Dock lens is liquid glass: at rest a soft inset pill (~12% white, hairline rim). While a finger is down the lens lifts to ~1.32x and overflows the dock (drawn in an unclipped overlay above the glass): ~7% white fill, specular rim (45% → 10% white, 1.25 dp), top inner highlight, soft shadow. The tab under the lens magnifies up to 1.2x by overlap and turns white/bold. The lens follows the finger on a spring (damping 0.7, stiffness 700) and stretches with speed. On release it shrinks back to the resting pill at the selected tab; a tap gives a quick lift and settle (~250 ms). v1.1.1 logic unchanged (select on touch-down, screen switches once on release, one haptic tick per tab crossed).

## v1.3.1
- Claude-style **shimmer text** for live agent status (`ui/components/ShimmerText.kt`). A soft highlight band (~35% of the text width) sweeps left to right across the letters, linear, ~1.7 s sweep + 0.3 s pause; muted grey → ~95% white → grey in dark mode, dark grey → black in light mode. Drawn with an offscreen `graphicsLayer` + `BlendMode.SrcIn` gradient; the animated offset is read only in the draw phase (no per-frame recomposition). The infinite transition exists only while the line is active; inactive lines are a plain static `Text`.
- `SparkleSpinner`: 12–13 dp orange accent spinner (4 pulsing dots rotating around a centre dot), drawn on a `Canvas` with rotation read in the draw phase, shown left of live status text.
- Used in the Chat screen for: the newest progress note while the agent is working (plan / steps / "Reviewing…", "Writing file…", "Running tests…"; older notes stay static with the grey dot), the "Thinking…" header of the reasoning box while it streams, the "Reading prompt / Writing · tok/s" status under a streaming reply (replaces the circular progress indicator; not shimmering while "Thinking…" shimmers), and the live activity strip above the composer.
- Status text changes crossfade in (fade + 4 dp slide up, ~200 ms). The reading/writing line only crossfades when the phase changes, not on every token-count update.
- Reduced motion: with animator duration scale 0 (Remove animations), no shimmer, static spinner dots and no crossfade.
- versionCode 2.

## v1.4

versionName 1.4, versionCode 3.

**Approvals everywhere**
- Autonomous, fix, specialist-agent and repair flows no longer switch approval off. Overwrites, edits and deletes of existing files show an approval dialog with a line diff and the agent waits for your answer (the chat file card's Apply / Discard answers it too). Every terminal command the agent proposes shows its text and waits. Self-repair patches always need approval.
- Settings → Agent: **Auto-approve new files** (default on) and **Auto-approve safe edits** (default off; edits only, never deletes or commands). Commands you type yourself in the Terminal screen run directly.
- Stop cancels a waiting approval (nothing is applied, the card stays pending), so the flow cannot hang.

**Agent tools**: ListFiles, ReadFile, SearchFiles, EditFile (exact find/replace, fails unless the match is unique), ApplyPatch (unified diff, context checked, rejected on mismatch), WriteFile, RunCommand (TerminalManager + approval), BuildProject (BuildRunner), AnalyzeErrors (file:line:message from build / command / preview logs), RunCheck. Old names (read_file, search, list_files, run_check, file_patch, terminal_run, project_build) still work.

**Insert code**: chat code blocks have Insert next to Copy. It inserts at the cursor of the file open in the editor (or at the end) and switches to Projects; with no file open it offers to create a new file named after the language.

**Memory-safe model loading**: before loading, file size × 1.2 + an estimated KV cache + overhead is compared with free RAM. If it does not fit you get Load anyway / Use a smaller context / Cancel. Load failures and OutOfMemoryError unload cleanly with a readable message. When Android reports critical memory pressure (onTrimMemory RUNNING_CRITICAL / COMPLETE) the model is unloaded unless it is generating, and you are told.

**Room database**: chat sessions, messages and token usage live in Room (AppDatabase v1). Existing JSON chats are imported once on first launch (idempotent; the JSON files stay on disk as a backup). The history drawer reads Room through a Flow. Settings → Data and diagnostics shows token usage totals.

**Prompt cache (KV reuse)**: the llama context is kept between turns; the new prompt is compared with the tokens already in the KV cache, the divergent tail is removed (`llama_memory_seq_rm`) and only new tokens are decoded. The status line shows "cached N". The cache resets on model or context change, and falls back to a clean cache when a partial removal is not supported.

**Exact token counts** for the local model (llama_tokenize). Remote counts stay estimates and show "≈".

**GPU (Vulkan), optional**: CMake option `VIBE_VULKAN` (default OFF), Gradle property `-PvibeVulkan=true`. Settings → Output → GPU offload toggle + layers slider, enabled only when the build has a GPU backend. A failed GPU load retries on the CPU automatically and tells you.

**Background downloads**: GGUF downloads run in WorkManager as a foreground (dataSync) worker with a progress notification and HTTP Range resume. Pause keeps the partial file, Resume continues it, and downloads survive closing the app. Android 13+ asks for notification permission; if you deny it the download still runs, only the notification is hidden.

**Code layout**: `patch/` (EditFileEngine, UnifiedDiff, LineDiff), `domain/` (ChatHistory, ModelRuntime, ProjectWorkspace, PlanEdit / PlanPatch use cases), `data/db` + `data/repository` (Room), `context/` (RelevantFiles, ContextManager alias). Prompts are shorter, the most relevant files go into the prompt first, and big unrelated files are listed by name only. The output token limit is enforced in the native generation loop.

**Unit tests** (plain JUnit, no device): security path / command rules, EditFile, ApplyPatch, line diff, Zip Slip rejection, friendlyModelName, the middle-ellipsis split, AnalyzeErrors, approval rules and the approval gate, memory estimate, editor insert, relevant-file ranking. Run: `./gradlew :app:testDebugUnitTest --tests "com.example.v14.*" --tests "com.example.ExampleUnitTest"`.

### Build

- CI (`.github/workflows/build-apk.yml`, same as the repo's `main.yml`): debug APK artifact `VibeCoderAI-debug-apk`; a signed `VibeCoderAI-release-apk` when the repository secrets `KEYSTORE_BASE64`, `STORE_PASSWORD` and `KEY_PASSWORD` exist (the keystore's key alias must be `upload`); and `VibeCoderAI-vulkan-debug-apk`, built with `continue-on-error` so it never breaks the main build.
- PC: clone llama.cpp `b12020` into `app/src/main/cpp/llama.cpp`, build `:webshell:assembleDebug`, copy its APK to `app/src/main/assets/webshell.apk`, then `./gradlew :app:assembleDebug` (add `-PvibeVulkan=true -PvibeVulkanHeaders=<Vulkan-Headers checkout> -PvibeSpirvHeadersDir=<SPIRV-Headers install>/share/cmake/SPIRV-Headers` for the GPU variant).

### What still needs a PC (honest limits)
- Android / Gradle projects cannot be built on the phone: there is no JDK, Android SDK or Gradle on the device. On-device builds cover web projects (packaged into the WebView shell APK); Android projects need a PC or GitHub Actions.
- The native changes in v1.4 (prompt cache, token counting, GPU layers) compile only in CI or on a PC with the NDK. They were checked against the b12020 headers but not run on a device for this release.
- The Vulkan variant is experimental: the NDK has no `vulkan.hpp` or SPIRV-Headers (CI fetches them), and GPU speed and stability depend on the phone's driver.
