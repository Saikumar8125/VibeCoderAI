# VibeCoderAI

Offline Android AI coding assistant. A local GGUF model runs on the phone through llama.cpp (JNI, CPU). It writes web apps (HTML/CSS/JS) into a project, previews them in-app and packages them into an installable APK. No cloud inference, no paid APIs.

## Build (GitHub Actions, no PC needed)
1. Repo root contains exactly one `vibecoderai*.zip` and `.github/workflows/build.yml` (copy of `.github/workflows/build-apk.yml` from this zip).
2. Push. The workflow unzips, clones llama.cpp tag b12020, builds the WebView shell, then `:app:assembleDebug`.
3. Download the `VibeCoderAI-debug-apk` artifact.

Local: `git clone --depth 1 --branch b12020 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp`, then `gradle :webshell:assembleDebug`, copy its APK to `app/src/main/assets/webshell.apk`, then `gradle :app:assembleDebug`.

## Features
- Chat with streaming output, markdown, syntax-highlighted code blocks with Copy, multi-chat history (History button), OLED black dark mode, liquid-glass dock, agent skills (Settings), auto-linked preview, project templates, a new project per new build chat, RAM fit hints for models, undo (project versions), regenerate, copy, quick actions, preview console, autonomous agent mode (plan, build steps, headless test, self-repair), output levels (Low to Max), redesigned chat, agent team (Builder, Debugger, Reviewer, Designer with tools), optional remote OpenAI-compatible backend (Ollama, llama-server, LM Studio), grouped Settings with sub-pages, animated glass output-level picker.
- Agent file protocol: the model emits `<file path="...">` blocks; new files apply automatically, overwrites need approval. Paths are validated against the project root.
- Models tab: Hugging Face GGUF search, download with pause/resume/progress, import from storage, select, unload.
- Web preview with console-error capture and "Fix with AI".
- Build APK from a web project, on device (prebuilt WebView shell + apksig signing, install after approval).
- Terminal with approval, project manager, settings (threads, context, output tokens, sampling).
- Cupertino-style UI: light/dark adaptive, Inter typeface (SIL OFL, bundled in res/font), floating tab bar with real backdrop blur on Android 12+ (translucent fallback below), haptics and spring press animations.
- Editor: file tabs, syntax highlighting, line numbers, undo/redo, find and replace, save.
- Chat input: attach a text/code file (6000 chars max) and voice input through the phone's speech recognizer (offline only if the phone has an offline speech pack).
- Token-lean prompts: stateless, short system prompt, project snapshot limited to the context budget.

## Known limits (blockers, not hidden)
- Nothing here was compiled on Android in the authoring sandbox; the first CI run may need small fixes. The C++ was compile- and link-checked on a host against llama.cpp b12020.
- No GPU acceleration (llama.cpp Vulkan backend is not built).
- Gradle / Android-project builds on the phone are not possible; on-device APKs are web apps only, and all share package `com.vibecoder.webapp`.
- Chat history and projects use JSON/files, not Room.
- Source is not split into the spec's module layout; no multi-tab editor or undo/redo; the Tests screen still holds legacy sample tests.
- Speed: expect a few tokens/sec for 1.5B-3B Q4_K_M models on a mid-range phone.

## UI refinements v1.1
- Global: shared design tokens (`ui/theme/Tokens.kt`: 16 dp card radius, 44 dp minimum touch target, Medium-weight secondary text); brighter, higher-contrast secondary/muted label colours; app-wide press feedback in `PressIndication.kt` (spring scale + opacity dip + light haptic tick on confirmed taps); new `ActionIconButton` (44 dp target); animated tab bar (brighter inactive icons, glow + scale on the active tab, uniform icon/label alignment); fade + slight directional slide between tabs.
- Chat: header always shows the current model and context size (e.g. `qwen2.5-coder-1.5b-instruct-q4_k_m · 4096 ctx`, or `No model`); roomier input area; Builder/Think/level pills with accent fill, rim and soft glow when active; tighter template/suggestion spacing.
- Projects/Editor: folders vs files clearly distinguished (amber folder icons, item count, expand arrow); coloured language badges (KT, KTS, JS, TS, HTML, CSS, JSON, MD, XML, JAVA, PY, ...); ellipsized long names; larger 44 dp toolbar actions; new empty state with a Compose-drawn illustration plus **New File** (creates a file, folders included, inside the project) and **Open Recent** (session-wide recent files list).
- Models: pulsing status dot while a model loads; 8 dp rounded progress bars with percentage (loading progress is an estimate from file size, since llama.cpp reports none); filled primary vs outlined/tonal secondary buttons; separate Search button with more spacing; larger red delete buttons.
- Terminal: workspace path shortened to `~/vibecoder_projects/...`; empty state shows recent commands (re-run or tap to edit) or tips; quick commands stay above the keyboard (imePadding); compact run button; Go key runs the command.
- Settings: larger right-side values, 16 dp cards, app version (`VibeCoder v<versionName>`) at the bottom and in Data and diagnostics.
- Build fix: the tab bar gesture now imports `awaitEachGesture` (a package-qualified extension call does not compile).
