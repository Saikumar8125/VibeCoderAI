# VibeCoderAI

Offline Android AI coding assistant. A local GGUF model runs on the phone through llama.cpp (JNI, CPU). It writes web apps (HTML/CSS/JS) into a project, previews them in-app and packages them into an installable APK. No cloud inference, no paid APIs.

## Build (GitHub Actions, no PC needed)
1. Repo root contains exactly one `vibecoderai*.zip` and `.github/workflows/build.yml` (copy of `.github/workflows/build-apk.yml` from this zip).
2. Push. The workflow unzips, clones llama.cpp tag b12020, builds the WebView shell, then `:app:assembleDebug`.
3. Download the `VibeCoderAI-debug-apk` artifact.

Local: `git clone --depth 1 --branch b12020 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp`, then `gradle :webshell:assembleDebug`, copy its APK to `app/src/main/assets/webshell.apk`, then `gradle :app:assembleDebug`.

## Features
- Chat with streaming output, markdown, syntax-highlighted code blocks with Copy, multi-chat history (History button), OLED black dark mode, liquid-glass dock.
- Agent file protocol: the model emits `<file path="...">` blocks; new files apply automatically, overwrites need approval. Paths are validated against the project root.
- Models tab: Hugging Face GGUF search, download with pause/resume/progress, import from storage, select, unload.
- Web preview with console-error capture and "Fix with AI".
- Build APK from a web project, on device (prebuilt WebView shell + apksig signing, install after approval).
- Terminal with approval, project manager, settings (threads, context, output tokens, sampling).
- Cupertino-style UI: light/dark adaptive, Inter typeface (SIL OFL, bundled in res/font), floating tab bar with real backdrop blur on Android 12+ (translucent fallback below), haptics and spring press animations.
- Editor: file tabs, syntax highlighting, line numbers, undo/redo, find and replace, save.
- Chat input: attach a text/code file (6000 chars max) and voice input through the phone's speech recognizer (offline only if the phone has an offline speech pack).
- Token-lean prompts: stateless, short system prompt, project snapshot limited to the context budget.

## Known limits (blockers, not hidden)
- Nothing here was compiled on Android in the authoring sandbox; the first CI run may need small fixes. The C++ was compile- and link-checked on a host against llama.cpp b12020.
- No GPU acceleration (llama.cpp Vulkan backend is not built).
- Gradle / Android-project builds on the phone are not possible; on-device APKs are web apps only, and all share package `com.vibecoder.webapp`.
- Chat history and projects use JSON/files, not Room.
- Source is not split into the spec's module layout; no multi-tab editor or undo/redo; the Tests screen still holds legacy sample tests.
- Speed: expect a few tokens/sec for 1.5B-3B Q4_K_M models on a mid-range phone.
