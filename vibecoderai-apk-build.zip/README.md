# VibeCoderAI

Offline Android AI coding assistant. A local GGUF model runs on the phone through llama.cpp (JNI, CPU). It writes web apps (HTML/CSS/JS) into a project, previews them in-app and packages them into an installable APK. No cloud inference, no paid APIs.

## Build (GitHub Actions, no PC needed)
1. Repo root contains exactly one `vibecoderai*.zip` and `.github/workflows/build.yml` (copy of `.github/workflows/build-apk.yml` from this zip).
2. Push. The workflow unzips, clones llama.cpp tag b12020, builds the WebView shell, then `:app:assembleDebug`.
3. Download the `VibeCoderAI-debug-apk` artifact.

Local: `git clone --depth 1 --branch b12020 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp`, then `gradle :webshell:assembleDebug`, copy its APK to `app/src/main/assets/webshell.apk`, then `gradle :app:assembleDebug`.

## Features
- Chat with streaming output, markdown, syntax-highlighted code blocks with Copy, multi-chat history (History button), OLED black dark mode, liquid-glass dock, agent skills (Settings), auto-linked preview, project templates, a new project per new build chat, RAM fit hints for models, undo (project versions), regenerate, copy, quick actions, preview console, autonomous agent mode (plan, build steps, headless test, self-repair), output levels (Low to Max), redesigned chat, agent team (Builder, Debugger, Reviewer, Designer with tools), optional remote OpenAI-compatible backend (Ollama, llama-server, LM Studio), grouped Settings with sub-pages, animated glass output-level picker.
- Agent file protocol: the model emits `<file path="...">` blocks; new files apply automatically, overwrites need approval. Paths are validated against the project root.
- Models tab: Hugging Face GGUF search, download with pause/resume/progress, import from storage, select, unload.
- Web preview with console-error capture and "Fix with AI".
- Build APK from a web project, on device (prebuilt WebView shell + apksig signing, install after approval).
- Terminal with approval, project manager, settings (threads, context, output tokens, sampling).
- Cupertino-style UI: light/dark adaptive, Inter typeface (SIL OFL, bundled in res/font), floating tab bar with real backdrop blur on Android 12+ (translucent fallback below), haptics and spring press animations.
- Editor: file tabs, syntax highlighting, line numbers, undo/redo, find and replace, save.
- Chat input: attach a text/code file (6000 chars max) and voice input through the phone's speech recognizer (offline only if the phone has an offline speech pack).
- Token-lean prompts: stateless, short system prompt, project snapshot limited to the context budget.

## Known limits (blockers, not hidden)
- Nothing here was compiled on Android in the authoring sandbox; the first CI run may need small fixes. The C++ was compile- and link-checked on a host against llama.cpp b12020.
- No GPU acceleration (llama.cpp Vulkan backend is not built).
- Gradle / Android-project builds on the phone are not possible; on-device APKs are web apps only, and all share package `com.vibecoder.webapp`.
- Chat history and projects use JSON/files, not Room.
- Source is not split into the spec's module layout; no multi-tab editor or undo/redo; the Tests screen still holds legacy sample tests.
- Speed: expect a few tokens/sec for 1.5B-3B Q4_K_M models on a mid-range phone.

## UI refinements v1.1
- Global: shared design tokens (`ui/theme/Tokens.kt`: 16 dp card radius, 44 dp minimum touch target, Medium-weight secondary text); brighter, higher-contrast secondary/muted label colours; app-wide press feedback in `PressIndication.kt` (spring scale + opacity dip + light haptic tick on confirmed taps); new `ActionIconButton` (44 dp target); animated tab bar (brighter inactive icons, glow + scale on the active tab, uniform icon/label alignment); fade + slight directional slide between tabs.
- Chat: header always shows the current model and context size (e.g. `qwen2.5-coder-1.5b-instruct-q4_k_m · 4096 ctx`, or `No model`); roomier input area; Builder/Think/level pills with accent fill, rim and soft glow when active; tighter template/suggestion spacing.
- Projects/Editor: folders vs files clearly distinguished (amber folder icons, item count, expand arrow); coloured language badges (KT, KTS, JS, TS, HTML, CSS, JSON, MD, XML, JAVA, PY, ...); ellipsized long names; larger 44 dp toolbar actions; new empty state with a Compose-drawn illustration plus **New File** (creates a file, folders included, inside the project) and **Open Recent** (session-wide recent files list).
- Models: pulsing status dot while a model loads; 8 dp rounded progress bars with percentage (loading progress is an estimate from file size, since llama.cpp reports none); filled primary vs outlined/tonal secondary buttons; separate Search button with more spacing; larger red delete buttons.
- Terminal: workspace path shortened to `~/vibecoder_projects/...`; empty state shows recent commands (re-run or tap to edit) or tips; quick commands stay above the keyboard (imePadding); compact run button; Go key runs the command.
- Settings: larger right-side values, 16 dp cards, app version (`VibeCoder v<versionName>`) at the bottom and in Data and diagnostics.
- Build fix: the tab bar gesture now imports `awaitEachGesture` (a package-qualified extension call does not compile).


## v1.1.1
- Dock swipe no longer lags: while sliding a finger across the dock the lens follows the finger and only the highlight changes (with a haptic tick per tab); the screen switches once when the finger lifts. Before, every tab crossed loaded a full screen under the blurred glass.

## v1.2
- Press feedback everywhere: every `clickable` now gets the Material ripple **plus** a spring press-down scale to 0.97 and a light haptic tick (`PressIndication.kt`, ripple delegated inside the indication node). Material buttons and chips (`Button`, `TextButton`, `OutlinedButton`, `FilledTonalButton`, `IconButton`, `FilterChip`) go through drop-in wrappers in `ui/components/Buttons.kt` that keep the ripple and add the same 0.97 scale (graphicsLayer only, driven by the button's `InteractionSource`) and a haptic tick. Duplicate manual haptic calls were removed so a tap buzzes once.
- Sub-screens (web preview, test runner) now fade in/out like the tabs.
- Dock: inactive tab icons/labels a step brighter; active glow unchanged; v1.1.1 drag logic untouched.
- Chat header shows a friendly model alias (`qwen2.5-coder-7b-instruct-q5_k_m` -> `Qwen 7B Coder`, see `ModelAlias.kt`); the full file name stays on the Models screen.
- Chat empty state: 12 dp between template-card rows, 10 dp between "Or try" suggestions.
- Projects: long file names are shortened in the middle with the extension kept visible (`MiddleEllipsisText.kt`, TextMeasurer + binary search, compound extensions such as `.gradle.kts`, `.d.ts`, `.min.js` kept whole).
- Editor empty state: "Create JS, HTML, CSS…" hint under **New File**.
- Models: unselected installed models sit on a slightly darker card with a faint 1 dp rim, so the selected one (blue border + check) stands out.
- Terminal: tighter Tips card (less padding and line spacing) to leave room for recent commands.
- Settings: the value on the right of each row (Memory, Agent skills, Output, Agent, Appearance, version) is its own tap target and opens a bottom sheet with quick details (memory breakdown: PSS, JVM heap, native heap, model file, device free RAM; skills list with on/off switches; a summary for the others) and a button to open the full page. Tapping the rest of the row still navigates as before.

## v1.2.1
- Liquid-glass popups: every floating menu, dropdown, sheet and dialog is now a readable dark frosted panel (~#202023 at 90–96% in dark mode, white ~86–96% in light mode) with a 1 dp specular rim (brighter on top, fading toward the bottom), a soft large shadow and 24–28 dp corners. Before, the chat menus were almost fully transparent over the chat.
- Real backdrop blur for menus on Android 12+ with blur on (`Modifier.glassPopupSurface`, `ui/components/Glass.kt`): the popup window draws a blurred, saturated copy of the main screen's existing glass layer (shared through `LocalGlassState`), shifted by the popup's on-screen position. Nothing extra is recorded per frame, nothing exists while no popup is open, and the blur only runs while the popup is drawing. Without blur (older Android, blur off, while generating or typing) the panel uses the 96% frosted tint.
- Chat menus (role, output level, "more"): 14 dp rows, 16 sp titles, 12.5 sp muted descriptions, 18 dp rounded selection with a subtle accent fill, accent text and a check.
- Motion (`ui/components/GlassPopup.kt`, graphicsLayer only): menus open with a 140 ms fade + 0.9 → 1 scale from the anchor corner on a gentle spring (no overshoot) and a 6 dp drift, and close with a 120 ms fade + scale to 0.94. Every close path (outside tap, back, item tap) plays the exit before the menu is removed. Project dropdowns use the same glass popup. Dialogs fade + scale in from 0.95 and fade + scale out through a window animation. The settings quick sheet keeps Material's slide and scrim fade, with a frosted container, a top rim and a subtle handle.
