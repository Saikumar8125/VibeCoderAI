package com.example

import com.example.agent.ContextManager
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.llama.GgufReader
import com.example.security.SecurityManager
import com.example.security.ValidationResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ExampleUnitTest {

  @Test
  fun testSecurityManagerPathTraversalBlock() {
    val securityManager = SecurityManager()
    val projectRoot = File("/data/user/0/com.aistudio.vibecoder.nxqksp/files/vibecoder_projects/Demo")
    val unsafeEscapedFile = File(projectRoot, "../../system/build.prop")
    val safeFile = File(projectRoot, "src/main/MainActivity.kt")

    assertFalse("SecurityManager must block path traversal escapes", securityManager.isPathSafe(unsafeEscapedFile, projectRoot))
    assertTrue("SecurityManager must allow paths within project workspace", securityManager.isPathSafe(safeFile, projectRoot))
  }

  @Test
  fun testSecurityManagerCommandValidation() {
    val securityManager = SecurityManager()
    val dangerousCmd = "rm -rf /"
    val safeCmd = "ls -la"
    val systemEscapeCmd = "cat /etc/passwd"

    val dangerousResult = securityManager.validateCommand(dangerousCmd)
    assertTrue("Dangerous command must be blocked", dangerousResult is ValidationResult.Blocked)

    val systemEscapeResult = securityManager.validateCommand(systemEscapeCmd)
    assertTrue("System directory access must be blocked", systemEscapeResult is ValidationResult.Blocked)

    val safeResult = securityManager.validateCommand(safeCmd)
    assertTrue("Safe command must be approved", safeResult is ValidationResult.Approved)
  }

  @Test
  fun testDiffGeneratorCalculatesLineChanges() {
    val original = "val counter = 0"
    val replacement = "var counter by remember { mutableStateOf(0) }"

    val diffs = PatchProposal.generateDiff(original, replacement)
    assertEquals("Should generate 2 diff lines (1 removed, 1 added)", 2, diffs.size)
    assertEquals(original, diffs[0].content)
    assertEquals(replacement, diffs[1].content)
  }

  @Test
  fun testBuildRunnerParsesKotlinCompilationErrors() {
    val buildRunner = BuildRunner()
    val rawLog = "e: /app/src/main/MainActivity.kt:32:15: Unresolved reference: brokenVar"

    val parsed = buildRunner.parseCompilationLogs(rawLog)
    assertEquals(1, parsed.size)
    val err = parsed[0]
    assertEquals(32, err.lineNumber)
    assertEquals(15, err.columnNumber)
    assertTrue(err.errorMessage.contains("Unresolved reference"))
  }

  @Test
  fun testContextManagerSlidingWindowAndHashing() {
    val contextManager = ContextManager()
    val tempFile = File.createTempFile("test_code", ".kt")
    try {
      tempFile.writeText("fun test() { println(\"Hash verification\") }")
      val hash1 = contextManager.computeFileSha256(tempFile)
      assertTrue("SHA-256 hash must not be empty", hash1.isNotEmpty())

      val content = contextManager.getFileContentCached(tempFile)
      assertTrue("Cached content must match", content.contains("Hash verification"))
      assertTrue("File should be unchanged", contextManager.isFileUnchanged(tempFile))

      val longContext = (1..50).joinToString("\n") { "line $it: val v$it = $it" }
      val trimmed = contextManager.applySlidingWindow(longContext, maxTokens = 40)
      assertTrue("Sliding window must trim older lines", trimmed.contains("trimmed for token efficiency") || trimmed.lines().size < 50)
    } finally {
      tempFile.delete()
    }
  }

  @Test
  fun testGgufReaderBinaryContainerParsing() {
    val reader = GgufReader()
    val tempFile = File.createTempFile("test_container", ".gguf")
    try {
      reader.writeValidGgufFile(tempFile, version = 3, tensorCount = 150, kvCount = 20)
      val header = reader.readHeader(tempFile)
      assertTrue("GGUF header should be valid", header.isValid)
      assertEquals("GGUF", header.magic)
      assertEquals(3, header.version)
      assertEquals(150L, header.tensorCount)
    } finally {
      tempFile.delete()
    }
  }

  @Test
  fun testSelfRepairEngineVerifiedWorkflow() = runBlocking {
    val engine = SelfRepairEngine()
    val tempDir = File.createTempFile("test_repair_proj", "").apply { delete(); mkdirs() }
    try {
      val project = Project("test", "TestApp", tempDir.absolutePath, "Test", ProjectType.ANDROID_COMPOSE)
      val recordedSteps = mutableListOf<Int>()
      val result = engine.executeRepairCycle(project, maxRetries = 2, autoApprove = true) { state ->
        recordedSteps.add(state.currentStep)
      }
      assertTrue("Self-repair engine must progress through workflow", recordedSteps.isNotEmpty())
      assertTrue("Final state must be produced", result.currentStep in 1..10)
    } finally {
      tempDir.deleteRecursively()
    }
  }
}
