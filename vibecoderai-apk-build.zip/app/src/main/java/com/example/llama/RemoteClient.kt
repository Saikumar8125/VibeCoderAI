package com.example.llama

import com.example.data.model.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Talks to any OpenAI-compatible server: Ollama (:11434/v1), llama-server (:8080/v1), LM Studio (:1234/v1), a PC on the same Wi-Fi. */
object RemoteClient {
  private fun base(url: String) = url.trim().trimEnd('/')

  private fun open(url: String, key: String, method: String): HttpURLConnection =
    (URL(url).openConnection() as HttpURLConnection).apply {
      requestMethod = method
      connectTimeout = 10_000
      readTimeout = 180_000
      setRequestProperty("Content-Type", "application/json")
      if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer ${key.trim()}")
    }

  private fun errorText(c: HttpURLConnection): String =
    runCatching { c.errorStream?.bufferedReader()?.readText()?.take(300) }.getOrNull().orEmpty()

  /** Model ids the server offers. */
  fun models(url: String, key: String): List<String> {
    val c = open(base(url) + "/models", key, "GET")
    try {
      if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} ${errorText(c)}")
      val data = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("data") ?: JSONArray()
      return (0 until data.length()).map { data.getJSONObject(it).optString("id") }.filter { it.isNotBlank() }
    } finally {
      c.disconnect()
    }
  }

  /** Human-readable connection test. */
  fun test(url: String, key: String): String = try {
    val m = models(url, key)
    if (m.isEmpty()) "Connected, but the server lists no models." else "Connected. Models: " + m.take(6).joinToString(", ")
  } catch (e: Exception) {
    "Could not connect: ${e.message ?: e.javaClass.simpleName}"
  }

  /**
   * Streams the reply. [onPiece] returns false to stop. Blocking: call from an IO dispatcher.
   */
  fun stream(settings: SettingsState, messages: List<Pair<String, String>>, maxTokens: Int, onPiece: (String) -> Boolean) {
    val model = settings.remoteModel.ifBlank { models(settings.remoteUrl, settings.remoteKey).let { all -> all.firstOrNull { !Regex("whisper|tts|embed|guard|moderation|dall-e|playai|orpheus|transcribe|speech|image|rerank", RegexOption.IGNORE_CASE).containsMatchIn(it) } ?: all.firstOrNull() } ?: throw IOException("No model on the server") }
    val body = JSONObject()
      .put("model", model)
      .put("stream", true)
      .put("temperature", settings.temperature.toDouble())
      .put("top_p", settings.topP.toDouble())
      .put("max_tokens", maxTokens)
      .put("messages", JSONArray().apply {
        messages.forEach { (role, content) -> put(JSONObject().put("role", role).put("content", content)) }
      })
    val c = open(base(settings.remoteUrl) + "/chat/completions", settings.remoteKey, "POST")
    try {
      c.doOutput = true
      c.outputStream.use { it.write(body.toString().toByteArray()) }
      if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} ${errorText(c)}")
      BufferedReader(InputStreamReader(c.inputStream)).use { r ->
        while (true) {
          val line = r.readLine() ?: break
          if (!line.startsWith("data:")) continue
          val payload = line.removePrefix("data:").trim()
          if (payload == "[DONE]") break
          val piece = runCatching {
            JSONObject(payload).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content", "")
          }.getOrNull().orEmpty()
          if (piece.isNotEmpty() && !onPiece(piece)) break
        }
      }
    } finally {
      c.disconnect()
    }
  }
}
