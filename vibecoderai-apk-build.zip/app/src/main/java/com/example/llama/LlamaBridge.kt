package com.example.llama

import java.io.File

/**
 * JNI bridge to llama.cpp (libllama-android.so). Fully offline CPU inference.
 *
 * Only one model is loaded at a time. All blocking calls (load, generate) must be made off the main thread.
 */
class LlamaBridge private constructor() {

  /** Receives native events. Return false from either method to stop generation. */
  interface TokenCallback {
    /** Generated text as UTF-8 bytes. */
    fun onPiece(bytes: ByteArray): Boolean

    /** Prompt processing progress (tokens read so far / total prompt tokens). */
    fun onProgress(done: Int, total: Int): Boolean
  }

  companion object {
    private const val TAG = "VibeCoderLlamaBridge"

    @Volatile
    private var loaded = false
    @Volatile
    private var loadError: String? = null

    val isNativeLoaded: Boolean get() = loaded
    val nativeLoadError: String? get() = loadError

    fun safeLog(msg: String, t: Throwable? = null) {
      try {
        android.util.Log.i(TAG, msg, t)
      } catch (_: Throwable) {
        println("[$TAG] $msg")
      }
    }

    init {
      try {
        System.loadLibrary("llama-android")
        loaded = true
        safeLog("libllama-android.so loaded.")
      } catch (t: Throwable) {
        loaded = false
        loadError = t.message ?: t.javaClass.simpleName
        safeLog("libllama-android.so could not be loaded: $loadError", t)
      }
    }

    val instance: LlamaBridge by lazy { LlamaBridge() }
  }

  // ---- JNI ----
  private external fun nativeLoad(modelPath: String, threads: Int, ctxLength: Int): Long
  private external fun nativeFree(handle: Long)
  private external fun nativeStop(handle: Long)
  private external fun nativeLastError(): String
  private external fun nativeSetThreads(handle: Long, threads: Int)
  private external fun nativeTokenize(handle: Long, text: String): IntArray
  private external fun nativeApplyChatTemplate(handle: Long, roles: Array<String>, contents: Array<String>): String?
  private external fun nativeInfo(handle: Long): String
  private external fun nativeBench(handle: Long): String
  private external fun nativeGenerate(
    handle: Long,
    prompt: String,
    maxTokens: Int,
    temp: Float,
    topP: Float,
    topK: Int,
    repeatPenalty: Float,
    callback: TokenCallback
  ): Int

  @Volatile
  private var handle: Long = 0L

  /** Human readable reason for the last failure (load error, missing file, ...). */
  @Volatile
  var lastError: String? = null
    private set

  val isModelLoaded: Boolean get() = handle != 0L

  @Synchronized
  fun initModel(modelPath: String, threads: Int = 4, ctxLength: Int = 2048): Boolean {
    freeModel()
    lastError = null
    if (!loaded) {
      lastError = "Native library not loaded: ${loadError ?: "unknown error"}"
      return false
    }
    val file = File(modelPath)
    if (!file.isFile || file.length() == 0L) {
      lastError = "Model file not found: $modelPath"
      return false
    }
    return try {
      handle = nativeLoad(modelPath, threads, ctxLength)
      if (handle == 0L) lastError = nativeLastError()
      handle != 0L
    } catch (t: Throwable) {
      lastError = "Native load crashed: ${t.message}"
      safeLog("nativeLoad failed", t)
      false
    }
  }

  /** Aborts a running generation (safe to call from any thread). */
  fun stop() {
    val h = handle
    if (loaded && h != 0L) runCatching { nativeStop(h) }
  }

  @Synchronized
  fun freeModel() {
    val h = handle
    if (loaded && h != 0L) {
      handle = 0L
      runCatching { nativeStop(h) }
      runCatching { nativeFree(h) }
    }
  }

  fun setCpuThreads(threads: Int) {
    val h = handle
    if (loaded && h != 0L) runCatching { nativeSetThreads(h, threads) }
  }

  /** Exact token count with a loaded model, otherwise a cheap estimate (~4 chars per token). */
  fun tokenize(text: String): IntArray {
    val h = handle
    if (loaded && h != 0L) {
      val ids = runCatching { nativeTokenize(h, text) }.getOrNull()
      if (ids != null) return ids
    }
    return IntArray(estimateTokens(text))
  }

  fun applyChatTemplate(messages: List<Pair<String, String>>): String? {
    val h = handle
    if (!loaded || h == 0L) return null
    return runCatching {
      nativeApplyChatTemplate(
        h,
        messages.map { it.first }.toTypedArray(),
        messages.map { it.second }.toTypedArray()
      )
    }.getOrNull()
  }

  /**
   * Blocking text generation. Streams UTF-8 decoded pieces to [onPiece]; return false from it to stop.
   * Returns the number of generated tokens, or -1 on failure (see [lastError]).
   */
  fun generate(
    prompt: String,
    maxTokens: Int,
    temperature: Float,
    topP: Float,
    topK: Int,
    repeatPenalty: Float,
    onProgress: (done: Int, total: Int) -> Boolean = { _, _ -> true },
    onPiece: (String) -> Boolean
  ): Int {
    val h = handle
    if (!loaded || h == 0L) {
      lastError = "No model loaded."
      return -1
    }
    lastError = null
    val pieceSink = onPiece
    val progressSink = onProgress
    val callback = object : TokenCallback {
      override fun onPiece(bytes: ByteArray): Boolean = pieceSink(String(bytes, Charsets.UTF_8))
      override fun onProgress(done: Int, total: Int): Boolean = progressSink(done, total)
    }
    val n = try {
      nativeGenerate(h, prompt, maxTokens, temperature, topP, topK, repeatPenalty, callback)
    } catch (t: Throwable) {
      lastError = "Generation crashed: ${t.message}"
      safeLog("nativeGenerate failed", t)
      -1
    }
    if (n < 0 && lastError == null) lastError = runCatching { nativeLastError() }.getOrNull()
    return n
  }

  /** Decodes 16 tokens and reports speed plus CPU features. Blocking: call off the main thread. */
  fun benchmark(): String {
    val h = handle
    if (!loaded || h == 0L) return "No model loaded."
    return runCatching { nativeBench(h) }.getOrElse { "Benchmark failed: ${it.message}" }
  }

  fun getModelInfo(): String {
    val h = handle
    if (loaded && h != 0L) {
      return runCatching { nativeInfo(h) }.getOrDefault("{}")
    }
    return "{\"loaded\":false,\"native\":$loaded}"
  }

  private fun estimateTokens(text: String): Int = (text.length / 4).coerceAtLeast(if (text.isEmpty()) 0 else 1)
}
