package com.example.llama

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.max

/**
 * High-level offline inference engine on top of llama.cpp.
 * Loads a GGUF model, applies the model's chat template and streams real generated tokens.
 */
class LlamaEngine(private val context: Context) : com.example.domain.ModelRuntime {

  private val bridge = LlamaBridge.instance

  private var loadedKey: String? = null

  /** Why the model is not usable right now (null when ready). */
  @Volatile
  override var statusMessage: String? = "No model loaded"
    private set

  override val isReady: Boolean get() = bridge.isModelLoaded

  fun modelsDir(): File = File(context.filesDir, "models").also { if (!it.exists()) it.mkdirs() }

  /** Resolves which .gguf file the current settings point at (may not exist). */
  fun resolveModelFile(settings: SettingsState): File {
    settings.customModelPath?.let { return File(it) }
    val preset = SettingsState.AVAILABLE_MODELS.firstOrNull { it.id == settings.activeModelId }
    return File(modelsDir(), preset?.fileName ?: "${settings.activeModelId}.gguf")
  }

  /**
   * Loads (or reloads) the model when the file / context length changed. Cheap no-op otherwise.
   * Blocking: call from a background thread.
   */
  /** v1.4: GPU fallback / memory notes for the UI (e.g. "GPU load failed, running on CPU"). */
  @Volatile
  var notice: String? = null
    private set

  /** v1.4: set when the last load was refused by the memory check (UI offers Load anyway / smaller context). */
  @Volatile
  var lastMemoryVerdict: MemoryEstimator.Verdict? = null
    private set

  /** Model+context the user chose to load despite the memory warning. */
  @Volatile
  private var memoryOverrideKey: String? = null

  /** True when the loaded model actually runs layers on the GPU. */
  @Volatile
  var gpuActive: Boolean = false
    private set

  private fun gpuLayersFor(settings: SettingsState): Int =
    if (settings.gpuOffload && bridge.hasGpu()) settings.gpuLayers.coerceIn(1, 999) else 0

  private fun keyFor(file: File, settings: SettingsState): String =
    "${file.absolutePath}|${file.length()}|${settings.contextLength}|${gpuLayersFor(settings)}"

  private fun memKey(file: File, settings: SettingsState): String = "${file.absolutePath}|${file.length()}|${settings.contextLength}"

  /** Free RAM as Android reports it (ActivityManager.MemoryInfo.availMem); 0 when unknown. */
  fun availableMemoryBytes(): Long {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0L
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return mi.availMem
  }

  /** v1.4: memory verdict for the model the settings point at (null when there is nothing to check). */
  fun memoryCheck(settings: SettingsState): MemoryEstimator.Verdict? {
    if (settings.backendMode == "remote") return null
    val file = resolveModelFile(settings)
    if (!file.isFile) return null
    if (bridge.isModelLoaded && keyFor(file, settings) == loadedKey) return null
    return MemoryEstimator.check(file.length(), settings.contextLength, availableMemoryBytes())
  }

  /** "Load anyway": the next [initialize] for this model and context skips the memory check. */
  fun allowLowMemoryLoad(settings: SettingsState) {
    memoryOverrideKey = memKey(resolveModelFile(settings), settings)
  }

  /**
   * Loads (or reloads) the model when the file / context length / GPU layers changed. Cheap no-op
   * otherwise. v1.4: refuses (status message, no crash) when the memory estimate does not fit unless the
   * user chose "Load anyway"; retries on CPU when a GPU load fails. Blocking: call from a background thread.
   */
  @Synchronized
  override fun initialize(settings: SettingsState): Boolean {
    val file = resolveModelFile(settings)
    val key = keyFor(file, settings)

    if (bridge.isModelLoaded && key == loadedKey) {
      bridge.setCpuThreads(settings.cpuThreads)
      return true
    }

    if (!file.isFile) {
      bridge.freeModel()
      loadedKey = null
      statusMessage = "No model file found. Open Settings and import a .gguf model."
      return false
    }

    lastMemoryVerdict = null
    if (memKey(file, settings) != memoryOverrideKey) {
      val verdict = MemoryEstimator.check(file.length(), settings.contextLength, availableMemoryBytes())
      if (!verdict.fits) {
        bridge.freeModel()
        loadedKey = null
        lastMemoryVerdict = verdict
        statusMessage = "Not enough free memory for this model: needs about ${verdict.neededBytes / 1048576} MB, " +
          "${verdict.availableBytes / 1048576} MB free." +
          (verdict.suggestedContext?.let { " Try a context of $it tokens." } ?: " Try a smaller model.")
        return false
      }
    }

    notice = null
    gpuActive = false
    val layers = gpuLayersFor(settings)
    var ok = try {
      bridge.initModel(file.absolutePath, settings.cpuThreads, settings.contextLength, layers)
    } catch (oom: OutOfMemoryError) {
      bridge.freeModel()
      false
    }
    if (ok && layers > 0) gpuActive = true
    if (!ok && layers > 0) {
      // v1.4: GPU (Vulkan) load failed: retry on the CPU automatically and tell the user.
      val gpuError = bridge.lastError
      ok = try {
        bridge.initModel(file.absolutePath, settings.cpuThreads, settings.contextLength, 0)
      } catch (oom: OutOfMemoryError) {
        bridge.freeModel()
        false
      }
      if (ok) notice = "GPU offload failed (${gpuError ?: "unknown error"}). Running on the CPU instead."
    }
    loadedKey = if (ok) key else null
    statusMessage = if (ok) null else friendlyLoadError(bridge.lastError)
    return ok
  }

  private fun friendlyLoadError(raw: String?): String {
    val r = raw ?: return "Failed to load model"
    return if (r.contains("memory", ignoreCase = true) || r.contains("OOM", ignoreCase = false))
      "Not enough memory to load this model. Close other apps, pick a smaller model, or lower the context length. ($r)"
    else r
  }

  /** Interrupts a running generation immediately (safe from any thread). */
  fun stopNow() = bridge.stop()

  fun benchmark(): String = bridge.benchmark()

  /** Frees the model's RAM. It reloads automatically on the next message. */
  @Synchronized
  override fun unload() {
    bridge.freeModel()
    loadedKey = null
    statusMessage = "Model unloaded (reloads on the next message)"
  }

  /** v1.4: exact count via llama_tokenize when a model is loaded, otherwise the ~4 chars/token estimate. */
  override fun countTokens(text: String): Int {
    if (text.isEmpty()) return 0
    return bridge.countTokensExact(text) ?: bridge.tokenize(text).size
  }

  /** Phone clock + zone, so the model can answer "what time/date is it" (it has no clock of its own). */
  private fun nowLine(): String {
    val z = java.util.TimeZone.getDefault()
    val f = java.text.SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", java.util.Locale.ENGLISH).apply { timeZone = z }
    return "\nCurrent date and time on the user's phone: ${f.format(java.util.Date())} (${z.id}). Use it when asked about the date or time." +
      "\nThe user may write Telugu or Hindi in English letters (for example \"ipudu time entha\" = what is the time now). Understand it and reply in the same style."
  }

  private fun systemFor(chatOnly: Boolean, systemOverride: String?, levelHint: String, thinking: Boolean = false): String =
    (systemOverride ?: ((if (chatOnly) CHAT_PROMPT else SYSTEM_PROMPT) + com.example.agent.Skills.promptFor(chatOnly) + (if (!chatOnly && levelHint.isNotBlank()) "\n" + levelHint else ""))) + (if (thinking) com.example.agent.Thinking.HINT else "") + nowLine()

  private fun buildPrompt(userPrompt: String, chatOnly: Boolean, history: List<Pair<String, String>>, systemOverride: String? = null, levelHint: String = "", thinking: Boolean = false): String {
    val system = systemFor(chatOnly, systemOverride, levelHint, thinking)
    val messages = listOf("system" to system) + history + ("user" to userPrompt)
    return bridge.applyChatTemplate(messages) ?: buildString {
      for ((role, content) in messages) append("<|im_start|>").append(role).append('\n').append(content).append("<|im_end|>\n")
      append("<|im_start|>assistant\n")
    }
  }

  private fun memoryInfo(): Pair<Long, Long> {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am?.getMemoryInfo(mi)
    val usedMb = (Debug.getNativeHeapAllocatedSize() + Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }) / (1024 * 1024)
    val totalMb = if (mi.totalMem > 0) mi.totalMem / (1024 * 1024) else Runtime.getRuntime().maxMemory() / (1024 * 1024)
    return usedMb to totalMb
  }

  /**
   * Streams real model output. Cancelling the collector stops native generation.
   * If no model is loaded, emits an explanatory message instead of fake output.
   */
  fun generateCompletionStream(
    prompt: String,
    settings: SettingsState,
    onTelemetryUpdate: (TelemetryData) -> Unit,
    chatOnly: Boolean = false,
    history: List<Pair<String, String>> = emptyList(),
    systemOverride: String? = null
  ): Flow<String> = callbackFlow {
    try {
      if (settings.backendMode == "remote") {
        val system = systemFor(chatOnly, systemOverride, com.example.data.model.OutputLevel.from(settings.outputLevel).hint, settings.thinking)
        val msgs = listOf("system" to system) + history + ("user" to prompt)
        val start = System.currentTimeMillis()
        var pieces = 0
        val host = runCatching { java.net.URL(settings.remoteUrl).host }.getOrDefault("server")
        // Remote: no tokenizer on the phone, so the prompt count is an estimate (shown with "≈").
        val estIn = (msgs.sumOf { it.first.length + it.second.length } / 4).coerceAtLeast(1)
        val remoteName = settings.remoteModel.ifBlank { host }
        onTelemetryUpdate(TelemetryData(inputTokens = estIn, activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
        kotlinx.coroutines.withContext(Dispatchers.IO) {
          RemoteClient.stream(settings, msgs, if (chatOnly) minOf(settings.maxOutputTokens, 1024) else settings.maxOutputTokens) { piece ->
            pieces++
            trySend(piece)
            if (pieces % 4 == 0) {
              val secs = max(0.05, (System.currentTimeMillis() - start) / 1000.0)
              onTelemetryUpdate(TelemetryData(inputTokens = estIn, outputTokens = pieces, tokensPerSecond = (pieces / secs).toFloat(), activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
            }
            isActive
          }
        }
        val secs = max(0.05, (System.currentTimeMillis() - start) / 1000.0)
        onTelemetryUpdate(TelemetryData(inputTokens = estIn, outputTokens = pieces, tokensPerSecond = (pieces / secs).toFloat(), latencyMs = System.currentTimeMillis() - start, activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
        close()
        return@callbackFlow
      }
      if (!initialize(settings)) {
        trySend(
          if (lastMemoryVerdict != null) "Offline model was not loaded: ${statusMessage}\n\nOpen Models to load it anyway or use a smaller context."
          else "Offline model is not ready: ${statusMessage ?: "unknown error"}\n\n" +
            "Go to Settings, tap \"Import GGUF model\" and pick a small coder model " +
            "(for example Qwen2.5-Coder 1.5B Q4_K_M)."
        )
        close()
        return@callbackFlow
      }

      val fullPrompt = buildPrompt(prompt, chatOnly, history, systemOverride, com.example.data.model.OutputLevel.from(settings.outputLevel).hint, settings.thinking)
      val start = System.currentTimeMillis()
      // v1.4: exact llama_tokenize count (same flags as generation).
      val exact = bridge.countTokensExact(fullPrompt)
      var inputTokens = exact ?: countTokens(fullPrompt)
      var cached = 0
      val modelName = resolveModelFile(settings).name
      var outputTokens = 0
      var promptDone = 0
      var firstTokenAt = 0L
      val totalMb = memoryInfo().second

      fun telemetry(): TelemetryData {
        val now = System.currentTimeMillis()
        val tps = if (outputTokens > 0 && firstTokenAt > 0) {
          outputTokens / max(0.05, (now - firstTokenAt) / 1000.0)
        } else if (promptDone > 0) {
          // prompt-processing speed while the model is still reading the prompt
          (promptDone - cached).coerceAtLeast(0) / max(0.05, (now - start) / 1000.0)
        } else 0.0
        return TelemetryData(
          inputTokens = if (outputTokens == 0 && promptDone > 0) promptDone else inputTokens,
          outputTokens = outputTokens,
          tokensPerSecond = tps.toFloat(),
          latencyMs = now - start,
          usedRamMb = memoryInfo().first,
          maxRamMb = totalMb,
          threadCount = settings.cpuThreads,
          activeBackend = if (gpuActive) "llama.cpp (offline, GPU)" else "llama.cpp (offline)",
          cachedTokens = cached,
          promptExact = exact != null,
          modelName = modelName
        )
      }
      onTelemetryUpdate(telemetry())

      // If the prompt never advances, show where the native side is stuck instead of waiting silently.
      val watchdog = launch {
        delay(25_000)
        if (promptDone == 0 && outputTokens == 0) {
          trySend("\n\n[No progress after 25 s. Native log:]\n${bridge.debugLog()}")
        }
      }

      val stopFilter = StopFilter()
      val n = bridge.generate(
        prompt = fullPrompt,
        maxTokens = if (chatOnly) minOf(settings.maxOutputTokens, 1024) else settings.maxOutputTokens,
        temperature = settings.temperature,
        topP = settings.topP,
        topK = settings.topK,
        repeatPenalty = settings.repetitionPenalty,
        onProgress = { done, total ->
          if (promptDone == 0) cached = bridge.cachedTokens()
          promptDone = done
          inputTokens = total
          onTelemetryUpdate(telemetry())
          isActive
        }
      ) { piece ->
        if (outputTokens == 0) firstTokenAt = System.currentTimeMillis()
        outputTokens++
        // Stop at any chat-turn marker the model prints as text (wrong/unknown template).
        val out = stopFilter.feed(piece)
        if (out.isNotEmpty()) trySend(out)
        if (outputTokens % 4 == 0) onTelemetryUpdate(telemetry())
        isActive && !stopFilter.hit
      }
      if (!stopFilter.hit) stopFilter.flush().let { if (it.isNotEmpty()) trySend(it) }
      watchdog.cancel()
      cached = bridge.cachedTokens()
      onTelemetryUpdate(telemetry())

      if (n < 0) trySend("\n\n[Generation error: ${bridge.lastError ?: "unknown"}]")
    } catch (t: Throwable) {
      LlamaBridge.safeLog("generateCompletionStream failed", t)
      val unreachable = t is java.net.ConnectException || t is java.net.UnknownHostException || t is java.net.SocketTimeoutException
      trySend(
        if (unreachable) "Cannot reach the remote server (${t.message}).\n\nOpen Models and switch to \"On this phone\", or start your server and tap Test connection."
        else "\n\n[Engine error: ${t.javaClass.simpleName}: ${t.message}]"
      )
    }
    close()
    awaitClose { bridge.stop() }
  }.buffer(Channel.UNLIMITED).flowOn(Dispatchers.Default)

  companion object {
    private const val CHAT_PROMPT =
      "You are VibeCoderAI, a friendly offline coding assistant. Reply naturally and briefly in the user's language. " +
        "Greetings and questions get a normal short answer. Only write code when the user asks for code, and then " +
        "use fenced markdown code blocks. Do not create project files unless the user asks you to build an app."

    // v1.4: shorter system prompt (same rules, fewer tokens on every request).
    private const val SYSTEM_PROMPT =
      "You are VibeCoderAI, an offline assistant that builds small web apps on a phone.\n" +
        "To create or change an app: one short plan sentence, then every changed file as\n" +
        "<file path=\"index.html\">\nFULL FILE CONTENT\n</file>\n" +
        "Rules: complete files only (no diffs, no placeholders), only files that change; vanilla HTML/CSS/JS, " +
        "no libraries or network; mobile-first, clean design; default files index.html, styles.css, app.js; " +
        "nothing after the last file. Answer questions briefly in plain text."
  }
}


/** Holds back text that could be the start of a chat-turn marker and stops once a full marker appears. */
internal class StopFilter {
  companion object {
    val MARKERS = listOf("<|im_end|>", "<|im_start|>", "<end_of_turn>", "<start_of_turn>", "<turn|>", "<|turn>",
      "<|eot_id|>", "<|start_header_id|>", "<|endoftext|>", "<|end|>", "<|user|>", "</s>")
  }
  private val buf = StringBuilder()
  var hit = false
    private set

  fun feed(piece: String): String {
    if (hit) return ""
    buf.append(piece)
    val text = buf.toString()
    val idx = MARKERS.map { text.indexOf(it) }.filter { it >= 0 }.minOrNull()
    if (idx != null) {
      hit = true
      buf.setLength(0)
      return text.substring(0, idx)
    }
    // keep a tail that might be the start of a marker
    var keep = 0
    for (m in MARKERS) for (k in minOf(m.length - 1, text.length) downTo 1) {
      if (text.endsWith(m.substring(0, k))) { if (k > keep) keep = k; break }
    }
    buf.setLength(0)
    buf.append(text.substring(text.length - keep))
    return text.substring(0, text.length - keep)
  }

  fun flush(): String { val t = buf.toString(); buf.setLength(0); return t }
}
