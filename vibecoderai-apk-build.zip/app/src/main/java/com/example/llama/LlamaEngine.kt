package com.example.llama

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.io.File
import kotlin.math.max

/**
 * High-level offline inference engine on top of llama.cpp.
 * Loads a GGUF model, applies the model's chat template and streams real generated tokens.
 */
class LlamaEngine(private val context: Context) {

  private val bridge = LlamaBridge.instance

  private var loadedKey: String? = null

  /** Why the model is not usable right now (null when ready). */
  @Volatile
  var statusMessage: String? = "No model loaded"
    private set

  val isReady: Boolean get() = bridge.isModelLoaded

  fun modelsDir(): File = File(context.filesDir, "models").also { if (!it.exists()) it.mkdirs() }

  /** Resolves which .gguf file the current settings point at (may not exist). */
  fun resolveModelFile(settings: SettingsState): File {
    settings.customModelPath?.let { return File(it) }
    val preset = SettingsState.AVAILABLE_MODELS.firstOrNull { it.id == settings.activeModelId }
    return File(modelsDir(), preset?.fileName ?: "${settings.activeModelId}.gguf")
  }

  /**
   * Loads (or reloads) the model when the file / context length changed. Cheap no-op otherwise.
   * Blocking: call from a background thread.
   */
  @Synchronized
  fun initialize(settings: SettingsState): Boolean {
    val file = resolveModelFile(settings)
    val key = "${file.absolutePath}|${file.length()}|${settings.contextLength}"

    if (bridge.isModelLoaded && key == loadedKey) {
      bridge.setCpuThreads(settings.cpuThreads)
      return true
    }

    if (!file.isFile) {
      bridge.freeModel()
      loadedKey = null
      statusMessage = "No model file found. Open Settings and import a .gguf model."
      return false
    }

    val ok = bridge.initModel(file.absolutePath, settings.cpuThreads, settings.contextLength)
    loadedKey = if (ok) key else null
    statusMessage = if (ok) null else (bridge.lastError ?: "Failed to load model")
    return ok
  }

  /** Interrupts a running generation immediately (safe from any thread). */
  fun stopNow() = bridge.stop()

  fun benchmark(): String = bridge.benchmark()

  /** Frees the model's RAM. It reloads automatically on the next message. */
  @Synchronized
  fun unload() {
    bridge.freeModel()
    loadedKey = null
    statusMessage = "Model unloaded (reloads on the next message)"
  }

  fun countTokens(text: String): Int {
    if (text.isEmpty()) return 0
    return bridge.tokenize(text).size
  }

  private fun buildPrompt(userPrompt: String): String {
    val messages = listOf(
      "system" to SYSTEM_PROMPT,
      "user" to userPrompt
    )
    return bridge.applyChatTemplate(messages)
      ?: "<|im_start|>system\n$SYSTEM_PROMPT<|im_end|>\n<|im_start|>user\n$userPrompt<|im_end|>\n<|im_start|>assistant\n"
  }

  private fun memoryInfo(): Pair<Long, Long> {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am?.getMemoryInfo(mi)
    val usedMb = (Debug.getNativeHeapAllocatedSize() + Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }) / (1024 * 1024)
    val totalMb = if (mi.totalMem > 0) mi.totalMem / (1024 * 1024) else Runtime.getRuntime().maxMemory() / (1024 * 1024)
    return usedMb to totalMb
  }

  /**
   * Streams real model output. Cancelling the collector stops native generation.
   * If no model is loaded, emits an explanatory message instead of fake output.
   */
  fun generateCompletionStream(
    prompt: String,
    settings: SettingsState,
    onTelemetryUpdate: (TelemetryData) -> Unit
  ): Flow<String> = callbackFlow {
    try {
      if (!initialize(settings)) {
        trySend(
          "Offline model is not ready: ${statusMessage ?: "unknown error"}\n\n" +
            "Go to Settings, tap \"Import GGUF model\" and pick a small coder model " +
            "(for example Qwen2.5-Coder 1.5B Q4_K_M)."
        )
        close()
        return@callbackFlow
      }

      val fullPrompt = buildPrompt(prompt)
      val start = System.currentTimeMillis()
      var inputTokens = countTokens(fullPrompt)
      var outputTokens = 0
      var promptDone = 0
      var firstTokenAt = 0L
      val totalMb = memoryInfo().second

      fun telemetry(): TelemetryData {
        val now = System.currentTimeMillis()
        val tps = if (outputTokens > 0 && firstTokenAt > 0) {
          outputTokens / max(0.05, (now - firstTokenAt) / 1000.0)
        } else if (promptDone > 0) {
          // prompt-processing speed while the model is still reading the prompt
          promptDone / max(0.05, (now - start) / 1000.0)
        } else 0.0
        return TelemetryData(
          inputTokens = if (outputTokens == 0 && promptDone > 0) promptDone else inputTokens,
          outputTokens = outputTokens,
          tokensPerSecond = tps.toFloat(),
          latencyMs = now - start,
          usedRamMb = memoryInfo().first,
          maxRamMb = totalMb,
          threadCount = settings.cpuThreads,
          activeBackend = "llama.cpp (offline)"
        )
      }
      onTelemetryUpdate(telemetry())

      val n = bridge.generate(
        prompt = fullPrompt,
        maxTokens = settings.maxOutputTokens,
        temperature = settings.temperature,
        topP = settings.topP,
        topK = settings.topK,
        repeatPenalty = settings.repetitionPenalty,
        onProgress = { done, total ->
          promptDone = done
          inputTokens = total
          onTelemetryUpdate(telemetry())
          isActive
        }
      ) { piece ->
        if (outputTokens == 0) firstTokenAt = System.currentTimeMillis()
        outputTokens++
        trySend(piece)
        if (outputTokens % 4 == 0) onTelemetryUpdate(telemetry())
        isActive
      }
      onTelemetryUpdate(telemetry())

      if (n < 0) trySend("\n\n[Generation error: ${bridge.lastError ?: "unknown"}]")
    } catch (t: Throwable) {
      LlamaBridge.safeLog("generateCompletionStream failed", t)
      trySend("\n\n[Engine error: ${t.javaClass.simpleName}: ${t.message}]")
    }
    close()
    awaitClose { bridge.stop() }
  }.buffer(Channel.UNLIMITED).flowOn(Dispatchers.Default)

  companion object {
    private const val SYSTEM_PROMPT =
      "You are VibeCoderAI, an offline coding assistant that builds small web apps on a phone.\n" +
        "When asked to create or change an app: write one short sentence of plan, then output every file you " +
        "create or change in exactly this format:\n" +
        "<file path=\"index.html\">\nFULL FILE CONTENT\n</file>\n" +
        "Rules: always output complete files, never diffs or placeholders; only files that change; " +
        "vanilla HTML/CSS/JS, no libraries, no network, no CDN; mobile-first, responsive, clean modern design; " +
        "default to index.html, styles.css, app.js; no text after the last file. " +
        "For questions, answer briefly in plain text."
  }
}
