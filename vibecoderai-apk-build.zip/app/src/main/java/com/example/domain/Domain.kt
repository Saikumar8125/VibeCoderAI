package com.example.domain

import com.example.data.local.ChatSummary
import com.example.data.model.ChatMessage
import com.example.data.model.SettingsState
import com.example.data.model.TokenUsage
import com.example.patch.EditFileEngine
import com.example.patch.EditResult
import com.example.patch.UnifiedDiff
import kotlinx.coroutines.flow.Flow
import java.io.File

/*
 * v1.4 domain layer: plain interfaces and use cases with no Android types, implemented by the data and
 * llama packages (ChatRepository, LlamaEngine). New code should depend on these, not on the classes.
 */

/** Chat history storage (implemented by data.repository.ChatRepository on Room). */
interface ChatHistory {
  val sessions: Flow<List<ChatSummary>>
  suspend fun load(id: String): List<ChatMessage>
  suspend fun save(id: String, messages: List<ChatMessage>, updated: Long = System.currentTimeMillis())
  suspend fun delete(id: String)
  suspend fun logUsage(u: TokenUsage)
}

/** The on-device model (implemented by llama.LlamaEngine). */
interface ModelRuntime {
  val isReady: Boolean
  val statusMessage: String?
  fun initialize(settings: SettingsState): Boolean
  fun unload()
  fun countTokens(text: String): Int
}

/** A project folder the agent may change (paths are always relative and sandboxed). */
interface ProjectWorkspace {
  val root: File
  /** Safe file for [relative] inside [root], or null when the path escapes it. */
  fun resolve(relative: String): File?
}

/** Default workspace over the existing sandboxed ProjectFiles rules. */
class FolderWorkspace(override val root: File) : ProjectWorkspace {
  override fun resolve(relative: String): File? = com.example.agent.ProjectFiles.resolve(root, relative)
}

/** Use case: compute (not write) the result of an exact find/replace edit. */
class PlanEdit(private val workspace: ProjectWorkspace) {
  operator fun invoke(path: String, find: String, replace: String): EditResult {
    val f = workspace.resolve(path) ?: return EditResult.Fail("Unsafe path: $path")
    if (!f.isFile) return EditResult.Fail("File not found: $path")
    return EditFileEngine.apply(f.readText(), find, replace)
  }
}

/** Use case: compute (not write) the result of a unified diff for one file. */
class PlanPatch(private val workspace: ProjectWorkspace) {
  operator fun invoke(diff: String, defaultPath: String? = null): List<Pair<String, UnifiedDiff.ApplyResult>> =
    UnifiedDiff.parse(diff, defaultPath).map { fp ->
      val f = workspace.resolve(fp.path)
      val old = if (f != null && f.isFile) f.readText() else ""
      fp.path to (if (f == null) UnifiedDiff.ApplyResult.Fail("Unsafe path: ${fp.path}") else UnifiedDiff.apply(old, fp))
    }
}
