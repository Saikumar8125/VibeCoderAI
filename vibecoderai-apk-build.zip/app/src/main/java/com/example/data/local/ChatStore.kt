package com.example.data.local

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ChatSummary(val id: String, val title: String, val updated: Long, val count: Int)

/** Persists every conversation as its own JSON file (filesDir/chats/<id>.json) so history survives restarts. */
class ChatStore(context: Context) {
  private val dir = File(context.filesDir, "chats").apply { mkdirs() }
  private val legacy = File(context.filesDir, "chat_history.json")

  /** Newest first. Migrates the old single-chat file the first time. */
  fun list(): List<ChatSummary> {
    migrateLegacy()
    return (dir.listFiles { f -> f.extension == "json" } ?: emptyArray()).mapNotNull { f ->
      runCatching {
        val o = JSONObject(f.readText())
        ChatSummary(
          id = f.nameWithoutExtension,
          title = o.optString("title", "Chat"),
          updated = o.optLong("updated"),
          count = o.optJSONArray("messages")?.length() ?: 0
        )
      }.getOrNull()
    }.sortedByDescending { it.updated }
  }

  fun load(id: String): List<ChatMessage> = runCatching {
    val f = File(dir, "$id.json")
    if (!f.isFile) return emptyList()
    val arr = JSONObject(f.readText()).getJSONArray("messages")
    (0 until arr.length()).map { i -> parseMessage(arr.getJSONObject(i)) }
  }.getOrDefault(emptyList())

  fun save(id: String, messages: List<ChatMessage>) {
    runCatching {
      val kept = messages.filter { it.sender == MessageSender.USER || it.sender == MessageSender.AGENT }.takeLast(80)
      val firstUser = kept.firstOrNull { it.sender == MessageSender.USER }?.content ?: return
      val arr = JSONArray()
      kept.forEach { arr.put(toJson(it)) }
      val o = JSONObject()
        .put("title", titleOf(firstUser))
        .put("updated", System.currentTimeMillis())
        .put("messages", arr)
      File(dir, "$id.json").writeText(o.toString())
    }
  }

  fun delete(id: String) {
    runCatching { File(dir, "$id.json").delete() }
  }

  private fun titleOf(text: String): String =
    text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(48) ?: "Chat"

  private fun migrateLegacy() {
    if (!legacy.isFile) return
    runCatching {
      val arr = JSONArray(legacy.readText())
      val msgs = (0 until arr.length()).map { parseMessage(arr.getJSONObject(it)) }
      if (msgs.any { it.sender == MessageSender.USER }) save(UUID.randomUUID().toString(), msgs)
    }
    legacy.delete()
  }

  private fun parseMessage(o: JSONObject): ChatMessage {
    val changes = o.optJSONArray("changes")?.let { ca ->
      (0 until ca.length()).map { j ->
        val c = ca.getJSONObject(j)
        FileChange(
          path = c.getString("path"),
          content = c.optString("content"),
          isNew = c.optBoolean("isNew"),
          status = ChangeStatus.valueOf(c.optString("status", "APPLIED")),
          savedLines = c.optInt("lines", 0)
        )
      }
    } ?: emptyList()
    return ChatMessage(
      id = o.getString("id"),
      sender = MessageSender.valueOf(o.getString("sender")),
      content = o.getString("content"),
      timestamp = o.optLong("ts"),
      fileChanges = changes
    )
  }

  private fun toJson(m: ChatMessage): JSONObject {
    val o = JSONObject()
      .put("id", m.id)
      .put("sender", m.sender.name)
      .put("content", m.content)
      .put("ts", m.timestamp)
    if (m.fileChanges.isNotEmpty()) {
      val ca = JSONArray()
      m.fileChanges.forEach { c ->
        val co = JSONObject().put("path", c.path).put("isNew", c.isNew).put("status", c.status.name).put("lines", c.lineCount)
        if (c.status == ChangeStatus.PENDING) co.put("content", c.content) // needed to apply later
        ca.put(co)
      }
      o.put("changes", ca)
    }
    return o
  }
}
