package com.example.data.local

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists the chat as JSON so history survives restarts. */
class ChatStore(context: Context) {
  private val file = File(context.filesDir, "chat_history.json")

  fun load(): List<ChatMessage> = runCatching {
    if (!file.isFile) return emptyList()
    val arr = JSONArray(file.readText())
    (0 until arr.length()).map { i ->
      val o = arr.getJSONObject(i)
      val changes = o.optJSONArray("changes")?.let { ca ->
        (0 until ca.length()).map { j ->
          val c = ca.getJSONObject(j)
          FileChange(
            path = c.getString("path"),
            content = c.optString("content"),
            isNew = c.optBoolean("isNew"),
            status = ChangeStatus.valueOf(c.optString("status", "APPLIED"))
          )
        }
      } ?: emptyList()
      ChatMessage(
        id = o.getString("id"),
        sender = MessageSender.valueOf(o.getString("sender")),
        content = o.getString("content"),
        timestamp = o.optLong("ts"),
        fileChanges = changes
      )
    }
  }.getOrDefault(emptyList())

  fun save(messages: List<ChatMessage>) {
    runCatching {
      val arr = JSONArray()
      messages.filter { it.sender == MessageSender.USER || it.sender == MessageSender.AGENT }
        .takeLast(60)
        .forEach { m ->
          val o = JSONObject()
            .put("id", m.id)
            .put("sender", m.sender.name)
            .put("content", m.content)
            .put("ts", m.timestamp)
          if (m.fileChanges.isNotEmpty()) {
            val ca = JSONArray()
            m.fileChanges.forEach { c ->
              val co = JSONObject().put("path", c.path).put("isNew", c.isNew).put("status", c.status.name)
              if (c.status == ChangeStatus.PENDING) co.put("content", c.content) // needed to apply later
              ca.put(co)
            }
            o.put("changes", ca)
          }
          arr.put(o)
        }
      file.writeText(arr.toString())
    }
  }
}
