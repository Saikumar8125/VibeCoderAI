package com.example.data.model

/** v1.4: token usage of one generation (stored in Room, totals shown in Data & diagnostics). */
data class TokenUsage(
  val promptTokens: Int,
  val outputTokens: Int,
  val tokensPerSecond: Float,
  val cachedTokens: Int,
  /** False when the prompt count is an estimate (remote backend). */
  val exact: Boolean,
  val model: String,
  val timestamp: Long,
  val durationMs: Long
)
