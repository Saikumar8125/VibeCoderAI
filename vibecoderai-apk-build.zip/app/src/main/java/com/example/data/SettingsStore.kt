package com.example.data

import android.content.Context
import com.example.data.model.SettingsState

/** Persists user settings (including the selected model file) across app restarts. */
class SettingsStore(context: Context) {
  private val prefs = context.getSharedPreferences("vibecoder_settings", Context.MODE_PRIVATE)

  fun load(): SettingsState {
    val d = SettingsState()
    // v2: bigger defaults so a full web app fits in one response.
    if (!prefs.getBoolean("schema2", false)) {
      prefs.edit().remove("contextLength").remove("maxOutputTokens").remove("repetitionPenalty").putBoolean("schema2", true).apply()
    }
    return d.copy(
      activeModelId = prefs.getString("activeModelId", d.activeModelId) ?: d.activeModelId,
      customModelPath = prefs.getString("customModelPath", null),
      cpuThreads = prefs.getInt("cpuThreads", d.cpuThreads),
      contextLength = prefs.getInt("contextLength", d.contextLength),
      maxOutputTokens = prefs.getInt("maxOutputTokens", d.maxOutputTokens),
      temperature = prefs.getFloat("temperature", d.temperature),
      topP = prefs.getFloat("topP", d.topP),
      topK = prefs.getInt("topK", d.topK),
      repetitionPenalty = prefs.getFloat("repetitionPenalty", d.repetitionPenalty),
      autoRebuildAfterPatch = prefs.getBoolean("autoRebuildAfterPatch", d.autoRebuildAfterPatch),
      maxRepairRetries = prefs.getInt("maxRepairRetries", d.maxRepairRetries),
      requireApprovalForDestructive = prefs.getBoolean("requireApprovalForDestructive", d.requireApprovalForDestructive)
    )
  }

  fun save(s: SettingsState) {
    prefs.edit()
      .putString("activeModelId", s.activeModelId)
      .putString("customModelPath", s.customModelPath)
      .putInt("cpuThreads", s.cpuThreads)
      .putInt("contextLength", s.contextLength)
      .putInt("maxOutputTokens", s.maxOutputTokens)
      .putFloat("temperature", s.temperature)
      .putFloat("topP", s.topP)
      .putInt("topK", s.topK)
      .putFloat("repetitionPenalty", s.repetitionPenalty)
      .putBoolean("autoRebuildAfterPatch", s.autoRebuildAfterPatch)
      .putInt("maxRepairRetries", s.maxRepairRetries)
      .putBoolean("requireApprovalForDestructive", s.requireApprovalForDestructive)
      .apply()
  }
}
