package com.example.data.model

enum class ModelBackend(val displayName: String) {
  LOCAL_LLAMA_JNI("Local llama.cpp (JNI/C++)")
}

data class LlamaModelPreset(
  val id: String,
  val name: String,
  val fileName: String,
  val sizeMb: Int,
  val contextTokens: Int,
  val quantMethod: String
)

data class SettingsState(
  val backend: ModelBackend = ModelBackend.LOCAL_LLAMA_JNI,
  val activeModelId: String = "qwen2.5-coder-0.5b",
  val customModelPath: String? = null,
  val cpuThreads: Int = 4,
  val contextLength: Int = 4096,
  val maxOutputTokens: Int = 1536,
  val temperature: Float = 0.2f,
  val topP: Float = 0.95f,
  val topK: Int = 40,
  val repetitionPenalty: Float = 1.0f,
  val autoRebuildAfterPatch: Boolean = true,
  val maxRepairRetries: Int = 3,
  val requireApprovalForDestructive: Boolean = true,
  val themeMode: String = "system",
  val glassBlur: Boolean = true,
  val autonomous: Boolean = true,
  val outputLevel: String = "high",
  val agentRole: String = "builder",
  val backend: String = "local",
  val remoteUrl: String = "http://127.0.0.1:11434/v1",
  val remoteModel: String = "",
  val remoteKey: String = ""
) {
  companion object {
    val AVAILABLE_MODELS = listOf(
      LlamaModelPreset(
        id = "qwen2.5-coder-0.5b",
        name = "Qwen2.5-Coder-0.5B-Instruct",
        fileName = "qwen2.5-coder-0.5b-instruct-q4_k_m.gguf",
        sizeMb = 394,
        contextTokens = 4096,
        quantMethod = "Q4_K_M"
      ),
      LlamaModelPreset(
        id = "smollm2-coder-135m",
        name = "SmolLM2-135M-Instruct-Coder",
        fileName = "smollm2-135m-instruct-q8_0.gguf",
        sizeMb = 145,
        contextTokens = 2048,
        quantMethod = "Q8_0"
      ),
      LlamaModelPreset(
        id = "deepseek-coder-1.3b",
        name = "DeepSeek-Coder-1.3B-Instruct",
        fileName = "deepseek-coder-1.3b-instruct-q4_k_s.gguf",
        sizeMb = 875,
        contextTokens = 4096,
        quantMethod = "Q4_K_S"
      ),
      LlamaModelPreset(
        id = "llama-3.2-1b",
        name = "Llama-3.2-1B-Instruct",
        fileName = "llama-3.2-1b-instruct-q4_k_m.gguf",
        sizeMb = 808,
        contextTokens = 2048,
        quantMethod = "Q4_K_M"
      )
    )
  }
}

data class TelemetryData(
  val inputTokens: Int = 0,
  val outputTokens: Int = 0,
  val tokensPerSecond: Float = 0.0f,
  val latencyMs: Long = 0,
  val usedRamMb: Long = 0,
  val maxRamMb: Long = 0,
  val threadCount: Int = 4,
  val activeBackend: String = "Local llama.cpp"
)
