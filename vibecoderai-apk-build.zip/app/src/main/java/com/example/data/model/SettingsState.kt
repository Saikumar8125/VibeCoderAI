package com.example.data.model

enum class ModelBackend(val displayName: String) {
  LOCAL_LLAMA_JNI("Local llama.cpp (JNI/C++)")
}

data class LlamaModelPreset(
  val id: String,
  val name: String,
  val fileName: String,
  val sizeMb: Int,
  val contextTokens: Int,
  val quantMethod: String
)

data class SettingsState(
  val backend: ModelBackend = ModelBackend.LOCAL_LLAMA_JNI,
  val activeModelId: String = "qwen2.5-coder-0.5b",
  val customModelPath: String? = null,
  val cpuThreads: Int = 4,
  val contextLength: Int = 4096,
  val maxOutputTokens: Int = 1536,
  val temperature: Float = 0.2f,
  val topP: Float = 0.95f,
  val topK: Int = 40,
  val repetitionPenalty: Float = 1.15f,
  val thinking: Boolean = false,
  val autoRebuildAfterPatch: Boolean = true,
  val maxRepairRetries: Int = 3,
  val requireApprovalForDestructive: Boolean = true,
  /** v1.4: new files written by the agent skip the approval dialog. */
  val autoApproveNewFiles: Boolean = true,
  /** v1.4: edits of existing files skip approval (never deletes, never commands). */
  val autoApproveSafeEdits: Boolean = false,
  /** v1.4: offload layers to the GPU (only works in a Vulkan build). */
  val gpuOffload: Boolean = false,
  /** v1.4: layers to offload when [gpuOffload] is on (99 = all). */
  val gpuLayers: Int = 99,
  val themeMode: String = "system",
  val glassBlur: Boolean = true,
  val autonomous: Boolean = true,
  val outputLevel: String = "high",
  val agentRole: String = "builder",
  val backendMode: String = "local",
  val remoteUrl: String = "http://127.0.0.1:11434/v1",
  val remoteModel: String = "",
  val remoteKey: String = ""
) {
  companion object {
    val AVAILABLE_MODELS = listOf(
      LlamaModelPreset(
        id = "qwen2.5-coder-0.5b",
        name = "Qwen2.5-Coder-0.5B-Instruct",
        fileName = "qwen2.5-coder-0.5b-instruct-q4_k_m.gguf",
        sizeMb = 394,
        contextTokens = 4096,
        quantMethod = "Q4_K_M"
      ),
      LlamaModelPreset(
        id = "smollm2-coder-135m",
        name = "SmolLM2-135M-Instruct-Coder",
        fileName = "smollm2-135m-instruct-q8_0.gguf",
        sizeMb = 145,
        contextTokens = 2048,
        quantMethod = "Q8_0"
      ),
      LlamaModelPreset(
        id = "deepseek-coder-1.3b",
        name = "DeepSeek-Coder-1.3B-Instruct",
        fileName = "deepseek-coder-1.3b-instruct-q4_k_s.gguf",
        sizeMb = 875,
        contextTokens = 4096,
        quantMethod = "Q4_K_S"
      ),
      LlamaModelPreset(
        id = "llama-3.2-1b",
        name = "Llama-3.2-1B-Instruct",
        fileName = "llama-3.2-1b-instruct-q4_k_m.gguf",
        sizeMb = 808,
        contextTokens = 2048,
        quantMethod = "Q4_K_M"
      )
    )
  }
}

data class TelemetryData(
  val inputTokens: Int = 0,
  val outputTokens: Int = 0,
  val tokensPerSecond: Float = 0.0f,
  val latencyMs: Long = 0,
  val usedRamMb: Long = 0,
  val maxRamMb: Long = 0,
  val threadCount: Int = 4,
  val activeBackend: String = "Local llama.cpp",
  /** v1.4: prompt tokens reused from the KV cache (local model only). */
  val cachedTokens: Int = 0,
  /** v1.4: true when [inputTokens] is an exact llama_tokenize count, false for the ~4 chars/token estimate. */
  val promptExact: Boolean = false,
  /** v1.4: model file or remote model id, for token usage logs. */
  val modelName: String = ""
)

/** v1.4: "1234 tokens · cached 900" for local (exact) prompts, "≈1234 tokens" for remote estimates. */
val TelemetryData.promptLabel: String
  get() = (if (promptExact) "" else "≈") + "$inputTokens tokens" + (if (cachedTokens > 0) " · cached $cachedTokens" else "")
