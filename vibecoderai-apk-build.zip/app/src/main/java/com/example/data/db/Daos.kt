package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
  @Query("SELECT * FROM chat_sessions ORDER BY updated DESC")
  fun observeSessions(): Flow<List<ChatSessionEntity>>

  @Query("SELECT * FROM chat_sessions ORDER BY updated DESC")
  suspend fun sessions(): List<ChatSessionEntity>

  @Query("SELECT * FROM chat_messages WHERE session_id = :sessionId ORDER BY position ASC")
  suspend fun messages(sessionId: String): List<ChatMessageEntity>

  @Upsert
  suspend fun upsertSession(session: ChatSessionEntity)

  @Insert
  suspend fun insertMessages(messages: List<ChatMessageEntity>)

  @Query("DELETE FROM chat_messages WHERE session_id = :sessionId")
  suspend fun deleteMessages(sessionId: String)

  @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
  suspend fun deleteSession(sessionId: String)

  @Query("SELECT COUNT(*) FROM chat_sessions")
  suspend fun sessionCount(): Int

  /** Replaces a whole conversation atomically (idempotent: same input, same rows). */
  @Transaction
  suspend fun replaceSession(session: ChatSessionEntity, messages: List<ChatMessageEntity>) {
    upsertSession(session)
    deleteMessages(session.id)
    if (messages.isNotEmpty()) insertMessages(messages)
  }
}

@Dao
interface TokenUsageDao {
  @Insert
  suspend fun insert(usage: TokenUsageEntity)

  @Query(
    "SELECT COUNT(*) AS runs, COALESCE(SUM(prompt_tokens), 0) AS promptTokens, " +
      "COALESCE(SUM(output_tokens), 0) AS outputTokens, COALESCE(SUM(cached_tokens), 0) AS cachedTokens, " +
      "COALESCE(AVG(CASE WHEN tokens_per_second > 0 THEN tokens_per_second END), 0) AS avgTokensPerSecond, " +
      "COALESCE(SUM(CASE WHEN exact = 0 THEN 1 ELSE 0 END), 0) AS estimatedRuns FROM token_usage"
  )
  fun observeTotals(): Flow<UsageTotals>

  @Query("SELECT * FROM token_usage ORDER BY timestamp DESC LIMIT :limit")
  fun observeRecent(limit: Int): Flow<List<TokenUsageEntity>>

  @Query("DELETE FROM token_usage")
  suspend fun clear()
}
