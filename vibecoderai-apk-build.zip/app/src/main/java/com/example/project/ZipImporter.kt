package com.example.project

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * v1.4: ZIP extraction pulled out of ProjectManager so it can be unit tested without Android.
 * Rejects Zip Slip entries ("../x", absolute paths, drive letters) before anything is written.
 */
object ZipImporter {

  /** Where [entryName] would land inside [targetDir], or null when it escapes the folder. */
  fun resolveEntry(targetDir: File, entryName: String): File? {
    val name = entryName.replace('\\', '/')
    if (name.isEmpty() || name.startsWith("/") || Regex("^[A-Za-z]:").containsMatchIn(name)) return null
    if (name.split('/').any { it == ".." }) return null
    val dest = File(targetDir, name)
    return try {
      val root = targetDir.canonicalPath
      val c = dest.canonicalPath
      if (c == root || c.startsWith(root + File.separator)) dest else null
    } catch (_: Exception) {
      null
    }
  }

  /**
   * Extracts [zip] into [targetDir]. Throws [SecurityException] on the first unsafe entry; in that
   * case it has already validated every entry, so nothing was written (entries are checked first).
   */
  fun extract(zip: File, targetDir: File): Int {
    // Pass 1: validate every entry name, so a malicious archive writes nothing at all.
    FileInputStream(zip).use { validate(it, targetDir) }
    // Pass 2: extract.
    targetDir.mkdirs()
    var count = 0
    ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        val dest = resolveEntry(targetDir, entry.name)
          ?: throw SecurityException("Zip Slip path traversal vulnerability blocked: ${entry.name}")
        if (entry.isDirectory) {
          dest.mkdirs()
        } else {
          dest.parentFile?.mkdirs()
          FileOutputStream(dest).use { zis.copyTo(it) }
          count++
        }
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }
    return count
  }

  private fun validate(input: InputStream, targetDir: File) {
    ZipInputStream(BufferedInputStream(input)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        if (resolveEntry(targetDir, entry.name) == null) {
          throw SecurityException("Zip Slip path traversal vulnerability blocked: ${entry.name}")
        }
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }
  }
}
