package com.example.project

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * v1.4: shared state between chat code blocks ("Insert") and the Projects editor.
 * The editor publishes the file that is open and its cursor; Insert posts a [Request] that the editor
 * consumes (inserting at the cursor, or at the end) and MainScreen switches to the Projects tab.
 */
object EditorBridge {

  /** Absolute path of the file last active in the editor, or null when none is open. */
  @Volatile var openFile: String? = null

  /** Cursor offset in [openFile] (null = unknown, insert at the end). */
  @Volatile var cursor: Int? = null

  /** Project the editor state belongs to (cleared when another project is selected). */
  @Volatile var projectId: String? = null

  /** Root folder of the active project (new files from code blocks are created inside it). */
  @Volatile var projectRoot: String? = null

  data class Request(val id: Long, val path: String, val code: String, val openOnly: Boolean)

  private val _requests = MutableStateFlow<Request?>(null)
  val requests: StateFlow<Request?> = _requests.asStateFlow()

  /** True when a file is open in the editor (Insert goes there; otherwise a new file is offered). */
  fun hasOpenFile(): Boolean = openFile?.let { File(it).isFile } == true

  /** Queues [code] for insertion into the open file. Returns false when no file is open. */
  fun insertIntoOpenFile(code: String): Boolean {
    val path = openFile?.takeIf { File(it).isFile } ?: return false
    _requests.value = Request(System.nanoTime(), path, code, openOnly = false)
    return true
  }

  /** Asks the editor to open [path] (a file just created from a code block). */
  fun openInEditor(path: String) {
    _requests.value = Request(System.nanoTime(), path, "", openOnly = true)
  }

  fun consume(id: Long) {
    if (_requests.value?.id == id) _requests.value = null
  }

  /**
   * Inserts [code] into [text] at [cursor] (clamped; null = end). Adds a line break before/after when the
   * code would otherwise run into neighbouring text. Returns the new text and the cursor after the code.
   */
  fun insertAt(text: String, cursor: Int?, code: String): Pair<String, Int> {
    val at = (cursor ?: text.length).coerceIn(0, text.length)
    val before = if (at > 0 && text[at - 1] != '\n') "\n" else ""
    val after = if (at < text.length && text[at] != '\n' && !code.endsWith("\n")) "\n" else ""
    val insert = before + code + after
    return (text.substring(0, at) + insert + text.substring(at)) to (at + before.length + code.length)
  }

  /** Default file name for a code block of [lang] ("kotlin" -> Snippet.kt). */
  fun suggestFileName(lang: String): String = when (lang.trim().lowercase()) {
    "kotlin", "kt", "kts" -> "Snippet.kt"
    "java" -> "Snippet.java"
    "js", "javascript", "jsx" -> "snippet.js"
    "ts", "typescript", "tsx" -> "snippet.ts"
    "html", "htm", "xml-html" -> "snippet.html"
    "css" -> "snippet.css"
    "json" -> "snippet.json"
    "xml" -> "snippet.xml"
    "py", "python" -> "snippet.py"
    "sh", "bash", "shell", "zsh" -> "script.sh"
    "md", "markdown" -> "notes.md"
    "sql" -> "query.sql"
    "c" -> "snippet.c"
    "cpp", "c++", "cc" -> "snippet.cpp"
    "go" -> "snippet.go"
    "rust", "rs" -> "snippet.rs"
    "yaml", "yml" -> "snippet.yml"
    else -> "snippet.txt"
  }

  /** [name] made unique inside [dir]: "a.js", "a-1.js", "a-2.js", ... */
  fun uniqueName(dir: File, name: String): String {
    if (!File(dir, name).exists()) return name
    val dot = name.lastIndexOf('.').takeIf { it > 0 } ?: name.length
    val stem = name.substring(0, dot)
    val ext = name.substring(dot)
    var i = 1
    while (File(dir, "$stem-$i$ext").exists()) i++
    return "$stem-$i$ext"
  }
}
