package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    com.example.data.SettingsStore(this).load().let {
      com.example.ui.theme.ThemeController.mode = it.themeMode
      com.example.ui.theme.ThemeController.blur = it.glassBlur
    }
    setContent {
      MyApplicationTheme {
        MainScreen()
      }
    }
  }
}
