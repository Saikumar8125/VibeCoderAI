package com.example.security

import java.io.File

sealed class ValidationResult {
  object Approved : ValidationResult()
  data class RequiresUserApproval(val reason: String, val severity: String = "warning") : ValidationResult()
  data class Blocked(val reason: String) : ValidationResult()
}

class SecurityManager {

  companion object {
    private val FORBIDDEN_COMMAND_PATTERNS = listOf(
      Regex("""\brm\s+-[rR]?[fF]?\s+(/|/\*|\.\.)"""),
      Regex("""\bmkfs\b"""),
      Regex("""\bdd\s+if="""),
      Regex("""\bformat\b"""),
      Regex("""\breboot\b"""),
      Regex("""\bshutdown\b"""),
      Regex("""\b:\(\)\s*\{\s*:\|:&\s*\};:"""), // Fork bomb
      Regex("""chmod\s+(-[rR]\s+)?777\s+(/|/\*)""")
    )

    private val DESTRUCTIVE_COMMAND_KEYWORDS = listOf(
      "rm", "rmdir", "delete", "unlink", "git reset --hard", "git clean", "drop"
    )
  }

  /**
   * Verifies that the given path is strictly contained within the project's root directory,
   * completely preventing path traversal (e.g. "../" escapes or absolute system paths).
   */
  fun isPathSafe(targetFile: File, projectRoot: File): Boolean {
    return try {
      val canonicalTarget = targetFile.canonicalFile
      val canonicalRoot = projectRoot.canonicalFile
      // v1.4: compare with a trailing separator, so "/projects/demo2" is not accepted as inside "/projects/demo".
      canonicalTarget.path == canonicalRoot.path ||
        canonicalTarget.path.startsWith(canonicalRoot.path + File.separator)
    } catch (e: Exception) {
      false
    }
  }

  /**
   * Validates a shell command against the security policy.
   * Disallows unrestricted execution, blocks path traversal, and flags destructive operations for user confirmation.
   */
  fun validateCommand(rawCommand: String, projectRoot: File? = null): ValidationResult {
    val trimmed = rawCommand.trim()
    if (trimmed.isEmpty()) {
      return ValidationResult.Blocked("Empty command.")
    }

    // 1. Check strictly forbidden commands
    for (pattern in FORBIDDEN_COMMAND_PATTERNS) {
      if (pattern.containsMatchIn(trimmed)) {
        return ValidationResult.Blocked("Execution blocked by security policy: Potentially destructive pattern detected.")
      }
    }

    // 2. Check for unauthorized system paths outside workspace
    val forbiddenPaths = listOf("/etc", "/system", "/proc", "/sys", "/dev", "/root")
    for (fp in forbiddenPaths) {
      if (trimmed.contains(fp)) {
        return ValidationResult.Blocked("Execution blocked: Access to system directory '$fp' is strictly forbidden.")
      }
    }

    // 3. Block path traversal attempts
    if (trimmed.contains("../") || trimmed.contains("..\\")) {
      return ValidationResult.Blocked("Execution blocked: Path traversal ('..') is not permitted in commands.")
    }

    // 4. Check for destructive operations requiring explicit user approval
    for (keyword in DESTRUCTIVE_COMMAND_KEYWORDS) {
      if (trimmed.startsWith(keyword) || trimmed.contains(" $keyword ")) {
        return ValidationResult.RequiresUserApproval(
          reason = "Command modifies or deletes files: '$trimmed'",
          severity = "warning"
        )
      }
    }

    return ValidationResult.Approved
  }

  /**
   * Checks whether a file write or patch requires user approval.
   */
  fun validateFileOperation(targetFile: File, projectRoot: File, isDelete: Boolean = false): ValidationResult {
    if (!isPathSafe(targetFile, projectRoot)) {
      return ValidationResult.Blocked("Access denied: File '${targetFile.path}' is outside approved project workspace '${projectRoot.path}'.")
    }

    if (isDelete) {
      return ValidationResult.RequiresUserApproval(
        reason = "Permanent deletion of file '${targetFile.name}'",
        severity = "high"
      )
    }

    if (targetFile.exists()) {
      return ValidationResult.RequiresUserApproval(
        reason = "Modifying existing file '${targetFile.name}'",
        severity = "medium"
      )
    }

    return ValidationResult.Approved
  }
}
