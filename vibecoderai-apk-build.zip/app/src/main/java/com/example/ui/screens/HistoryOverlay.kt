package com.example.ui.screens

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatSummary
import com.example.ui.components.GlassState
import com.example.ui.components.glassSurface
import com.example.ui.components.pressScale
import com.example.ui.components.rememberHaptics
import com.example.ui.components.specularBrush
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/** Chat history sheet: every saved conversation, newest first. Tap to open, bin to delete. */
@Composable
fun HistoryOverlay(
  glass: GlassState,
  chats: List<ChatSummary>,
  currentId: String,
  onOpen: (String) -> Unit,
  onDelete: (String) -> Unit,
  onNew: () -> Unit,
  onDismiss: () -> Unit
) {
  val haptics = rememberHaptics()
  val shape = RoundedCornerShape(30.dp)
  val none = remember { MutableInteractionSource() }
  val now = System.currentTimeMillis()

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black.copy(alpha = 0.50f))
      .clickable(interactionSource = none, indication = null, onClick = onDismiss)
  ) {
    Column(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .navigationBarsPadding()
        .padding(8.dp)
        .fillMaxWidth()
        .fillMaxHeight(0.86f)
        .shadow(24.dp, shape, clip = false, ambientColor = Color.Black, spotColor = Color.Black)
        .glassSurface(glass, shape, ObsidianSurfaceSolid.copy(alpha = if (Palette.dark) 0.78f else 0.70f), blurRadiusPx = 90f)
        .border(1.dp, specularBrush(), shape)
        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          "History",
          color = TextPrimary,
          fontSize = 28.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = (-0.4).sp,
          modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { haptics.tick(); onDismiss() }) {
          Text("Done", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
      }

      Row(
        modifier = Modifier
          .padding(top = 6.dp, bottom = 10.dp)
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(CyberCyanPrimary)
          .clickable { haptics.tick(); onNew() }
          .pressScale()
          .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        Text("  New chat", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
      }

      if (chats.isEmpty()) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
          Text("No saved chats yet. Send a message and it shows up here.", color = TextMuted, fontSize = 14.sp)
        }
      } else {
        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(4.dp),
          contentPadding = PaddingValues(bottom = 8.dp)
        ) {
          items(chats, key = { it.id }) { chat ->
            val selected = chat.id == currentId
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (selected) CyberCyanPrimary.copy(alpha = 0.16f) else Color.Transparent)
                .clickable { haptics.tick(); onOpen(chat.id) }
                .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(Modifier.weight(1f)) {
                Text(
                  chat.title,
                  color = TextPrimary,
                  fontSize = 16.sp,
                  fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  DateUtils.getRelativeTimeSpanString(chat.updated, now, DateUtils.MINUTE_IN_MILLIS).toString() +
                    "  ·  " + chat.count + " messages",
                  color = TextMuted,
                  fontSize = 12.sp
                )
              }
              IconButton(onClick = { haptics.tick(); onDelete(chat.id) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete chat", tint = CyberCoralError, modifier = Modifier.size(20.dp))
              }
            }
          }
        }
      }
    }
  }
}
