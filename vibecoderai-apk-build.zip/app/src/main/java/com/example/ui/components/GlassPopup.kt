package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties

/**
 * v1.2.1: one animated "liquid glass" popup for every floating menu.
 *
 * - Nothing is composed (no window, no layer) while closed.
 * - Open: fade 140ms + scale 0.9 -> 1 from the anchor corner on a gentle spring (no overshoot) + a 6dp drift
 *   away from the anchor. Close: fade 120ms + scale to 0.94 toward the anchor.
 * - Every close path (outside tap, back, item click, [expanded] = false) plays the exit; [onClosed] runs only
 *   after the exit has finished.
 * - All motion is graphicsLayer only (read in the layer phase): no recomposition or relayout per frame.
 */
@Composable
fun GlassPopup(
  expanded: Boolean,
  onDismissRequest: () -> Unit,
  above: Boolean,
  alignEnd: Boolean,
  modifier: Modifier = Modifier,
  onClosed: () -> Unit = {},
  shape: Shape = RoundedCornerShape(28.dp),
  scrollable: Boolean = false,
  content: @Composable ColumnScope.() -> Unit
) {
  val state = remember { MutableTransitionState(false) }
  state.targetState = expanded
  val visible = state.currentState || state.targetState || !state.isIdle
  val closed by rememberUpdatedState(onClosed)
  // Plain holder (not state) so marking "has been open" never causes a recomposition.
  val wasShown = remember { booleanArrayOf(false) }
  if (state.currentState || state.targetState) wasShown[0] = true
  LaunchedEffect(state.currentState, state.targetState, state.isIdle) {
    if (wasShown[0] && state.isIdle && !state.currentState && !state.targetState) {
      wasShown[0] = false
      closed()
    }
  }
  if (!visible) return

  val density = LocalDensity.current
  val gapPx = with(density) { 8.dp.roundToPx() }
  val provider = remember(above, alignEnd, gapPx) { GlassPopupPosition(above, alignEnd, gapPx) }
  val dismiss by rememberUpdatedState(onDismissRequest)

  Popup(
    popupPositionProvider = provider,
    onDismissRequest = { dismiss() },
    properties = PopupProperties(focusable = true)
  ) {
    val transition = rememberTransition(state, label = "glassPopup")
    val progress = transition.animateFloat(
      transitionSpec = {
        if (targetState) spring(dampingRatio = 0.8f, stiffness = 500f, visibilityThreshold = 0.001f)
        else tween(120, easing = FastOutSlowInEasing)
      },
      label = "progress"
    ) { if (it) 1f else 0f }
    val alpha = transition.animateFloat(
      transitionSpec = { if (targetState) tween(140, easing = LinearOutSlowInEasing) else tween(120) },
      label = "alpha"
    ) { if (it) 1f else 0f }
    val drift = with(density) { 6.dp.toPx() }
    val origin = TransformOrigin(if (alignEnd) 1f else 0f, if (above) 1f else 0f)
    Column(
      modifier = modifier
        .graphicsLayer {
          val p = progress.value.coerceIn(0f, 1.05f)
          val opening = state.targetState
          val s = if (opening) 0.9f + 0.1f * p else 0.94f + 0.06f * p
          scaleX = s
          scaleY = s
          this.alpha = alpha.value.coerceIn(0f, 1f)
          transformOrigin = origin
          // Starts 6dp closer to the anchor and drifts out to its resting place.
          translationY = (1f - p.coerceAtMost(1f)) * drift * (if (above) 1f else -1f)
        }
        .padding(14.dp)
        .glassPopupSurface(shape)
        .then(if (scrollable) Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()) else Modifier)
        .padding(8.dp),
      verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)
    ) {
      CompositionLocalProvider(LocalContentColor provides com.example.ui.theme.TextPrimary) { content() }
    }
  }
}

/** Above or below the anchor, aligned to its start or end; flips if it would not fit. */
private class GlassPopupPosition(val above: Boolean, val alignEnd: Boolean, val gap: Int) : PopupPositionProvider {
  override fun calculatePosition(
    anchorBounds: IntRect,
    windowSize: IntSize,
    layoutDirection: LayoutDirection,
    popupContentSize: IntSize
  ): IntOffset {
    val rawX = if (alignEnd) anchorBounds.right - popupContentSize.width else anchorBounds.left
    val x = rawX.coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
    val aboveY = anchorBounds.top - popupContentSize.height + gap / 2
    val belowY = anchorBounds.bottom - gap / 2
    val fitsAbove = aboveY >= 0
    val fitsBelow = belowY + popupContentSize.height <= windowSize.height
    val rawY = when {
      above && (fitsAbove || !fitsBelow) -> aboveY
      !above && (fitsBelow || !fitsAbove) -> belowY
      above -> belowY
      else -> aboveY
    }
    val y = rawY.coerceIn(0, (windowSize.height - popupContentSize.height).coerceAtLeast(0))
    return IntOffset(x, y)
  }
}

/** Drop-in for Material3 DropdownMenu with the glass look and the same open/close motion. */
@Composable
fun GlassDropdownMenu(
  expanded: Boolean,
  onDismissRequest: () -> Unit,
  modifier: Modifier = Modifier,
  alignEnd: Boolean = false,
  content: @Composable ColumnScope.() -> Unit
) {
  GlassPopup(
    expanded = expanded,
    onDismissRequest = onDismissRequest,
    above = false,
    alignEnd = alignEnd,
    modifier = modifier.widthIn(min = 200.dp, max = 320.dp),
    shape = RoundedCornerShape(24.dp),
    scrollable = true,
    content = content
  )
}

/** Subtle drag handle for glass bottom sheets. */
@Composable
fun GlassSheetHandle() {
  Box(Modifier.padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
    Spacer(
      Modifier
        .width(36.dp)
        .heightIn(min = 4.dp, max = 4.dp)
        .background(com.example.ui.theme.TextMuted.copy(alpha = 0.35f), CircleShape)
    )
  }
}

/**
 * AlertDialog with the frosted glass container, a hairline rim, and fade + scale 0.95 -> 1 entry
 * (graphicsLayer only). The dialog window gets a matching fade + scale exit animation.
 */
@Composable
fun GlassAlertDialog(
  onDismissRequest: () -> Unit,
  confirmButton: @Composable () -> Unit,
  modifier: Modifier = Modifier,
  dismissButton: (@Composable () -> Unit)? = null,
  icon: (@Composable () -> Unit)? = null,
  title: (@Composable () -> Unit)? = null,
  text: (@Composable () -> Unit)? = null,
  properties: androidx.compose.ui.window.DialogProperties = androidx.compose.ui.window.DialogProperties()
) {
  val shape = RoundedCornerShape(28.dp)
  val enter = remember { Animatable(0f) }
  LaunchedEffect(Unit) { enter.animateTo(1f, tween(180, easing = LinearOutSlowInEasing)) }
  androidx.compose.material3.AlertDialog(
    onDismissRequest = onDismissRequest,
    confirmButton = {
      GlassDialogWindowEffect()
      confirmButton()
    },
    modifier = modifier
      .graphicsLayer {
        val p = enter.value
        alpha = p
        scaleX = 0.95f + 0.05f * p
        scaleY = 0.95f + 0.05f * p
      }
      .border(1.dp, GlassPopupColors.rim(), shape),
    dismissButton = dismissButton,
    icon = icon,
    title = title,
    text = text,
    shape = shape,
    containerColor = GlassPopupColors.container,
    titleContentColor = com.example.ui.theme.TextPrimary,
    textContentColor = com.example.ui.theme.TextSecondary,
    tonalElevation = 0.dp,
    properties = properties
  )
}

/** Gives the hosting dialog window a soft fade + scale exit (window animation, no per-frame Compose work). */
@Composable
private fun GlassDialogWindowEffect() {
  val view = LocalView.current
  DisposableEffect(view) {
    val window = (view.parent as? DialogWindowProvider)?.window
    runCatching { window?.setWindowAnimations(com.example.R.style.GlassDialogAnimation) }
    onDispose { }
  }
}
