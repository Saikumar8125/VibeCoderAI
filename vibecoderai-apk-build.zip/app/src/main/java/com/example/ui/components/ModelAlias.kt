package com.example.ui.components

/**
 * v1.2: short, human friendly name for a model file or remote model id, used in the chat header where
 * the full GGUF file name gets cut mid-word. The full name stays visible on the Models screen.
 *
 *   "qwen2.5-coder-7b-instruct-q5_k_m"        -> "Qwen 7B Coder"
 *   "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"  -> "Llama 8B Instruct"
 *   "deepseek-coder-1.3b-instruct.Q8_0"       -> "DeepSeek 1.3B Coder"
 *   "Phi-3-mini-4k-instruct-q4"               -> "Phi Mini Instruct"
 *   "my-custom-model-q4_k_m"                  -> "My Custom Model"
 *
 * Never throws: on any unexpected input it falls back to the trimmed original.
 */
fun friendlyModelName(raw: String?): String {
  val original = raw?.trim().orEmpty()
  if (original.isEmpty()) return original
  return runCatching { alias(original) }.getOrNull()?.takeIf { it.isNotBlank() } ?: original
}

private val FAMILIES: List<Pair<String, String>> = listOf(
  // Longer / more specific keys first so "codellama" wins over "llama".
  "codellama" to "Code Llama",
  "code-llama" to "Code Llama",
  "tinyllama" to "TinyLlama",
  "codegemma" to "CodeGemma",
  "codestral" to "Codestral",
  "starcoder" to "StarCoder",
  "deepseek" to "DeepSeek",
  "mixtral" to "Mixtral",
  "mistral" to "Mistral",
  "smollm" to "SmolLM",
  "granite" to "Granite",
  "stablelm" to "StableLM",
  "falcon" to "Falcon",
  "gemma" to "Gemma",
  "llama" to "Llama",
  "qwen" to "Qwen",
  "phi" to "Phi",
  "yi-" to "Yi"
)

private val SEP = Regex("[-_ .:/]+")
private val QUANT_TOKEN = Regex("^(i?q\\d+(_[a-z0-9]+)*|f16|f32|bf16|fp16|fp32|gguf|ggml|k|m|s|l|xs|xxs)$")
private val SIZE = Regex("(?:^|[-_ :/])((?:\\d+x)?\\d+(?:\\.\\d+)?)([bm])(?=$|[-_ .:/])")
private val PHI_SIZE = Regex("(?:^|[-_ ])(mini|small|medium)(?=$|[-_ ])")

private fun alias(input: String): String {
  // Drop any directory and the .gguf/.bin extension.
  var name = input.substringAfterLast('/').substringAfterLast('\\')
  for (ext in listOf(".gguf", ".bin", ".ggml")) {
    if (name.endsWith(ext, ignoreCase = true)) name = name.dropLast(ext.length)
  }
  if (name.isBlank()) return input
  val lower = name.lowercase()

  val family = FAMILIES.firstOrNull { (key, _) -> lower.contains(key) }?.second

  val size = SIZE.find(lower)?.let { m ->
    val num = m.groupValues.getOrNull(1).orEmpty()
    val unit = m.groupValues.getOrNull(2).orEmpty().uppercase()
    if (num.isEmpty()) null else num.uppercase().replace("X", "x") + unit
  } ?: PHI_SIZE.find(lower)?.groupValues?.getOrNull(1)?.replaceFirstChar { it.uppercase() }

  val familyHasCode = family?.contains("Code", ignoreCase = true) == true
  val tag = when {
    !familyHasCode && (lower.contains("coder") || Regex("(?:^|[-_ ])code(?=$|[-_ ])").containsMatchIn(lower)) -> "Coder"
    Regex("(?:^|[-_ ])r1(?=$|[-_ ])").containsMatchIn(lower) -> "R1"
    lower.contains("math") -> "Math"
    lower.contains("vision") || Regex("(?:^|[-_ ])vl(?=$|[-_ ])").containsMatchIn(lower) -> "Vision"
    lower.contains("instruct") || Regex("(?:^|[-_ ])it(?=$|[-_ ])").containsMatchIn(lower) -> "Instruct"
    lower.contains("chat") -> "Chat"
    else -> null
  }

  if (family != null) {
    return listOfNotNull(family, size, tag).joinToString(" ")
  }

  // Fallback: the file name without quantisation tokens, title-cased and shortened.
  val words = name.split(SEP)
    .filter { it.isNotBlank() && !QUANT_TOKEN.matches(it.lowercase()) }
    .map { w -> if (w.any { it.isDigit() }) w else w.lowercase().replaceFirstChar { it.uppercase() } }
  if (words.isEmpty()) return name
  val short = words.take(3).joinToString(" ")
  return if (short.length > 24) short.take(23).trimEnd() + "…" else short
}
