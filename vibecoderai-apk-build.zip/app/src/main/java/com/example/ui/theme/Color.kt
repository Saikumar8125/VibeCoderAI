package com.example.ui.theme

import androidx.compose.ui.graphics.Color

/** Set once per composition by [MyApplicationTheme]. The activity is recreated when the system theme changes. */
object Palette {
  @Volatile
  var dark: Boolean = true
}

private fun c(dark: Long, light: Long): Color = Color(if (Palette.dark) dark else light)

// Cupertino grouped surfaces. (Constant names kept so every screen picks the palette up.)
val ObsidianBackground: Color get() = c(0xFF000000, 0xFFF2F2F7)
val ObsidianSurface: Color get() = c(0xFF1C1C1E, 0xFFFFFFFF)
val ObsidianSurfaceVariant: Color get() = c(0xFF2C2C2E, 0xFFE9E9EE)
val ObsidianBorder: Color get() = c(0xFF38383A, 0xFFE5E5EA)

// iOS system blue
val CyberCyanPrimary: Color get() = c(0xFF0A84FF, 0xFF007AFF)
val CyberCyanContainer: Color get() = c(0xFF0A2A4D, 0xFFD6E8FF)
val CyberOnCyan: Color get() = Color.White

val CyberVioletSecondary: Color get() = c(0xFF5E5CE6, 0xFF5856D6)
val CyberVioletContainer: Color get() = c(0xFF25244D, 0xFFE4E3FA)

// System green / orange / red
val CyberGreenSuccess: Color get() = c(0xFF30D158, 0xFF34C759)
val CyberGreenContainer: Color get() = c(0xFF12301B, 0xFFD9F5E0)

val CyberAmberWarning: Color get() = c(0xFFFF9F0A, 0xFFFF9500)
val CyberAmberContainer: Color get() = c(0xFF3A2A0A, 0xFFFFEBCC)

val CyberCoralError: Color get() = c(0xFFFF453A, 0xFFFF3B30)
val CyberCoralContainer: Color get() = c(0xFF3D1512, 0xFFFFDAD7)

// Labels
val TextPrimary: Color get() = c(0xFFFFFFFF, 0xFF000000)
val TextSecondary: Color get() = c(0xFFAEAEB2, 0xFF6C6C70)
val TextMuted: Color get() = Color(0xFF8E8E93)

// Code and diffs
val CodeBackground: Color get() = c(0xFF111113, 0xFFF5F5F7)
val DiffAddedBg: Color get() = c(0xFF14261C, 0xFFE3F6E8)
val DiffRemovedBg: Color get() = c(0xFF2B181B, 0xFFFDE6E4)
val DiffAddedText: Color get() = c(0xFF8FD6A1, 0xFF1E7B34)
val DiffRemovedText: Color get() = c(0xFFF0A0A8, 0xFFC4281C)
