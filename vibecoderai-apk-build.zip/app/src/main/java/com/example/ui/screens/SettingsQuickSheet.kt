package com.example.ui.screens

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.Skills
import com.example.data.model.SettingsState
import com.example.ui.components.Button
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Keys of the Settings rows whose right-hand value opens a quick-details sheet (v1.2). */
internal object QuickSheetKeys {
  const val APPEARANCE = "appearance"
  const val OUTPUT = "output"
  const val AGENT = "agent"
  const val SKILLS = "skills"
  const val MEMORY = "memory"
  const val DATA = "data"

  fun title(key: String): String = when (key) {
    APPEARANCE -> "Appearance"
    OUTPUT -> "Output and generation"
    AGENT -> "Agent"
    SKILLS -> "Agent skills"
    MEMORY -> "Memory"
    else -> "Data and diagnostics"
  }
}

/**
 * v1.2: quick details for a Settings value, shown in a Material 3 modal bottom sheet.
 * [onOpenFull] closes the sheet (animated) and then opens the full settings page for [key].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SettingsQuickSheet(
  key: String,
  settings: SettingsState,
  appVersion: String,
  onToggleSkill: (com.example.agent.Skill, Boolean) -> Unit = { s, on -> Skills.setEnabled(s, on) },
  onOpenFull: (String) -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  // Guards against a double tap on "Open" running the close-then-navigate sequence twice.
  var closing by remember { mutableStateOf(false) }

  fun closeThen(after: () -> Unit) {
    if (closing) return
    closing = true
    scope.launch { sheetState.hide() }.invokeOnCompletion {
      onDismiss()
      after()
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    // v1.2.1: frosted glass sheet with a hairline top rim and a subtle handle.
    modifier = Modifier.border(
      1.dp,
      com.example.ui.components.GlassPopupColors.rim(),
      androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ),
    shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (com.example.ui.theme.Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 16.dp)
        .navigationBarsPadding(),
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      Text(QuickSheetKeys.title(key), color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(6.dp))
      when (key) {
        QuickSheetKeys.MEMORY -> MemoryDetails(settings)
        QuickSheetKeys.SKILLS -> SkillsDetails(onToggleSkill)
        else -> SummaryDetails(key, settings, appVersion)
      }
      Spacer(Modifier.height(12.dp))
      Button(
        onClick = { closeThen { onOpenFull(key) } },
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      ) {
        Text("Open ${QuickSheetKeys.title(key)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
      }
    }
  }
}

@Composable
private fun DetailRow(label: String, value: String, hint: String? = null) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth().heightIn(min = 36.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(label, color = TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
      Text(
        value,
        color = TextSecondary,
        fontSize = 15.sp,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 12.dp)
      )
    }
    if (hint != null) Text(hint, color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp)
    Box(Modifier.fillMaxWidth().padding(top = 4.dp).height(0.5.dp).background(ObsidianBorder))
  }
}

private data class MemorySnapshot(
  val heapUsedMb: Long,
  val heapTotalMb: Long,
  val heapMaxMb: Long,
  val nativeAllocMb: Long,
  val nativeHeapMb: Long,
  val pssMb: Long?,
  val deviceAvailMb: Long?,
  val deviceTotalMb: Long?,
  val lowMemory: Boolean
)

private fun readMemory(context: Context): MemorySnapshot {
  val rt = Runtime.getRuntime()
  val mb = 1024L * 1024L
  val pss = runCatching {
    val mi = Debug.MemoryInfo()
    Debug.getMemoryInfo(mi)
    mi.totalPss.toLong() / 1024L // KB -> MB
  }.getOrNull()
  val device = runCatching {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
  }.getOrNull()
  return MemorySnapshot(
    heapUsedMb = (rt.totalMemory() - rt.freeMemory()) / mb,
    heapTotalMb = rt.totalMemory() / mb,
    heapMaxMb = rt.maxMemory() / mb,
    nativeAllocMb = Debug.getNativeHeapAllocatedSize() / mb,
    nativeHeapMb = Debug.getNativeHeapSize() / mb,
    pssMb = pss,
    deviceAvailMb = device?.availMem?.div(mb),
    deviceTotalMb = device?.totalMem?.div(mb),
    lowMemory = device?.lowMemory == true
  )
}

@Composable
private fun MemoryDetails(settings: SettingsState) {
  val context = LocalContext.current
  var refresh by remember { mutableIntStateOf(0) }
  var snap by remember { mutableStateOf<MemorySnapshot?>(null) }
  LaunchedEffect(refresh) {
    // Debug.getMemoryInfo can take a few ms, so read off the main thread.
    snap = withContext(Dispatchers.Default) {
      if (refresh > 0) System.gc()
      readMemory(context.applicationContext)
    }
  }
  val modelFile = remember(settings.customModelPath) {
    settings.customModelPath?.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { runCatching { it.isFile }.getOrDefault(false) }
  }
  val s = snap
  if (s == null) {
    Text("Reading memory…", color = TextMuted, fontSize = 13.sp)
  } else {
    DetailRow("App total (PSS)", s.pssMb?.let { "$it MB" } ?: "n/a", "Everything this app holds in RAM right now.")
    DetailRow("JVM heap used", "${s.heapUsedMb} of ${s.heapMaxMb} MB", "Allocated ${s.heapTotalMb} MB so far.")
    DetailRow("Native heap", "${s.nativeAllocMb} MB", "Native heap size ${s.nativeHeapMb} MB (llama.cpp buffers, KV cache).")
    DetailRow(
      "Model file",
      when {
        settings.backendMode == "remote" -> "Remote"
        modelFile != null -> "${modelFile.length() / (1024L * 1024L)} MB"
        else -> "None"
      },
      if (modelFile != null && settings.backendMode != "remote") "Memory-mapped while loaded; counted in PSS only for pages in use." else null
    )
    if (s.deviceAvailMb != null && s.deviceTotalMb != null) {
      DetailRow(
        "Device free",
        "${s.deviceAvailMb} of ${s.deviceTotalMb} MB",
        if (s.lowMemory) "The system reports low memory." else null
      )
    }
  }
  TextButton(onClick = { refresh++ }) {
    Text("Free RAM and refresh", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun SkillsDetails(onToggle: (com.example.agent.Skill, Boolean) -> Unit) {
  // Reading Skills.version makes this list recompose when a skill is switched.
  val skills = Skills.version.let { Skills.all() }
  val haptics = com.example.ui.components.rememberHaptics()
  if (skills.isEmpty()) {
    Text("No skills yet.", color = TextMuted, fontSize = 13.sp)
    return
  }
  val on = skills.count { Skills.isEnabled(it) }
  Text("$on of ${skills.size} active", color = TextMuted, fontSize = 13.sp)
  skills.forEach { skill ->
    Row(
      modifier = Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(Modifier.weight(1f)) {
        Text(skill.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(skill.description, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      Switch(
        checked = Skills.isEnabled(skill),
        onCheckedChange = { haptics.tick(); onToggle(skill, it) },
        colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White)
      )
    }
  }
}

@Composable
private fun SummaryDetails(key: String, settings: SettingsState, appVersion: String) {
  when (key) {
    QuickSheetKeys.APPEARANCE -> {
      DetailRow("Theme", when (settings.themeMode) { "light" -> "Light"; "dark" -> "Dark (OLED)"; else -> "System" })
      DetailRow("Glass blur", if (settings.glassBlur) "On" else "Off", "Blur needs Android 12 or newer.")
    }
    QuickSheetKeys.OUTPUT -> {
      val level = com.example.data.model.OutputLevel.from(settings.outputLevel)
      DetailRow("Output level", level.label)
      DetailRow("Context window", "${settings.contextLength} tokens")
      DetailRow("Max output", "${settings.maxOutputTokens} tokens")
      DetailRow("Temperature", "%.2f".format(settings.temperature))
      DetailRow("CPU threads", "${settings.cpuThreads}")
      DetailRow("Thinking", if (settings.thinking) "On" else "Off")
    }
    QuickSheetKeys.AGENT -> {
      DetailRow("Mode", if (settings.autonomous) "Autonomous" else "Manual",
        if (settings.autonomous) "The agent applies changes and runs tools on its own." else "You approve each change.")
      DetailRow("Role", com.example.agent.AgentRoles.from(settings.agentRole).name)
      DetailRow("Ask before destructive", if (settings.requireApprovalForDestructive) "On" else "Off")
      DetailRow("Rebuild after patch", if (settings.autoRebuildAfterPatch) "On" else "Off")
      DetailRow("Max repair attempts", "${settings.maxRepairRetries}")
    }
    else -> {
      DetailRow("Version", appVersion)
      DetailRow("Backend", if (settings.backendMode == "remote") "Remote server" else "On-device (llama.cpp)")
      val model = if (settings.backendMode == "remote") settings.remoteModel
      else settings.customModelPath?.let { File(it).name }.orEmpty()
      DetailRow("Model", com.example.ui.components.friendlyModelName(model).ifBlank { "None" }, model.takeIf { it.isNotBlank() })
      DetailRow("Android", "API ${android.os.Build.VERSION.SDK_INT}")
    }
  }
}
