package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import com.example.ui.components.pressScale
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.llama.LlamaBridge
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

private fun listModels(dir: File): List<File> =
  dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
    ?.sortedBy { it.name.lowercase() }
    ?: emptyList()

private fun importModel(context: Context, uri: Uri, dir: File): Result<File> = runCatching {
  val resolver = context.contentResolver
  var name = "model.gguf"
  var size = -1L
  resolver.query(uri, null, null, null, null)?.use { c ->
    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    val si = c.getColumnIndex(OpenableColumns.SIZE)
    if (c.moveToFirst()) {
      if (ni >= 0) name = c.getString(ni) ?: name
      if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
    }
  }
  name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
  if (!name.endsWith(".gguf", ignoreCase = true)) {
    throw IllegalArgumentException("Please pick a .gguf model file.")
  }
  dir.mkdirs()
  if (size > 0 && dir.usableSpace < size + 64L * 1024 * 1024) {
    throw IllegalStateException("Not enough free storage for this model.")
  }

  val tmp = File(dir, "$name.part")
  val dest = File(dir, name)
  try {
    val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open the selected file.")
    input.use { ins -> FileOutputStream(tmp).use { out -> ins.copyTo(out, 1 shl 20) } }

    val magic = ByteArray(4)
    tmp.inputStream().use { it.read(magic) }
    if (String(magic, Charsets.US_ASCII) != "GGUF") {
      throw IllegalArgumentException("This file is not a valid GGUF model.")
    }
    if (dest.exists()) dest.delete()
    if (!tmp.renameTo(dest)) throw IOException("Could not save the model file.")
  } finally {
    if (tmp.exists()) tmp.delete()
  }
  dest
}

private fun formatSize(bytes: Long): String =
  if (bytes >= 1_000_000_000L) "%.2f GB".format(bytes / 1_000_000_000.0) else "${bytes / 1_000_000} MB"

@Composable
fun ModelManagerCard(
  modelsDir: File,
  currentPath: String?,
  modelLoaded: Boolean,
  modelStatus: String?,
  onSelectModel: (String?) -> Unit,
  refreshKey: Int = 0
) {
  val context = LocalContext.current
  val deviceRam = remember {
    val mi = android.app.ActivityManager.MemoryInfo()
    (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
    mi.totalMem.coerceAtLeast(1L).toDouble()
  }
  val scope = rememberCoroutineScope()
  var files by remember(refreshKey) { mutableStateOf(listModels(modelsDir)) }
  var importing by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf<String?>(null) }

  val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (uri != null) {
      importing = true
      message = "Importing model... this can take a minute for large files."
      scope.launch {
        val result = withContext(Dispatchers.IO) { importModel(context, uri, modelsDir) }
        importing = false
        files = listModels(modelsDir)
        result
          .onSuccess { f ->
            message = "Imported ${f.name}"
            onSelectModel(f.absolutePath)
          }
          .onFailure { e -> message = e.message ?: "Import failed" }
      }
    }
  }

  val statusColor = when {
    !LlamaBridge.isNativeLoaded -> CyberCoralError
    modelLoaded -> CyberGreenSuccess
    else -> CyberAmberWarning
  }
  val loading = LlamaBridge.isNativeLoaded && !modelLoaded && currentPath != null && modelStatus?.startsWith("Loading") == true
  val statusText = when {
    !LlamaBridge.isNativeLoaded -> "Engine failed to load: ${LlamaBridge.nativeLoadError ?: "unknown error"}"
    modelLoaded -> "Ready"
    loading -> "Loading into memory. Large models can take a minute."
    else -> modelStatus ?: "No model selected"
  }
  val activeName = files.firstOrNull { it.absolutePath == currentPath }?.name

  com.example.ui.components.GroupedSection(
    "Offline model",
    footer = "Tip: 1.5B to 3B models at Q4 give the fastest replies on most phones."
  ) {
    // Active model summary
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
      Box(
        modifier = Modifier.size(10.dp).clip(CircleShape).background(statusColor)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(activeName ?: "No model selected", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(statusText, color = statusColor, fontSize = 12.sp)
      }
    }
    if (loading) {
      androidx.compose.material3.LinearProgressIndicator(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp).clip(CircleShape),
        color = CyberCyanPrimary,
        trackColor = ObsidianSurfaceVariant
      )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(CyberCyanPrimary)
        .clickable(enabled = !importing) { picker.launch(arrayOf("*/*")) }
        .pressScale()
        .padding(vertical = 12.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(if (importing) "Importing..." else "Import GGUF model", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
    message?.let {
      Text(it, color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
    Spacer(modifier = Modifier.height(6.dp))

    if (files.isEmpty()) {
      Text(
        "No models yet. Download one below, or import a .gguf file. Recommended: Qwen2.5-Coder 1.5B or 3B Instruct, Q4.",
        color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
      )
    }

    files.forEachIndexed { idx, f ->
      val isSelected = f.absolutePath == currentPath
      val ratio = f.length().toDouble() / deviceRam
      val (fit, fitColor) = when {
        ratio > 0.5 -> "Too big: very slow" to CyberCoralError
        ratio > 0.3 -> "Heavy: slower replies" to CyberAmberWarning
        ratio < 0.2 -> "Fast" to CyberGreenSuccess
        else -> "Good fit" to CyberGreenSuccess
      }
      if (idx > 0) Box(Modifier.fillMaxWidth().height(0.5.dp).background(ObsidianSurfaceVariant))
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .clickable { onSelectModel(f.absolutePath) }
          .padding(vertical = 10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(if (isSelected) CyberCyanPrimary else Color.Transparent)
            .border(1.5.dp, if (isSelected) CyberCyanPrimary else TextMuted, CircleShape),
          contentAlignment = Alignment.Center
        ) { if (isSelected) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            f.name.removeSuffix(".gguf"),
            color = if (isSelected) CyberCyanPrimary else TextPrimary,
            fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2
          )
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            Text(formatSize(f.length()), color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Text(fit, color = fitColor, fontSize = 12.sp, fontWeight = FontWeight.Medium)
          }
        }
        IconButton(onClick = {
          val wasSelected = isSelected
          f.delete()
          files = listModels(modelsDir)
          if (wasSelected) onSelectModel(null)
        }) {
          Icon(Icons.Default.Delete, contentDescription = "Delete ${f.name}", tint = CyberCoralError, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}
