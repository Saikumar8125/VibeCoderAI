package com.example.ui.components

import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** True when the user turned animations off (Developer options / Accessibility "Remove animations"). */
@Composable
fun rememberReducedMotion(): Boolean {
  val context = LocalContext.current
  return remember(context) {
    runCatching {
      Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }.getOrDefault(false)
  }
}

/**
 * Claude-style live status text: a soft highlight band sweeps left to right across the letters
 * (~1.7 s sweep + short pause, linear). The animated value is read only in the draw phase, so the
 * text never recomposes per frame. When [active] is false (or animations are off) this is a plain
 * static [Text] and no infinite transition exists.
 */
@Composable
fun ShimmerText(
  text: String,
  active: Boolean,
  modifier: Modifier = Modifier,
  color: Color = TextMuted,
  fontSize: TextUnit = TextUnit.Unspecified,
  fontWeight: FontWeight? = null,
  lineHeight: TextUnit = TextUnit.Unspecified,
  maxLines: Int = Int.MAX_VALUE,
  overflow: TextOverflow = TextOverflow.Clip,
  style: TextStyle = LocalTextStyle.current
) {
  val reduced = rememberReducedMotion()
  if (!active || reduced) {
    Text(text, modifier = modifier, color = color, fontSize = fontSize, fontWeight = fontWeight,
      lineHeight = lineHeight, maxLines = maxLines, overflow = overflow, style = style)
  } else {
    ShimmerActive(text, modifier, color, fontSize, fontWeight, lineHeight, maxLines, overflow, style)
  }
}

private const val SWEEP_MS = 1700
private const val CYCLE_MS = 2000

@Composable
private fun ShimmerActive(
  text: String,
  modifier: Modifier,
  color: Color,
  fontSize: TextUnit,
  fontWeight: FontWeight?,
  lineHeight: TextUnit,
  maxLines: Int,
  overflow: TextOverflow,
  style: TextStyle
) {
  val transition = rememberInfiniteTransition(label = "shimmer")
  val progress: State<Float> = transition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = keyframes {
        durationMillis = CYCLE_MS
        0f at 0 using LinearEasing
        1f at SWEEP_MS // hold at 1 (band off-screen) for the pause
      },
      repeatMode = RepeatMode.Restart
    ),
    label = "shimmerProgress"
  )
  val highlight = if (Palette.dark) Color.White.copy(alpha = 0.95f) else Color.Black
  Text(
    text,
    color = color,
    fontSize = fontSize,
    fontWeight = fontWeight,
    lineHeight = lineHeight,
    maxLines = maxLines,
    overflow = overflow,
    style = style,
    modifier = modifier
      .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
      .drawWithContent {
        drawContent()
        val w = size.width
        val band = (w * 0.35f).coerceAtLeast(1f)
        // Center travels from fully left of the text to fully right of it.
        val cx = -band + (w + 2 * band) * progress.value
        drawRect(
          brush = Brush.linearGradient(
            colors = listOf(color, highlight, color),
            start = Offset(cx - band / 2f, 0f),
            end = Offset(cx + band / 2f, 0f),
            tileMode = TileMode.Clamp
          ),
          blendMode = BlendMode.SrcIn
        )
      }
  )
}

/** Small accent "sparkle dots" spinner shown left of live status text. Static dots when animations are off. */
@Composable
fun SparkleSpinner(modifier: Modifier = Modifier, size: Dp = 13.dp, color: Color = CyberAmberWarning) {
  if (rememberReducedMotion()) {
    Canvas(modifier.size(size)) { drawSparkle(color, 0f, 0f) }
    return
  }
  val transition = rememberInfiniteTransition(label = "sparkle")
  val angle = transition.animateFloat(
    0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "sparkleAngle"
  )
  val pulse = transition.animateFloat(
    0f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "sparklePulse"
  )
  Canvas(modifier.size(size)) { drawSparkle(color, angle.value, pulse.value) }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSparkle(color: Color, angle: Float, pulse: Float) {
  val c = center
  val r = size.minDimension * 0.34f
  val dotMax = size.minDimension * 0.13f
  rotate(angle, c) {
    for (i in 0 until 4) {
      val a = i * (PI / 2).toFloat()
      // Each dot pulses a quarter cycle after the previous one.
      val s = 0.5f + 0.5f * sin(((pulse + i / 4f) * 2 * PI).toFloat())
      drawCircle(
        color = color.copy(alpha = 0.45f + 0.55f * s),
        radius = dotMax * (0.6f + 0.4f * s),
        center = Offset(c.x + r * cos(a), c.y + r * sin(a))
      )
    }
    drawCircle(color = color.copy(alpha = 0.9f), radius = dotMax * 0.55f, center = c)
  }
}

/**
 * Crossfades a status line when its text changes: new line fades in and slides up 4 dp (~200 ms).
 * [contentKey] lets callers animate only on meaningful changes (e.g. phase), not on every token.
 */
@Composable
fun <T> StatusCrossfade(
  target: T,
  modifier: Modifier = Modifier,
  contentKey: (T) -> Any? = { it },
  content: @Composable (T) -> Unit
) {
  val reduced = rememberReducedMotion()
  val shift = with(LocalDensity.current) { 4.dp.roundToPx() }
  AnimatedContent(
    targetState = target,
    modifier = modifier,
    contentAlignment = Alignment.CenterStart,
    contentKey = contentKey,
    transitionSpec = {
      if (reduced) ContentTransform(EnterTransition.None, ExitTransition.None, sizeTransform = null)
      else (fadeIn(tween(200)) + slideInVertically(tween(200)) { shift }) togetherWith
        fadeOut(tween(150)) using SizeTransform(clip = false)
    },
    label = "statusCrossfade"
  ) { content(it) }
}
