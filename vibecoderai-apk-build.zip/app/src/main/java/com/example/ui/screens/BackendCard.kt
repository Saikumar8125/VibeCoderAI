package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.llama.RemoteClient
import com.example.ui.components.GroupedSection
import com.example.ui.components.pressScale
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Choose where the model runs: on this phone (GGUF) or on an OpenAI-compatible server (Ollama, llama-server, LM Studio). */
@Composable
fun BackendCard(settings: SettingsState, onUpdate: (SettingsState) -> Unit) {
  val haptics = rememberHaptics()
  val scope = rememberCoroutineScope()
  var testResult by remember { mutableStateOf<String?>(null) }
  var testing by remember { mutableStateOf(false) }
  val remote = settings.backendMode == "remote"
  val fieldShape = RoundedCornerShape(16.dp)

  ModelSurface {
    Row(
      modifier = Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).padding(4.dp)
    ) {
      listOf("local" to "On this phone", "remote" to "Remote server").forEach { (key, label) ->
        val sel = settings.backendMode == key
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(CircleShape)
            .background(if (sel) CyberCyanPrimary else Color.Transparent)
            .clickable { haptics.tick(); onUpdate(settings.copy(backendMode = key)) }
            .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .padding(vertical = 11.dp),
          contentAlignment = Alignment.Center
        ) { Text(label, color = if (sel) Color.White else TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
      }
    }
    Text(
      if (remote) "Uses a server you run (Ollama, LM Studio, llama-server). Needs the server running and reachable."
      else "Runs the downloaded GGUF model on this phone. Fully offline.",
      color = com.example.ui.theme.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
      fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(top = 12.dp)
    )
    if (remote) {
      Column(modifier = Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = settings.remoteUrl, onValueChange = { onUpdate(settings.copy(remoteUrl = it)) },
          label = { Text("Server URL") }, singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
          value = settings.remoteModel, onValueChange = { onUpdate(settings.copy(remoteModel = it)) },
          label = { Text("Model name (optional)") }, singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
          value = settings.remoteKey, onValueChange = { onUpdate(settings.copy(remoteKey = it)) },
          label = { Text("API key (optional)") }, singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth()
        )
        Text(
          "Examples: Ollama http://127.0.0.1:11434/v1 (a PC: http://PC-IP:11434/v1), llama-server :8080/v1, LM Studio :1234/v1.",
          color = TextMuted, fontSize = 12.5.sp, lineHeight = 17.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
        )
        PillButton(
          if (testing) "Testing..." else "Test connection",
          onClick = {
            haptics.tick()
            testing = true
            testResult = null
            scope.launch {
              testResult = withContext(Dispatchers.IO) { RemoteClient.test(settings.remoteUrl, settings.remoteKey) }
              testing = false
            }
          },
          primary = true, enabled = !testing, modifier = Modifier.fillMaxWidth()
        )
        testResult?.let {
          Text(it, color = if (it.startsWith("Connected")) CyberGreenSuccess else CyberCoralError, fontSize = 13.sp)
        }
      }
    }
  }
}
