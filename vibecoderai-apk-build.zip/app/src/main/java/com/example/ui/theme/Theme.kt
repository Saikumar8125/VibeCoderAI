package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AppShapes = Shapes(
  extraSmall = RoundedCornerShape(6.dp),
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(14.dp),
  large = RoundedCornerShape(18.dp),
  extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  // Must run before any content reads a palette colour.
  Palette.dark = darkTheme

  val scheme = if (darkTheme) {
    darkColorScheme(
      primary = CyberCyanPrimary, onPrimary = Color.White, primaryContainer = CyberCyanContainer,
      onPrimaryContainer = TextPrimary, secondary = CyberVioletSecondary, onSecondary = Color.White,
      secondaryContainer = CyberVioletContainer, onSecondaryContainer = TextPrimary,
      tertiary = CyberGreenSuccess, onTertiary = Color.White, tertiaryContainer = CyberGreenContainer,
      onTertiaryContainer = TextPrimary, background = ObsidianBackground, onBackground = TextPrimary,
      surface = ObsidianSurface, onSurface = TextPrimary, surfaceVariant = ObsidianSurfaceVariant,
      onSurfaceVariant = TextSecondary, outline = ObsidianBorder, error = CyberCoralError,
      onError = Color.White, errorContainer = CyberCoralContainer, onErrorContainer = TextPrimary
    )
  } else {
    lightColorScheme(
      primary = CyberCyanPrimary, onPrimary = Color.White, primaryContainer = CyberCyanContainer,
      onPrimaryContainer = TextPrimary, secondary = CyberVioletSecondary, onSecondary = Color.White,
      secondaryContainer = CyberVioletContainer, onSecondaryContainer = TextPrimary,
      tertiary = CyberGreenSuccess, onTertiary = Color.White, tertiaryContainer = CyberGreenContainer,
      onTertiaryContainer = TextPrimary, background = ObsidianBackground, onBackground = TextPrimary,
      surface = ObsidianSurface, onSurface = TextPrimary, surfaceVariant = ObsidianSurfaceVariant,
      onSurfaceVariant = TextSecondary, outline = ObsidianBorder, error = CyberCoralError,
      onError = Color.White, errorContainer = CyberCoralContainer, onErrorContainer = TextPrimary
    )
  }

  MaterialTheme(
    colorScheme = scheme,
    typography = Typography,
    shapes = AppShapes
  ) {
    androidx.compose.material3.ProvideTextStyle(
      androidx.compose.ui.text.TextStyle(fontFamily = Sans),
      content = content
    )
  }
}
