package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString

/** Small regex tokenizer. Good enough for chat code blocks; skips very large inputs. */
object SyntaxHighlighter {
  private val cComment: Color get() = if (com.example.ui.theme.Palette.dark) Color(0xFF6B7394) else Color(0xFF8E8E93)
  private val cString: Color get() = if (com.example.ui.theme.Palette.dark) Color(0xFF9ECE6A) else Color(0xFF1E7B34)
  private val cKeyword: Color get() = if (com.example.ui.theme.Palette.dark) Color(0xFFBB9AF7) else Color(0xFF9B2DB8)
  private val cNumber: Color get() = if (com.example.ui.theme.Palette.dark) Color(0xFFFF9E64) else Color(0xFFC25400)
  private val cTag: Color get() = if (com.example.ui.theme.Palette.dark) Color(0xFFF7768E) else Color(0xFFD70015)

  private const val MAX_CHARS = 20_000

  private val jsKeywords = "const let var function return if else for while do switch case break continue new class extends import export from default async await try catch finally throw typeof instanceof this null undefined true false of in"
  private val ktKeywords = "fun val var class object interface return if else when for while do break continue import package private public internal override suspend data sealed enum null true false is as in try catch finally throw this super companion"
  private val pyKeywords = "def class return if elif else for while break continue import from as try except finally raise with lambda None True False and or not in is pass yield async await"
  private val cKeywords = "int long float double char void bool const static struct class return if else for while do switch case break continue include define namespace using new delete public private nullptr true false auto"

  private fun kw(words: String) = "\\b(?:${words.trim().split(' ').joinToString("|")})\\b"

  private fun rules(lang: String): List<Pair<Regex, Color>>? {
    val l = lang.lowercase()
    return when (l) {
      "js", "javascript", "ts", "typescript", "jsx", "tsx", "json" -> listOf(
        Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/") to cComment,
        Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'|`(?:\\\\.|[^`\\\\])*`") to cString,
        Regex(kw(jsKeywords)) to cKeyword,
        Regex("\\b\\d+(?:\\.\\d+)?\\b") to cNumber
      )
      "kotlin", "kt", "java" -> listOf(
        Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/") to cComment,
        Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'") to cString,
        Regex(kw(ktKeywords)) to cKeyword,
        Regex("\\b\\d+(?:\\.\\d+)?[fFL]?\\b") to cNumber
      )
      "python", "py" -> listOf(
        Regex("#[^\\n]*") to cComment,
        Regex("\"\"\"[\\s\\S]*?\"\"\"|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'") to cString,
        Regex(kw(pyKeywords)) to cKeyword,
        Regex("\\b\\d+(?:\\.\\d+)?\\b") to cNumber
      )
      "c", "cpp", "c++", "h", "hpp" -> listOf(
        Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/") to cComment,
        Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'") to cString,
        Regex(kw(cKeywords)) to cKeyword,
        Regex("\\b\\d+(?:\\.\\d+)?[fFuUlL]*\\b") to cNumber
      )
      "html", "xml", "svg" -> listOf(
        Regex("<!--[\\s\\S]*?-->") to cComment,
        Regex("\"[^\"\\n]*\"|'[^'\\n]*'") to cString,
        Regex("</?[A-Za-z][A-Za-z0-9-]*|/?>") to cTag
      )
      "css" -> listOf(
        Regex("/\\*[\\s\\S]*?\\*/") to cComment,
        Regex("\"[^\"\\n]*\"|'[^'\\n]*'") to cString,
        Regex("[.#][A-Za-z_-][A-Za-z0-9_-]*") to cTag,
        Regex("[a-z-]+(?=\\s*:)") to cKeyword,
        Regex("#[0-9a-fA-F]{3,8}\\b|\\b\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|s|ms)?\\b") to cNumber
      )
      "sh", "bash", "shell", "gradle", "kts" -> listOf(
        Regex("#[^\\n]*|//[^\\n]*") to cComment,
        Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'[^'\\n]*'") to cString,
        Regex("\\b\\d+\\b") to cNumber
      )
      else -> null
    }
  }

  fun highlight(code: String, lang: String, base: Color): AnnotatedString {
    val rs = if (code.length > MAX_CHARS) null else rules(lang)
    if (rs == null) return AnnotatedString(code)
    // Earlier rules win on overlap (comments and strings first).
    val owner = arrayOfNulls<Color>(code.length)
    for ((re, color) in rs) {
      for (m in re.findAll(code)) {
        val range = m.range
        if (range.isEmpty() || owner[range.first] != null) continue
        for (i in range) if (owner[i] == null) owner[i] = color
      }
    }
    return buildAnnotatedString {
      var i = 0
      while (i < code.length) {
        val c = owner[i]
        var j = i + 1
        while (j < code.length && owner[j] == c) j++
        if (c == null) append(code.substring(i, j)) else {
          pushStyle(SpanStyle(color = c))
          append(code.substring(i, j))
          pop()
        }
        i = j
      }
    }
  }
}
