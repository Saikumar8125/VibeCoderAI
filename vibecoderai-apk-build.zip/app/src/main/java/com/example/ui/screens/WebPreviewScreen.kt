package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.build.ApkPackager
import com.example.data.model.Project
import com.example.ui.theme.CyberCoralContainer
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface ApkUi {
  object Idle : ApkUi
  object Working : ApkUi
  class Done(val file: File) : ApkUi
  class Failed(val message: String) : ApkUi
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPreviewScreen(
  project: Project,
  onBack: () -> Unit,
  onFixErrors: (String) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val errors = remember { mutableStateListOf<String>() }
  var webView by remember { mutableStateOf<WebView?>(null) }
  var apk by remember { mutableStateOf<ApkUi>(ApkUi.Idle) }
  val indexFile = File(project.rootDir, "index.html")

  DisposableEffect(Unit) {
    onDispose { webView?.destroy() }
  }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    Row(
      modifier = Modifier.fillMaxWidth().background(ObsidianSurface).padding(horizontal = 4.dp, vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
      }
      Text(
        text = project.name,
        color = TextPrimary,
        fontSize = 13.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.weight(1f)
      )
      TextButton(onClick = {
        errors.clear()
        webView?.reload()
      }) { Text("Reload", fontSize = 13.sp, color = TextSecondary) }
      Button(
        onClick = {
          apk = ApkUi.Working
          scope.launch {
            apk = withContext(Dispatchers.IO) {
              runCatching { ApkPackager.build(context, project.rootDir, project.name) }
                .fold({ ApkUi.Done(it) }, { ApkUi.Failed(it.message ?: it.javaClass.simpleName) })
            }
          }
        },
        enabled = apk !is ApkUi.Working && indexFile.isFile,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
      ) { Text("Build APK", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
    }

    if (errors.isNotEmpty()) {
      Row(
        modifier = Modifier.fillMaxWidth().background(CyberCoralContainer).padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${errors.size} JS error(s): ${errors.last()}",
          color = CyberCoralError,
          fontSize = 12.sp,
          maxLines = 2,
          modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { onFixErrors(errors.take(5).joinToString("\n")) }) {
          Text("Fix with AI", fontSize = 12.sp, color = CyberCoralError, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    if (!indexFile.isFile) {
      Text("index.html not found in this project.", color = TextMuted, modifier = Modifier.padding(16.dp))
    } else {
      AndroidView(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        factory = { ctx ->
          WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            if (com.example.ui.theme.Palette.dark) {
              // OLED black preview: let WebView darken pages that do not set their own colours.
              if (android.os.Build.VERSION.SDK_INT >= 33) {
                settings.isAlgorithmicDarkeningAllowed = true
              } else if (android.os.Build.VERSION.SDK_INT >= 29) {
                @Suppress("DEPRECATION")
                settings.forceDark = android.webkit.WebSettings.FORCE_DARK_ON
              }
              setBackgroundColor(android.graphics.Color.BLACK)
            }
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
              override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                  errors.add("${m.message()} (line ${m.lineNumber()})")
                }
                return true
              }
            }
            loadUrl("file://" + indexFile.absolutePath)
            webView = this
          }
        }
      )
    }
  }

  when (val state = apk) {
    ApkUi.Idle -> Unit
    ApkUi.Working -> AlertDialog(
      onDismissRequest = {},
      title = { Text("Building APK") },
      text = { Text("Packaging and signing on this phone...") },
      confirmButton = {}
    )
    is ApkUi.Done -> AlertDialog(
      onDismissRequest = { apk = ApkUi.Idle },
      title = { Text("APK ready") },
      text = { Text("${state.file.name} (${state.file.length() / 1024} KB). Installing replaces the previous app built from VibeCoderAI.") },
      confirmButton = {
        TextButton(onClick = {
          ApkPackager.install(context, state.file)
          apk = ApkUi.Idle
        }) { Text("Install") }
      },
      dismissButton = {
        TextButton(onClick = {
          ApkPackager.share(context, state.file)
          apk = ApkUi.Idle
        }) { Text("Share") }
      }
    )
    is ApkUi.Failed -> AlertDialog(
      onDismissRequest = { apk = ApkUi.Idle },
      title = { Text("Build failed") },
      text = { Text(state.message) },
      confirmButton = { TextButton(onClick = { apk = ApkUi.Idle }) { Text("OK") } }
    )
  }
}
