package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.IndicationNodeFactory
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.node.DelegatableNode
import androidx.compose.ui.node.DrawModifierNode
import kotlinx.coroutines.launch

/** Replaces the ripple with an iOS-like spring scale while the element is pressed. */
object PressScaleIndication : IndicationNodeFactory {
  override fun create(interactionSource: InteractionSource): DelegatableNode = PressScaleNode(interactionSource)

  override fun hashCode(): Int = -1

  override fun equals(other: Any?): Boolean = other === this
}

private class PressScaleNode(private val interactionSource: InteractionSource) : Modifier.Node(), DrawModifierNode {
  private val scale = Animatable(1f)

  override fun onAttach() {
    coroutineScope.launch {
      interactionSource.interactions.collect { interaction ->
        when (interaction) {
          is PressInteraction.Press -> launch {
            scale.animateTo(0.94f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh))
          }
          is PressInteraction.Release, is PressInteraction.Cancel -> launch {
            scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
          }
          else -> Unit
        }
      }
    }
  }

  override fun ContentDrawScope.draw() {
    scale(scale.value) {
      this@draw.drawContent()
    }
  }
}
