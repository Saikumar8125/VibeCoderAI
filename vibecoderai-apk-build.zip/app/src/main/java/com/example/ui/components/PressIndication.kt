package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.IndicationNodeFactory
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.node.CompositionLocalConsumerModifierNode
import androidx.compose.ui.node.DelegatableNode
import androidx.compose.ui.node.DrawModifierNode
import androidx.compose.ui.node.currentValueOf
import androidx.compose.ui.node.invalidateDraw
import androidx.compose.ui.platform.LocalView
import kotlinx.coroutines.launch

/**
 * App-wide press feedback, provided as LocalIndication so every `clickable` gets it:
 * an iOS-like spring scale, a soft opacity dip while pressed, and a light haptic tick
 * (View.performHapticFeedback(VIRTUAL_KEY), which honours the system touch-feedback setting)
 * when a tap is confirmed. Scroll gestures cancel the press, so scrolling never buzzes.
 */
object PressScaleIndication : IndicationNodeFactory {
  override fun create(interactionSource: InteractionSource): DelegatableNode = PressScaleNode(interactionSource)

  override fun hashCode(): Int = -1

  override fun equals(other: Any?): Boolean = other === this
}

private const val PRESSED_SCALE = 0.94f
private const val PRESSED_ALPHA = 0.78f

private class PressScaleNode(private val interactionSource: InteractionSource) :
  Modifier.Node(), DrawModifierNode, CompositionLocalConsumerModifierNode {
  private val scale = Animatable(1f)
  private val alpha = Animatable(1f)
  private val layerPaint = Paint()

  override fun onAttach() {
    coroutineScope.launch {
      interactionSource.interactions.collect { interaction ->
        when (interaction) {
          is PressInteraction.Press -> {
            launch { scale.animateTo(PRESSED_SCALE, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh)) }
            launch { alpha.animateTo(PRESSED_ALPHA, tween(90)) }
          }
          is PressInteraction.Release -> {
            runCatching {
              currentValueOf(LocalView).performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            }
            launch { scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }
            launch { alpha.animateTo(1f, tween(160)) }
          }
          is PressInteraction.Cancel -> {
            launch { scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }
            launch { alpha.animateTo(1f, tween(160)) }
          }
          else -> Unit
        }
        invalidateDraw()
      }
    }
  }

  override fun ContentDrawScope.draw() {
    val a = alpha.value
    scale(scale.value) {
      if (a >= 0.999f) {
        this@draw.drawContent()
      } else {
        // Opacity dip: draw the content into a translucent layer (shape-agnostic, so it never shows a square overlay).
        drawIntoCanvas { canvas ->
          layerPaint.alpha = a
          canvas.saveLayer(Rect(0f, 0f, size.width, size.height), layerPaint)
          this@draw.drawContent()
          canvas.restore()
        }
      }
    }
  }
}
