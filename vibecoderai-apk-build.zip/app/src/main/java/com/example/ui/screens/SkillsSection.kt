package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import com.example.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.Skills
import com.example.ui.components.GroupedSection
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/** Settings block: switch agent skills on or off and add your own. */
@Composable
fun SkillsSection() {
  val haptics = rememberHaptics()
  val skills = Skills.version.let { Skills.all() }
  var adding by remember { mutableStateOf(false) }

  GroupedSection(
    "Agent skills",
    footer = "Enabled skills are added to the model's instructions. Each one costs a few tokens, so keep only what you need."
  ) {
    skills.forEach { skill ->
      Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(Modifier.weight(1f)) {
          Text(skill.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
          Text(skill.description, color = TextMuted, fontSize = 12.sp)
        }
        if (!skill.builtIn) {
          TextButton(onClick = { Skills.deleteCustom(skill.id) }) {
            Text("Delete", color = CyberCoralError, fontSize = 13.sp)
          }
        }
        Switch(
          checked = Skills.isEnabled(skill),
          onCheckedChange = { haptics.tick(); Skills.setEnabled(skill, it) },
          colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White)
        )
      }
    }
    TextButton(onClick = { adding = true }) {
      Text("Add skill", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
    }
  }

  if (adding) {
    var name by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { adding = false },
      title = { Text("New skill") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
          OutlinedTextField(
            prompt, { prompt = it },
            label = { Text("Instructions for the model") },
            placeholder = { Text("e.g. Always add a dark mode toggle") },
            minLines = 3
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = name.isNotBlank() && prompt.isNotBlank(),
          onClick = { Skills.addCustom(name, prompt); adding = false }
        ) { Text("Add") }
      },
      dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
    )
  }
}
