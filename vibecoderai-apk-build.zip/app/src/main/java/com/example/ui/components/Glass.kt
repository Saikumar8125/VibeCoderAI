package com.example.ui.components

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow

/**
 * Real backdrop blur: the screen content is recorded into a layer, and glass surfaces draw a blurred
 * copy of the part of that layer that sits behind them. Blur needs Android 12+ (API 31); older
 * versions get a translucent surface only.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
  var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
  val layer = rememberGraphicsLayer()
  return remember(layer) { GlassState(layer) }
}

/** Marks the content that glass surfaces blur. [background] is painted into the layer so the blur is never transparent. */
fun Modifier.glassSource(state: GlassState, background: Color): Modifier = this
  .onGloballyPositioned { state.origin = it.positionInWindow() }
  .drawWithContent {
    state.layer.record {
      drawRect(background)
      this@drawWithContent.drawContent()
    }
    drawLayer(state.layer)
  }

fun Modifier.glassSurface(
  state: GlassState,
  shape: Shape,
  tint: Color,
  blurRadiusPx: Float = 60f
): Modifier = composed {
  var position by remember { mutableStateOf(Offset.Zero) }
  val blurLayer = rememberGraphicsLayer()
  val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
  remember(blurLayer, blurRadiusPx) {
    if (canBlur) {
      blurLayer.renderEffect = BlurEffect(blurRadiusPx, blurRadiusPx, TileMode.Clamp)
      blurLayer.clip = true
    }
    true
  }
  this
    .clip(shape)
    .onGloballyPositioned { position = it.positionInWindow() }
    .drawWithContent {
      if (canBlur) {
        val shift = position - state.origin
        blurLayer.record {
          translate(left = -shift.x, top = -shift.y) {
            drawLayer(state.layer)
          }
        }
        drawLayer(blurLayer)
      }
      drawRect(tint)
      drawContent()
    }
}
