package com.example.ui.components

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.layout.positionOnScreen

/**
 * Real backdrop blur: the screen content is recorded into a layer, and glass surfaces draw a blurred
 * copy of the part of that layer that sits behind them. Blur needs Android 12+ (API 31); older
 * versions get a translucent surface only.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
  var origin by mutableStateOf(Offset.Zero)
  /** Where the recorded content sits on the physical screen. Plain field (not state): read only at draw time by popups. */
  var screenOrigin: Offset = Offset.Zero
}

/** The main screen's glass layer, so popups/menus in their own windows can blur what is behind them. */
val LocalGlassState = androidx.compose.runtime.staticCompositionLocalOf<GlassState?> { null }

@Composable
fun rememberGlassState(): GlassState {
  val layer = rememberGraphicsLayer()
  return remember(layer) { GlassState(layer) }
}

/** Marks the content that glass surfaces blur. [background] is painted into the layer so the blur is never transparent. */
fun Modifier.glassSource(state: GlassState, background: Color): Modifier = this
  .onGloballyPositioned {
    state.origin = it.positionInWindow()
    state.screenOrigin = runCatching { it.positionOnScreen() }.getOrDefault(state.screenOrigin)
  }
  .drawWithContent {
    if (com.example.ui.theme.ThemeController.blurActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      state.layer.record {
        drawAmbient(background)
        this@drawWithContent.drawContent()
      }
      drawLayer(state.layer)
    } else {
      // Fast path: no offscreen layer.
      drawAmbient(background)
      drawContent()
    }
  }

fun Modifier.glassSurface(
  state: GlassState,
  shape: Shape,
  tint: Color,
  blurRadiusPx: Float = 60f
): Modifier = composed {
  var position by remember { mutableStateOf(Offset.Zero) }
  val blurLayer = rememberGraphicsLayer()
  val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && com.example.ui.theme.ThemeController.blurActive
  remember(blurLayer, blurRadiusPx, canBlur) {
    if (canBlur) {
      blurLayer.renderEffect = BlurEffect(blurRadiusPx, blurRadiusPx, TileMode.Clamp)
      // Apple "vibrancy": colours behind the glass get richer, not just blurrier.
      blurLayer.colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(1.7f) }
      )
      blurLayer.clip = true
    }
    true
  }
  this
    .clip(shape)
    .onGloballyPositioned { position = it.positionInWindow() }
    .drawWithContent {
      if (canBlur) {
        val shift = position - state.origin
        blurLayer.record {
          translate(left = -shift.x, top = -shift.y) {
            drawLayer(state.layer)
          }
        }
        drawLayer(blurLayer)
      }
      // Without blur the glass is more opaque so it stays readable over content.
      drawRect(if (canBlur) tint else tint.copy(alpha = (tint.alpha + 0.12f).coerceAtMost(0.80f)))
      drawContent()
    }
}

/** Soft colour blobs behind everything, so translucent glass has something to refract. */
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAmbient(background: Color) {
  drawRect(background)
  val dark = com.example.ui.theme.Palette.dark
  // OLED: dark mode is pure black, no colour glow, so pixels stay off.
  if (dark) return
  val a = 0.30f
  fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
    drawCircle(
      brush = androidx.compose.ui.graphics.Brush.radialGradient(
        colors = listOf(color.copy(alpha = alpha), Color.Transparent),
        center = Offset(size.width * cx, size.height * cy),
        radius = size.width * r
      ),
      radius = size.width * r,
      center = Offset(size.width * cx, size.height * cy)
    )
  }
  blob(Color(0xFF0A84FF), 0.05f, 0.08f, 0.75f, a)
  blob(Color(0xFFBF5AF2), 1.00f, 0.42f, 0.65f, a * 0.75f)
  blob(Color(0xFF64D2FF), 0.15f, 0.98f, 0.75f, a * 0.65f)
}

/** v1.2.1 frosted popup colours ("liquid glass" menus, sheets, dialogs). */
object GlassPopupColors {
  /** Body tint. [blurred] = a real backdrop blur is drawn under it, so it can be slightly lighter. */
  fun tint(blurred: Boolean): Color =
    if (com.example.ui.theme.Palette.dark) Color(0xFF202023).copy(alpha = if (blurred) 0.90f else 0.96f)
    else Color(0xFFFFFFFF).copy(alpha = if (blurred) 0.86f else 0.96f)

  /** Solid-ish colour for Material containers (sheets, dialogs) that live in their own window. */
  val container: Color get() = tint(blurred = false)

  /** 1dp specular hairline: brighter on top, fading toward the bottom. */
  fun rim(): androidx.compose.ui.graphics.Brush =
    if (com.example.ui.theme.Palette.dark) androidx.compose.ui.graphics.Brush.verticalGradient(
      listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))
    ) else androidx.compose.ui.graphics.Brush.verticalGradient(
      listOf(Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.10f))
    )

  val divider: Color get() =
    if (com.example.ui.theme.Palette.dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.08f)

  val shadow: Color get() =
    Color.Black.copy(alpha = if (com.example.ui.theme.Palette.dark) 0.60f else 0.18f)
}

/**
 * Frosted "liquid glass" surface for content in its own window (Popup, dropdown).
 *
 * Android 12+ with blur on: draws a blurred, saturated copy of the main screen's glass layer
 * ([LocalGlassState]), shifted by this surface's on-screen position minus the main content's, so it is a
 * real backdrop blur even though the popup is a separate window. Nothing extra is recorded per frame:
 * it reuses the layer the main window already records, and the blur runs only when this surface draws
 * (popups only redraw while animating). A high-opacity tint is always painted on top, so the text stays
 * readable when blur is unavailable (older Android, blur off, busy, or the layer is not recorded).
 */
fun Modifier.glassPopupSurface(
  shape: Shape,
  elevation: androidx.compose.ui.unit.Dp = 24.dp,
  blurRadiusPx: Float = 56f
): Modifier = composed {
  val state = LocalGlassState.current
  val canBlur = state != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
    com.example.ui.theme.ThemeController.blurActive
  val blurLayer = rememberGraphicsLayer()
  remember(blurLayer, blurRadiusPx, canBlur) {
    if (canBlur) {
      blurLayer.renderEffect = BlurEffect(blurRadiusPx, blurRadiusPx, TileMode.Clamp)
      blurLayer.colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(1.6f) }
      )
      blurLayer.clip = true
    }
    true
  }
  // Holder, not state: positions are read at draw time and never trigger recomposition.
  val coords = remember { arrayOfNulls<androidx.compose.ui.layout.LayoutCoordinates>(1) }
  val tint = GlassPopupColors.tint(canBlur)
  val rim = GlassPopupColors.rim()
  val shadowColor = GlassPopupColors.shadow
  this
    .shadow(elevation, shape, clip = false, ambientColor = shadowColor, spotColor = shadowColor)
    .clip(shape)
    .onGloballyPositioned { coords[0] = it }
    .drawWithContent {
      if (canBlur && state != null && !state.layer.isReleased) {
        val c = coords[0]
        if (c != null && c.isAttached) {
          val here = runCatching { c.positionOnScreen() }.getOrNull()
          if (here != null) {
            val shift = here - state.screenOrigin
            blurLayer.record {
              translate(left = -shift.x, top = -shift.y) { drawLayer(state.layer) }
            }
            drawLayer(blurLayer)
          }
        }
      }
      drawRect(tint)
      drawContent()
    }
    .border(1.dp, rim, shape)
}
