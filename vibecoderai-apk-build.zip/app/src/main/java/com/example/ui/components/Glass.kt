package com.example.ui.components

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow

/**
 * Real backdrop blur: the screen content is recorded into a layer, and glass surfaces draw a blurred
 * copy of the part of that layer that sits behind them. Blur needs Android 12+ (API 31); older
 * versions get a translucent surface only.
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
  var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
  val layer = rememberGraphicsLayer()
  return remember(layer) { GlassState(layer) }
}

/** Marks the content that glass surfaces blur. [background] is painted into the layer so the blur is never transparent. */
fun Modifier.glassSource(state: GlassState, background: Color): Modifier = this
  .onGloballyPositioned { state.origin = it.positionInWindow() }
  .drawWithContent {
    if (com.example.ui.theme.ThemeController.blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      state.layer.record {
        drawAmbient(background)
        this@drawWithContent.drawContent()
      }
      drawLayer(state.layer)
    } else {
      // Fast path: no offscreen layer.
      drawAmbient(background)
      drawContent()
    }
  }

fun Modifier.glassSurface(
  state: GlassState,
  shape: Shape,
  tint: Color,
  blurRadiusPx: Float = 60f
): Modifier = composed {
  var position by remember { mutableStateOf(Offset.Zero) }
  val blurLayer = rememberGraphicsLayer()
  val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && com.example.ui.theme.ThemeController.blur
  remember(blurLayer, blurRadiusPx, canBlur) {
    if (canBlur) {
      blurLayer.renderEffect = BlurEffect(blurRadiusPx, blurRadiusPx, TileMode.Clamp)
      // Apple "vibrancy": colours behind the glass get richer, not just blurrier.
      blurLayer.colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(1.7f) }
      )
      blurLayer.clip = true
    }
    true
  }
  this
    .clip(shape)
    .onGloballyPositioned { position = it.positionInWindow() }
    .drawWithContent {
      if (canBlur) {
        val shift = position - state.origin
        blurLayer.record {
          translate(left = -shift.x, top = -shift.y) {
            drawLayer(state.layer)
          }
        }
        drawLayer(blurLayer)
      }
      // Without blur the glass is more opaque so it stays readable over content.
      drawRect(if (canBlur) tint else tint.copy(alpha = (tint.alpha + 0.12f).coerceAtMost(0.80f)))
      drawContent()
    }
}

/** Soft colour blobs behind everything, so translucent glass has something to refract. */
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAmbient(background: Color) {
  drawRect(background)
  val dark = com.example.ui.theme.Palette.dark
  // OLED: dark mode is pure black, no colour glow, so pixels stay off.
  if (dark) return
  val a = 0.30f
  fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
    drawCircle(
      brush = androidx.compose.ui.graphics.Brush.radialGradient(
        colors = listOf(color.copy(alpha = alpha), Color.Transparent),
        center = Offset(size.width * cx, size.height * cy),
        radius = size.width * r
      ),
      radius = size.width * r,
      center = Offset(size.width * cx, size.height * cy)
    )
  }
  blob(Color(0xFF0A84FF), 0.05f, 0.08f, 0.75f, a)
  blob(Color(0xFFBF5AF2), 1.00f, 0.42f, 0.65f, a * 0.75f)
  blob(Color(0xFF64D2FF), 0.15f, 0.98f, 0.75f, a * 0.65f)
}
