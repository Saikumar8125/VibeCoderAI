package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.llama.RemoteClient
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** v1.4.3: per-server model list cache, so reopening the picker is instant. Key = url. */
internal object RemoteModelCache {
  val lists = mutableMapOf<String, List<String>>()
}

/** Ids that are not chat models (speech, TTS, embeddings, guards, images). Hidden unless searched. */
private val NON_CHAT = Regex("whisper|tts|embed|guard|moderation|dall-e|playai|orpheus|transcribe|speech|image|rerank|distil-whisper", RegexOption.IGNORE_CASE)

/**
 * v1.4.3: pick the remote model from chat. Fetches GET {url}/models with the saved key
 * (Groq, OpenRouter, Gemini, OpenAI, Ollama, LM Studio...) and saves the choice as remoteModel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ModelPickerSheet(
  settings: SettingsState,
  onPick: (String) -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  val remote = settings.backendMode == "remote"
  var models by remember { mutableStateOf(RemoteModelCache.lists[settings.remoteUrl]) }
  var error by remember { mutableStateOf<String?>(null) }
  var loading by remember { mutableStateOf(false) }
  var query by remember { mutableStateOf("") }
  var reload by remember { mutableIntStateOf(0) }

  LaunchedEffect(reload) {
    if (!remote || settings.remoteUrl.isBlank()) return@LaunchedEffect
    if (models != null && reload == 0) return@LaunchedEffect
    loading = true
    error = null
    val result = withContext(Dispatchers.IO) {
      runCatching { RemoteClient.models(settings.remoteUrl, settings.remoteKey).distinct().sorted() }
    }
    result.onSuccess {
      models = it
      RemoteModelCache.lists[settings.remoteUrl] = it
    }.onFailure { error = it.message ?: it.javaClass.simpleName }
    loading = false
  }

  fun pick(id: String) {
    scope.launch { sheetState.hide() }.invokeOnCompletion {
      onPick(id)
      onDismiss()
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    modifier = Modifier.border(
      1.dp,
      com.example.ui.components.GlassPopupColors.rim(),
      RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (com.example.ui.theme.Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .padding(bottom = 12.dp)
        .navigationBarsPadding()
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
          Text("Choose model", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          val host = runCatching { java.net.URL(settings.remoteUrl).host }.getOrNull().orEmpty()
          if (remote && host.isNotBlank()) Text(host, color = TextMuted, fontSize = 12.5.sp)
        }
        if (remote) {
          Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).clickable(enabled = !loading) { reload++ },
            contentAlignment = Alignment.Center
          ) { Icon(Icons.Default.Refresh, contentDescription = "Reload models", tint = TextSecondary) }
        }
      }
      Spacer(Modifier.height(10.dp))

      if (!remote) {
        Text(
          "You're running models on this phone. To pick an API model, open Models, choose \"Remote server\" and save your API key.",
          color = TextSecondary, fontSize = 14.sp, lineHeight = 20.sp
        )
        Spacer(Modifier.height(16.dp))
        return@Column
      }

      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text("Search models") },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CyberCyanPrimary,
          unfocusedBorderColor = ObsidianBorder,
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          cursorColor = CyberCyanPrimary
        ),
        modifier = Modifier.fillMaxWidth()
      )
      Spacer(Modifier.height(8.dp))

      when {
        loading && models == null -> Row(
          Modifier.fillMaxWidth().padding(vertical = 28.dp),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = CyberCyanPrimary)
          Spacer(Modifier.width(10.dp))
          Text("Loading models…", color = TextSecondary, fontSize = 14.sp)
        }
        error != null && models == null -> Column(Modifier.padding(vertical = 16.dp)) {
          Text("Couldn't load models", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
          Text(error.orEmpty().take(200), color = TextMuted, fontSize = 13.sp)
          Spacer(Modifier.height(6.dp))
          Text("Check the server URL and API key in Models, then tap reload.", color = TextSecondary, fontSize = 13.sp)
        }
        else -> {
          val all = models.orEmpty()
          val q = query.trim()
          val shown = if (q.isEmpty()) all.filterNot { NON_CHAT.containsMatchIn(it) }
          else all.filter { it.contains(q, ignoreCase = true) }
          val current = settings.remoteModel.trim()
          LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
            item {
              ModelRow(
                title = "Auto",
                sub = "Server's first model",
                selected = current.isBlank()
              ) { pick("") }
            }
            items(shown, key = { it }) { id ->
              ModelRow(
                title = com.example.ui.components.friendlyModelName(id).ifBlank { id },
                sub = id,
                selected = id == current
              ) { pick(id) }
            }
            if (shown.isEmpty()) item {
              Text(
                if (q.isEmpty()) "The server lists no chat models." else "No model matches \"$q\".",
                color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 14.dp)
              )
            }
          }
          if (all.isNotEmpty()) Text(
            "${all.size} models on this server",
            color = TextMuted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 6.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun ModelRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(if (selected) CyberCyanPrimary.copy(alpha = 0.12f) else Color.Transparent)
      .clickable(onClick = onClick)
      .heightIn(min = 52.dp)
      .padding(horizontal = 12.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(Modifier.weight(1f)) {
      Text(
        title, color = if (selected) CyberCyanPrimary else TextPrimary, fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
      )
      if (sub != title) Text(sub, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    if (selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = CyberCyanPrimary, modifier = Modifier.size(20.dp))
  }
}
