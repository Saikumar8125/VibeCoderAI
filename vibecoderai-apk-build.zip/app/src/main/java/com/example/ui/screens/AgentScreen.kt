package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.graphics.Brush
import com.example.data.model.OutputLevel
import com.example.data.model.withLevel
import com.example.ui.components.rememberHaptics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.FileBlocks
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.project.ProjectManager
import com.example.project.createBlankWebProject
import com.example.project.createFromTemplate
import androidx.compose.foundation.horizontalScroll
import com.example.ui.components.DiffViewer
import com.example.ui.components.FileChangesCard
import com.example.ui.components.MarkdownText
import com.example.ui.components.PatchApprovalDialog
import com.example.ui.components.TelemetryBar
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.components.pressScale
import com.example.ui.components.liquidGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val SUGGESTIONS = listOf(
  "Build a todo list with local storage",
  "Build a scientific calculator",
  "Build a pomodoro timer with sound",
  "Build an expense tracker with a bar chart"
)

@Composable
fun AgentScreen(
  orchestrator: AgentOrchestrator,
  projectManager: ProjectManager,
  activeProject: Project?,
  settings: SettingsState,
  onPreview: () -> Unit,
  onOpenBuild: () -> Unit = {},
  onOpenHistory: () -> Unit = {},
  onSettingsChange: (SettingsState) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val messages by orchestrator.messages.collectAsState()
  val telemetry by orchestrator.telemetry.collectAsState()
  val pendingPatch by orchestrator.pendingPatch.collectAsState()
  val isGenerating by orchestrator.isGenerating.collectAsState()
  val activity by orchestrator.activity.collectAsState()

  var inputText by remember { mutableStateOf("") }
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  val writtenCount = messages.count { m -> m.fileChanges.any { it.status == com.example.data.model.ChangeStatus.APPLIED } }
  val canPreview = remember(activeProject?.id, writtenCount) {
    activeProject != null && File(activeProject.rootDir, "index.html").isFile
  }

  val chat = messages.drop(1) // the welcome message is replaced by the hero screen
  val level = OutputLevel.from(settings.outputLevel)
  LaunchedEffect(chat.size) {
    if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
  }
  LaunchedEffect(chat.lastOrNull()?.content?.length) {
    if (isGenerating && chat.isNotEmpty()) listState.scrollToItem(chat.lastIndex, 100_000)
  }

  pendingPatch?.let { patch ->
    if (activeProject != null) {
      PatchApprovalDialog(
        proposal = patch,
        onApprove = { orchestrator.approveAndApplyPatch(patch, activeProject, scope) },
        onReject = { orchestrator.rejectPatch(patch) }
      )
    }
  }

  val context = androidx.compose.ui.platform.LocalContext.current
  var attachment by remember { mutableStateOf<Pair<String, String>?>(null) }

  val filePicker = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
  ) { uri: android.net.Uri? ->
    if (uri != null) {
      scope.launch {
        val loaded = withContext(Dispatchers.IO) {
          runCatching {
            var name = "file"
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
              val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
              if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: name
            }
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
            val text = String(bytes, Charsets.UTF_8)
            if (text.contains('\u0000')) error("This looks like a binary file.")
            val clipped = if (text.length > MAX_ATTACH_CHARS) text.take(MAX_ATTACH_CHARS) + "\n[truncated]" else text
            name to clipped
          }
        }
        loaded
          .onSuccess { attachment = it }
          .onFailure { android.widget.Toast.makeText(context, it.message ?: "Could not read the file", android.widget.Toast.LENGTH_SHORT).show() }
      }
    }
  }

  val voiceLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val spoken = result.data
      ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
      ?.firstOrNull()
    if (!spoken.isNullOrBlank()) inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
  }

  fun startVoice() {
    val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
      putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Describe your app")
    }
    try {
      voiceLauncher.launch(intent)
    } catch (e: android.content.ActivityNotFoundException) {
      android.widget.Toast.makeText(context, "No speech recognizer is installed on this phone.", android.widget.Toast.LENGTH_LONG).show()
    }
  }

  fun submit(raw: String) {
    val text = raw.trim()
    if (text.isEmpty() || isGenerating) return
    val file = attachment
    inputText = ""
    attachment = null
    scope.launch {
      val wantsBuild = com.example.agent.Intent.classify(text) == com.example.agent.Intent.Mode.BUILD
      val builder = settings.agentRole == "builder"
      val project = if (activeProject == null || (builder && wantsBuild && !orchestrator.useActiveProject)) {
        withContext(Dispatchers.IO) { projectManager.createBlankWebProject(text) }
      } else activeProject
      if (wantsBuild) orchestrator.useActiveProject = true
      if (file == null) {
        orchestrator.sendMessage(text, project, settings, scope)
      } else {
        val modelText = "Attached file ${file.first}:\n```\n${file.second}\n```\n\n$text"
        orchestrator.sendMessage(modelText, project, settings, scope, displayText = "$text\n[Attached: ${file.first}]")
      }
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
  ) {
    val subtitle = when {
      isGenerating && telemetry.outputTokens == 0 -> "Reading prompt · ${telemetry.inputTokens} tokens"
      isGenerating -> "Writing · ${"%.1f".format(telemetry.tokensPerSecond)} tok/s"
      else -> (if (settings.backendMode == "remote") "Remote" else "Offline") + " · ${com.example.agent.AgentRoles.from(settings.agentRole).name} · ${level.label}"
    }
    var menuOpen by remember { mutableStateOf(false) }
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      GlassIconButton(Icons.Default.History, "History", onOpenHistory)
      Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
        Text(
          activeProject?.name ?: "VibeCoder",
          color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
          maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
        Text(subtitle, color = TextMuted, fontSize = 12.sp, maxLines = 1)
      }
      if (canPreview) {
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(CyberCyanPrimary)
            .clickable { onPreview() }
            .pressScale()
            .padding(horizontal = 14.dp, vertical = 9.dp)
        ) { Text("Preview", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
      }
      if (messages.size > 1 && !isGenerating) {
        GlassIconButton(Icons.Default.Edit, "New chat") { orchestrator.newChat() }
      }
      Box {
        GlassIconButton(Icons.Default.MoreVert, "More") { menuOpen = true }
        androidx.compose.material3.DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
          androidx.compose.material3.DropdownMenuItem(
            text = { Text("Build and APK") },
            onClick = { menuOpen = false; onOpenBuild() }
          )
        }
      }
    }

    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
      contentPadding = PaddingValues(vertical = 8.dp)
    ) {
      items(chat, key = { it.id }, contentType = { it.sender }) { message ->
        Box {
        MessageItem(
          message = message,
          telemetry = telemetry,
          canPreview = canPreview,
          onApply = { if (activeProject != null) orchestrator.applyChanges(message.id, activeProject, scope) },
          onDiscard = { orchestrator.discardChanges(message.id) },
          onPreview = onPreview,
          isLast = message.id == chat.lastOrNull()?.id,
          isBusy = isGenerating,
          canUndo = orchestrator.canUndo(message.id),
          onUndo = { if (activeProject != null) orchestrator.undoChanges(message.id, activeProject) },
          onRegenerate = { orchestrator.regenerate(activeProject, settings, scope) },
          onApplyPatch = { patch ->
            if (activeProject != null) orchestrator.approveAndApplyPatch(patch, activeProject, scope)
          }
        )
        }
      }
      if (chat.isEmpty() && !isGenerating) {
        item {
          Column(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF0A84FF), Color(0xFF5E5CE6)))),
              contentAlignment = Alignment.Center
            ) { Text("</>", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) }
            Text("What shall we build?", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp)
            Text("Runs fully offline on this phone.", color = TextMuted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Text("START FROM A TEMPLATE", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.align(Alignment.Start).padding(start = 4.dp))
            com.example.project.Templates.all.chunked(2).forEach { pair ->
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { t ->
                  Column(
                    modifier = Modifier
                      .weight(1f)
                      .liquidGlass(RoundedCornerShape(20.dp), 6.dp)
                      .clickable {
                        scope.launch {
                          withContext(Dispatchers.IO) { projectManager.createFromTemplate(t) }
                          orchestrator.useActiveProject = true
                          orchestrator.addNote("Created the \"${t.name}\" project. Tap Preview to run it, or tell me what to change.")
                        }
                      }
                      .pressScale()
                      .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                  ) {
                    Text(t.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(t.blurb, color = TextMuted, fontSize = 12.sp, maxLines = 2)
                  }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
              }
            }
            Spacer(Modifier.height(4.dp))
            Text("OR TRY", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.align(Alignment.Start).padding(start = 4.dp))
            SUGGESTIONS.forEach { sug ->
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .liquidGlass(RoundedCornerShape(18.dp), 4.dp)
                  .clickable { submit(sug) }
                  .pressScale()
                  .padding(horizontal = 16.dp, vertical = 13.dp)
              ) { Text(sug, color = TextPrimary, fontSize = 14.sp) }
            }
          }
        }
      }
    }

    if (isGenerating && activity.isNotEmpty()) ActivityFeed(activity)

    if (inputText.isEmpty()) Row(
      modifier = Modifier
        .horizontalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      com.example.agent.AgentRoles.all.forEach { r ->
        val sel = settings.agentRole == r.id
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(if (sel) CyberCyanPrimary else ObsidianSurfaceVariant)
            .clickable { onSettingsChange(settings.copy(agentRole = r.id)) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) { Text(r.name, color = if (sel) Color.White else TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
      }
    }

    if (canPreview && !isGenerating && messages.size > 1 && inputText.isEmpty()) {
      Row(
        modifier = Modifier
          .horizontalScroll(androidx.compose.foundation.rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("Make it responsive", "Add dark mode", "Improve the design", "Fix errors", "Add animations").forEach { q ->
          Box(
            modifier = Modifier
              .clip(CircleShape)
              .background(ObsidianSurfaceVariant)
              .clickable { submit(q) }
              .padding(horizontal = 12.dp, vertical = 7.dp)
          ) { Text(q, color = TextSecondary, fontSize = 12.sp) }
        }
      }
    }

    attachment?.let { (name, _) ->
      Row(
        modifier = Modifier
          .padding(horizontal = 16.dp)
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(name, color = TextPrimary, fontSize = 12.sp, maxLines = 1)
        IconButton(onClick = { attachment = null }, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Remove attachment", tint = TextMuted, modifier = Modifier.size(14.dp))
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .liquidGlass(RoundedCornerShape(28.dp), 8.dp)
        .padding(6.dp),
      verticalAlignment = Alignment.Bottom
    ) {
      IconButton(
        onClick = { filePicker.launch(arrayOf("*/*")) },
        modifier = Modifier.size(40.dp).pressScale()
      ) {
        Icon(Icons.Default.Add, contentDescription = "Attach a text or code file", tint = TextSecondary)
      }
      Box(modifier = Modifier.weight(1f).padding(start = 2.dp, end = 6.dp, top = 10.dp, bottom = 10.dp)) {
        if (inputText.isEmpty()) Text("Describe an app or ask a question", color = TextMuted, fontSize = 16.sp)
        androidx.compose.foundation.text.BasicTextField(
          value = inputText,
          onValueChange = { inputText = it },
          textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 16.sp, lineHeight = 22.sp),
          cursorBrush = androidx.compose.ui.graphics.SolidColor(CyberCyanPrimary),
          maxLines = 5,
          modifier = Modifier.fillMaxWidth()
        )
      }
      Box(
        modifier = Modifier
          .padding(bottom = 6.dp, end = 6.dp)
          .clip(CircleShape)
          .background(if (settings.thinking) CyberCyanPrimary else ObsidianSurfaceVariant)
          .clickable { onSettingsChange(settings.copy(thinking = !settings.thinking)) }
          .padding(horizontal = 10.dp, vertical = 6.dp)
      ) { Text("Think", color = if (settings.thinking) Color.White else TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
      var levelMenu by remember { mutableStateOf(false) }
      Box(modifier = Modifier.padding(bottom = 6.dp)) {
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(ObsidianSurfaceVariant)
            .clickable { levelMenu = true }
            .padding(horizontal = 10.dp, vertical = 6.dp)
        ) { Text(level.label + " ▾", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
        if (levelMenu) {
          LevelPicker(
            current = level,
            onPick = { onSettingsChange(settings.withLevel(it)) },
            onDismiss = { levelMenu = false }
          )
        }
      }
      Spacer(modifier = Modifier.width(6.dp))
      val showMic = !isGenerating && inputText.isBlank()
      IconButton(
        onClick = {
          if (isGenerating) orchestrator.stop() else if (showMic) startVoice() else submit(inputText)
        },
        colors = IconButtonDefaults.iconButtonColors(
          containerColor = if (showMic) ObsidianSurfaceVariant else CyberCyanPrimary,
          contentColor = if (showMic) CyberCyanPrimary else Color.White
        ),
        modifier = Modifier.size(40.dp).pressScale()
      ) {
        Icon(
          imageVector = when {
            isGenerating -> Icons.Default.Stop
            showMic -> Icons.Default.Mic
            else -> Icons.AutoMirrored.Filled.Send
          },
          contentDescription = when {
            isGenerating -> "Stop"
            showMic -> "Voice input"
            else -> "Send"
          }
        )
      }
    }
  }
}

@Composable
private fun GlassIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
  val haptics = rememberHaptics()
  Box(
    modifier = Modifier
      .size(40.dp)
      .liquidGlass(CircleShape, 4.dp)
      .clickable { haptics.tick(); onClick() }
      .pressScale(),
    contentAlignment = Alignment.Center
  ) { Icon(icon, contentDescription = description, tint = TextPrimary, modifier = Modifier.size(20.dp)) }
}

private const val MAX_ATTACH_CHARS = 6000

@Composable
private fun MessageItem(
  message: ChatMessage,
  telemetry: TelemetryData,
  canPreview: Boolean,
  onApply: () -> Unit,
  onDiscard: () -> Unit,
  onPreview: () -> Unit,
  isLast: Boolean,
  isBusy: Boolean,
  canUndo: Boolean,
  onUndo: () -> Unit,
  onRegenerate: () -> Unit,
  onApplyPatch: (com.example.data.model.PatchProposal) -> Unit
) {
  when (message.sender) {
    MessageSender.USER -> Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
      Box(
        modifier = Modifier
          .widthIn(max = 300.dp)
          .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
          .background(CyberCyanPrimary)
          .padding(horizontal = 14.dp, vertical = 9.dp)
      ) {
        val long = message.content.length > 400
        var expanded by remember(message.id) { mutableStateOf(false) }
        Column {
          Text(
            if (long && !expanded) message.content.take(400).trimEnd() + "…" else message.content,
            color = Color.White, fontSize = 14.sp, lineHeight = 20.sp
          )
          if (long) {
            Text(
              if (expanded) "Show less" else "Show more",
              color = Color.White.copy(alpha = 0.75f),
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier
                .padding(top = 4.dp)
                .clickable { expanded = !expanded }
            )
          }
        }
      }
    }

    MessageSender.AGENT -> if (message.thoughts == "note") {
      NoteLine(message.content)
    } else Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      message.reasoning?.takeIf { it.isNotBlank() }?.let { ThinkingBox(it, message.isStreaming && message.content.isBlank()) }
      val full = remember(message.content) { FileBlocks.displayText(message.content) }
      // Trailing "[Stopped...]" / "[Error...]" markers become a small caption instead of looking like model text.
      val tagStart = remember(full) {
        val i = full.lastIndexOf("[")
        if (i >= 0 && full.trimEnd().endsWith("]") && (full.startsWith("[", i) && (full.substring(i).startsWith("[Stopped") || full.substring(i).startsWith("[Error") || full.substring(i).startsWith("[The model") || full.substring(i).startsWith("[No progress")))) i else -1
      }
      val shown = if (tagStart >= 0) full.substring(0, tagStart).trimEnd() else full
      val tag = if (tagStart >= 0) full.substring(tagStart).trim().removePrefix("[").removeSuffix("]") else null
      if (shown.isNotEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth(0.94f)
            .clip(RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp))
            .background(ObsidianSurfaceVariant.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 11.dp)
        ) { MarkdownText(shown) }
      }
      if (tag != null) {
        val isErr = tag.startsWith("Error") || tag.startsWith("No progress")
        Row(
          modifier = Modifier
            .clip(CircleShape)
            .background((if (isErr) com.example.ui.theme.CyberCoralError else TextMuted).copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(tag, color = if (isErr) com.example.ui.theme.CyberCoralError else TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
        }
      }
      if (message.isStreaming) StatusLine(telemetry)
      if (!message.isStreaming && message.content.isNotBlank()) {
        val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(start = 6.dp)) {
          Text("Copy", fontSize = 12.sp, color = TextMuted, modifier = Modifier.clickable { clipboard.setText(androidx.compose.ui.text.AnnotatedString(message.content)) }.padding(vertical = 4.dp))
          if (isLast && !isBusy) {
            Text("Regenerate", fontSize = 12.sp, color = TextMuted, modifier = Modifier.clickable { onRegenerate() }.padding(vertical = 4.dp))
          }
          if (canUndo) {
            Text("Undo changes", fontSize = 12.sp, color = CyberCyanPrimary, modifier = Modifier.clickable { onUndo() }.padding(vertical = 4.dp))
          }
        }
      }
      if (message.fileChanges.isNotEmpty()) {
        FileChangesCard(
          changes = message.fileChanges,
          canPreview = canPreview,
          onApply = onApply,
          onDiscard = onDiscard,
          onPreview = onPreview
        )
      }
      message.patchProposal?.let { patch ->
        Text(patch.relativePath, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        DiffViewer(diffLines = patch.diffLines)
        if (!patch.isApplied) {
          Button(
            onClick = { onApplyPatch(patch) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
          ) { Text("Apply patch", fontSize = 13.sp) }
        }
      }
    }

    else -> {
      val label = message.toolCall?.let { "${it.toolName} · ${it.status}" } ?: message.content
      Text(label, color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
  }
}

@Composable
private fun StatusLine(t: TelemetryData) {
  val text = if (t.outputTokens == 0) {
    "Reading prompt · ${t.inputTokens} tokens"
  } else {
    "Writing · ${"%.1f".format(t.tokensPerSecond)} tok/s"
  }
  Row(verticalAlignment = Alignment.CenterVertically) {
    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = TextMuted)
    Spacer(modifier = Modifier.width(8.dp))
    Text(text, color = TextMuted, fontSize = 12.sp)
  }
}

/** Rounded glass popup above the level pill: springs in from the pill, fades out when closed. */
@Composable
private fun LevelPicker(current: OutputLevel, onPick: (OutputLevel) -> Unit, onDismiss: () -> Unit) {
  val state = remember { androidx.compose.animation.core.MutableTransitionState(false).apply { targetState = true } }
  val haptics = rememberHaptics()
  androidx.compose.runtime.LaunchedEffect(state.currentState, state.targetState) {
    if (!state.targetState && !state.currentState) onDismiss()
  }
  val provider = remember {
    object : androidx.compose.ui.window.PopupPositionProvider {
      override fun calculatePosition(
        anchorBounds: androidx.compose.ui.unit.IntRect,
        windowSize: androidx.compose.ui.unit.IntSize,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        popupContentSize: androidx.compose.ui.unit.IntSize
      ): androidx.compose.ui.unit.IntOffset {
        val x = (anchorBounds.right - popupContentSize.width).coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
        val y = (anchorBounds.top - popupContentSize.height - 16).coerceAtLeast(0)
        return androidx.compose.ui.unit.IntOffset(x, y)
      }
    }
  }
  androidx.compose.ui.window.Popup(
    popupPositionProvider = provider,
    onDismissRequest = { state.targetState = false },
    properties = androidx.compose.ui.window.PopupProperties(focusable = true)
  ) {
    androidx.compose.animation.AnimatedVisibility(
      visibleState = state,
      enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)) +
        androidx.compose.animation.scaleIn(
          animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 420f),
          initialScale = 0.78f,
          transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 1f)
        ),
      exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(110)) +
        androidx.compose.animation.scaleOut(
          animationSpec = androidx.compose.animation.core.tween(130),
          targetScale = 0.85f,
          transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 1f)
        )
    ) {
      Column(
        modifier = Modifier
          .padding(14.dp)
          .width(270.dp)
          .liquidGlass(RoundedCornerShape(28.dp), 18.dp)
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        OutputLevel.values().forEach { l ->
          val sel = l == current
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(20.dp))
              .background(if (sel) CyberCyanPrimary.copy(alpha = 0.18f) else Color.Transparent)
              .clickable {
                haptics.tick()
                onPick(l)
                state.targetState = false
              }
              .pressScale()
              .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(Modifier.weight(1f)) {
              Text(l.label, color = if (sel) CyberCyanPrimary else TextPrimary, fontSize = 16.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Medium)
              Text(l.blurb, color = TextMuted, fontSize = 12.sp)
            }
            if (sel) Icon(androidx.compose.material.icons.Icons.Default.Check, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}

/** Progress notes from the agent (plan, steps, test results): quiet status text, not a chat bubble. */
@Composable
private fun NoteLine(text: String) {
  Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.Top) {
    Box(
      modifier = Modifier
        .padding(top = 7.dp, end = 10.dp)
        .size(6.dp)
        .clip(CircleShape)
        .background(CyberCyanPrimary.copy(alpha = 0.8f))
    )
    Text(text, color = TextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
  }
}


/** Collapsible model reasoning (<think> text). Open while the model is still thinking. */
@Composable
private fun ThinkingBox(text: String, streaming: Boolean) {
  var open by remember { mutableStateOf(false) }
  val show = open || streaming
  Column(
    modifier = Modifier
      .fillMaxWidth(0.94f)
      .clip(RoundedCornerShape(16.dp))
      .background(ObsidianSurfaceVariant.copy(alpha = 0.5f))
      .clickable { open = !open }
      .padding(horizontal = 12.dp, vertical = 8.dp)
      .animateContentSize()
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(if (streaming) "Thinking…" else "Thought process", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
      Text(if (show) "Hide" else "Show", color = TextMuted, fontSize = 12.sp)
    }
    if (show) Text(text, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 6.dp))
  }
}

/** Live "what is the agent doing now" strip. Tap to see the recent steps. */
@Composable
private fun ActivityFeed(lines: List<String>) {
  var open by remember { mutableStateOf(false) }
  val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
    initialValue = 0.3f, targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha"
  )
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 4.dp)
      .liquidGlass(RoundedCornerShape(18.dp), 4.dp)
      .clickable { open = !open }
      .padding(horizontal = 14.dp, vertical = 9.dp)
      .animateContentSize()
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(Modifier.size(8.dp).graphicsLayer { alpha = pulse }.clip(CircleShape).background(CyberCyanPrimary))
      Spacer(Modifier.width(10.dp))
      Text(lines.last(), color = TextPrimary, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
      Text(if (open) "Hide" else "${lines.size} steps", color = TextMuted, fontSize = 12.sp)
    }
    if (open) {
      Column(modifier = Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        lines.takeLast(12).dropLast(1).asReversed().forEach {
          Text("✓ $it", color = TextMuted, fontSize = 12.sp, maxLines = 1)
        }
      }
    }
  }
}
