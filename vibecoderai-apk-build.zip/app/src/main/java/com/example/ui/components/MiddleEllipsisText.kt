package com.example.ui.components

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.TextUnit

// v1.4: splitFileExtension / middleEllipsize moved to TextEllipsis.kt (pure, unit tested).

/**
 * v1.2: single-line text that, when too wide, cuts the middle of a file name and keeps its extension
 * visible ("build.gra…dle.kts" style). Measured once per (text, width, style) with a TextMeasurer and a
 * binary search, so scrolling a file tree does not re-measure every frame.
 */
@Composable
fun MiddleEllipsisText(
  text: String,
  modifier: Modifier = Modifier,
  color: Color = Color.Unspecified,
  fontSize: TextUnit = TextUnit.Unspecified,
  fontFamily: FontFamily? = null,
  fontWeight: FontWeight? = null
) {
  val measurer = rememberTextMeasurer()
  val style: TextStyle = LocalTextStyle.current.merge(
    TextStyle(color = color, fontSize = fontSize, fontFamily = fontFamily, fontWeight = fontWeight)
  )
  BoxWithConstraints(modifier = modifier) {
    val maxW = constraints.maxWidth
    val shown = remember(text, maxW, style) {
      if (text.isEmpty() || maxW == Constraints.Infinity || maxW <= 0) {
        text
      } else {
        fun fits(s: String): Boolean =
          measurer.measure(s, style, maxLines = 1, softWrap = false).size.width <= maxW
        if (fits(text)) {
          text
        } else {
          val (stem, ext) = splitFileExtension(text)
          if (stem.length < 2 || !fits(middleEllipsize(stem, ext, 0))) {
            text // Not even "…ext" fits: fall back to the normal end ellipsis below.
          } else {
            var lo = 0
            var hi = stem.length - 1
            while (lo < hi) {
              val mid = (lo + hi + 1) / 2
              if (fits(middleEllipsize(stem, ext, mid))) lo = mid else hi = mid - 1
            }
            middleEllipsize(stem, ext, lo)
          }
        }
      }
    }
    Text(
      text = shown,
      style = style,
      maxLines = 1,
      softWrap = false,
      overflow = TextOverflow.Ellipsis
    )
  }
}
