package com.example.ui.components

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.TextUnit

/** Compound extensions that are kept whole (checked before the plain last-dot extension). */
private val COMPOUND_EXTENSIONS = listOf(
  ".gradle.kts", ".d.ts", ".tar.gz", ".tar.xz", ".min.js", ".min.css",
  ".test.ts", ".test.js", ".spec.ts", ".spec.js", ".module.css"
)

/** Splits a file name into (stem, extension). The extension includes its dot; "" when there is none. */
internal fun splitFileExtension(name: String): Pair<String, String> {
  val lower = name.lowercase()
  COMPOUND_EXTENSIONS.firstOrNull { lower.endsWith(it) && name.length > it.length }?.let { ext ->
    return name.dropLast(ext.length) to name.takeLast(ext.length)
  }
  val dot = name.lastIndexOf('.')
  // No dot, a leading-dot file (".gitignore") or a very long "extension": treat it all as stem.
  if (dot <= 0 || name.length - dot > 10) return name to ""
  return name.substring(0, dot) to name.substring(dot)
}

/** Builds "head…tail.ext" keeping [keep] characters of the stem (60 % head, 40 % tail). */
internal fun middleEllipsize(stem: String, ext: String, keep: Int): String {
  val k = keep.coerceIn(0, stem.length)
  val head = ((k * 3 + 4) / 5).coerceIn(0, k)
  val tail = (k - head).coerceIn(0, stem.length - head)
  return stem.take(head) + "\u2026" + stem.takeLast(tail) + ext
}

/**
 * v1.2: single-line text that, when too wide, cuts the middle of a file name and keeps its extension
 * visible ("build.gra…dle.kts" style). Measured once per (text, width, style) with a TextMeasurer and a
 * binary search, so scrolling a file tree does not re-measure every frame.
 */
@Composable
fun MiddleEllipsisText(
  text: String,
  modifier: Modifier = Modifier,
  color: Color = Color.Unspecified,
  fontSize: TextUnit = TextUnit.Unspecified,
  fontFamily: FontFamily? = null,
  fontWeight: FontWeight? = null
) {
  val measurer = rememberTextMeasurer()
  val style: TextStyle = LocalTextStyle.current.merge(
    TextStyle(color = color, fontSize = fontSize, fontFamily = fontFamily, fontWeight = fontWeight)
  )
  BoxWithConstraints(modifier = modifier) {
    val maxW = constraints.maxWidth
    val shown = remember(text, maxW, style) {
      if (text.isEmpty() || maxW == Constraints.Infinity || maxW <= 0) {
        text
      } else {
        fun fits(s: String): Boolean =
          measurer.measure(s, style, maxLines = 1, softWrap = false).size.width <= maxW
        if (fits(text)) {
          text
        } else {
          val (stem, ext) = splitFileExtension(text)
          if (stem.length < 2 || !fits(middleEllipsize(stem, ext, 0))) {
            text // Not even "…ext" fits: fall back to the normal end ellipsis below.
          } else {
            var lo = 0
            var hi = stem.length - 1
            while (lo < hi) {
              val mid = (lo + hi + 1) / 2
              if (fits(middleEllipsize(stem, ext, mid))) lo = mid else hi = mid - 1
            }
            middleEllipsize(stem, ext, lo)
          }
        }
      }
    }
    Text(
      text = shown,
      style = style,
      maxLines = 1,
      softWrap = false,
      overflow = TextOverflow.Ellipsis
    )
  }
}
