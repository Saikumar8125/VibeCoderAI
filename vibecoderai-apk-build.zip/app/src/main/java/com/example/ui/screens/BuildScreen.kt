package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.example.ui.components.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.model.BuildResult
import com.example.data.model.BuildStatus
import com.example.data.model.CompilationError
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.ui.components.PatchApprovalDialog
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.CyberVioletSecondary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun BuildScreen(
  buildRunner: BuildRunner,
  selfRepairEngine: SelfRepairEngine,
  activeProject: Project?,
  onNavigateToAgent: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var buildResult by remember { mutableStateOf<BuildResult?>(null) }
  var isBuilding by remember { mutableStateOf(false) }
  val buildLogs = remember { mutableStateListOf<String>() }
  val logListState = rememberLazyListState()

  var pendingProposal by remember { mutableStateOf<PatchProposal?>(null) }

  LaunchedEffect(buildLogs.size) {
    if (buildLogs.isNotEmpty()) {
      logListState.animateScrollToItem(buildLogs.size - 1)
    }
  }

  // Surgical patch approval dialog
  pendingProposal?.let { patch ->
    if (activeProject != null) {
      PatchApprovalDialog(
        proposal = patch,
        onApprove = {
          scope.launch {
            val applied = selfRepairEngine.applyPatch(patch, activeProject)
            pendingProposal = null
            if (applied) {
              Toast.makeText(context, "Patch applied! Re-running build verification...", Toast.LENGTH_SHORT).show()
              // Re-run build verification
              isBuilding = true
              buildLogs.clear()
              val res = buildRunner.runBuild(activeProject) { log -> buildLogs.add(log) }
              buildResult = res
              isBuilding = false
            } else {
              Toast.makeText(context, "Failed to apply patch.", Toast.LENGTH_SHORT).show()
            }
          }
        },
        onReject = { pendingProposal = null }
      )
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
  ) {
    // Header status card
    Card(
      shape = RoundedCornerShape(0.dp),
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Build,
              contentDescription = null,
              tint = CyberCyanPrimary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Gradle Build Runner",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
          }

          if (activeProject != null) {
            val isGradle = buildRunner.isGradleProject(activeProject)
            Text(
              text = if (isGradle) "Gradle (AGP 9.1.1)" else "Standard Workspace",
              color = if (isGradle) CyberGreenSuccess else TextMuted,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (activeProject != null && !isBuilding) {
                isBuilding = true
                buildLogs.clear()
                scope.launch {
                  val res = buildRunner.runBuild(activeProject) { log -> buildLogs.add(log) }
                  buildResult = res
                  isBuilding = false
                }
              }
            },
            enabled = activeProject != null && !isBuilding,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("run_build_button")
          ) {
            if (isBuilding) {
              CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.White)
              Spacer(modifier = Modifier.width(6.dp))
              Text("Building...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            } else {
              Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Run Build / Compile", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }

          OutlinedButton(
            onClick = {
              activeProject?.let { proj ->
                val mainFile = File(proj.rootDir, "src/main/java/com/example/demo/MainActivity.kt")
                if (mainFile.exists()) {
                  val text = mainFile.readText()
                  if (!text.contains("TODO_BREAK_BUILD")) {
                    mainFile.writeText(text.replace("\"Welcome to \" + appName", "TODO_BREAK_BUILD"))
                    Toast.makeText(context, "Injected error into MainActivity.kt. Run build to test repair!", Toast.LENGTH_SHORT).show()
                  }
                }
              }
            },
            shape = RoundedCornerShape(6.dp)
          ) {
            Text("Simulate Bug", fontSize = 11.sp, color = TextMuted)
          }
        }
      }
    }

    // Build Artifact locator card
    buildResult?.apkPath?.let { apk ->
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.CyberGreenContainer),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(imageVector = Icons.Default.Android, contentDescription = null, tint = CyberGreenSuccess, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("Debug APK Generated Successfully", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(apk, color = Color(0xFF7EE787), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }

    // Parsed Compilation Errors section
    val errors = buildResult?.errors ?: emptyList()
    if (errors.isNotEmpty()) {
      Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = Color(0xFFF85149), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Compilation Errors (${errors.size})",
            color = Color(0xFFF85149),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.height(4.dp))

        errors.forEach { err ->
          Card(
            shape = RoundedCornerShape(6.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "${File(err.filePath).name}:${err.lineNumber}:${err.columnNumber}",
                  color = CyberCyanPrimary,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
                Button(
                  onClick = {
                    if (activeProject != null) {
                      val patch = selfRepairEngine.generateTargetedPatch(err, activeProject)
                      pendingProposal = patch
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberVioletSecondary, contentColor = Color.White),
                  shape = RoundedCornerShape(4.dp)
                ) {
                  Icon(imageVector = Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Self-Repair", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = err.errorMessage,
                color = Color(0xFFFFA198),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
              )
              if (err.snippet.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = ">>> ${err.snippet}",
                  color = TextMuted,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }
      }
    }

    // Streaming Log Output Console
    Column(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(12.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xFF101012))
        .padding(8.dp)
    ) {
      Text(
        text = "BUILD CONSOLE OUTPUT",
        color = TextMuted,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 4.dp)
      )

      LazyColumn(
        state = logListState,
        modifier = Modifier.fillMaxSize()
      ) {
        if (buildLogs.isEmpty()) {
          item {
            Text(
              text = "No active build. Click 'Run Build / Compile' to verify the workspace.",
              color = TextMuted,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        items(buildLogs) { logLine ->
          val color = when {
            logLine.contains("FAILED") || logLine.contains("error:") || logLine.startsWith("e:") -> Color(0xFFFFA198)
            logLine.contains("SUCCESSFUL") || logLine.contains("UP-TO-DATE") -> Color(0xFF7EE787)
            logLine.startsWith("> Task") -> CyberCyanPrimary
            else -> TextPrimary
          }
          Text(
            text = logLine,
            color = color,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 15.sp
          )
        }
      }
    }
  }
}
