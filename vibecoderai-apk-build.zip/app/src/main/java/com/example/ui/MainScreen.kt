package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.ui.layout.onSizeChanged
import com.example.ui.components.glassSource
import com.example.ui.components.glassSurface
import com.example.ui.components.rememberGlassState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.components.specularBrush
import com.example.ui.theme.Palette
import com.example.ui.components.rememberHaptics
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.SettingsStore
import com.example.data.model.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withTimeoutOrNull
import com.example.llama.LlamaBridge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.llama.LlamaEngine
import com.example.project.ProjectManager
import com.example.terminal.TerminalManager
import com.example.testing.TestRunnerEngine
import com.example.ui.screens.AgentScreen
import com.example.ui.screens.WebPreviewScreen
import com.example.ui.screens.BuildScreen
import com.example.ui.screens.ModelsScreen
import com.example.data.downloader.ModelDownloadManager
import com.example.data.local.ChatStore
import com.example.data.local.ChatSummary
import com.example.ui.screens.HistoryOverlay
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import com.example.ui.screens.ProjectScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.TestsScreen
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class AppDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  AGENT("Chat", Icons.Default.SmartToy),
  PROJECT("Projects", Icons.Default.Folder),
  MODELS("Models", Icons.Default.Memory),
  TERMINAL("Terminal", Icons.Default.Terminal),
  SETTINGS("Settings", Icons.Default.Settings),
  BUILD("Build", Icons.Default.Build)
}

@Composable
fun MainScreen() {
  val context = LocalContext.current

  // Shared instances
  val projectManager = remember { ProjectManager(context) }
  val terminalManager = remember { TerminalManager() }
  val buildRunner = remember { BuildRunner() }
  val selfRepairEngine = remember { SelfRepairEngine(buildRunner = buildRunner) }
  val testRunnerEngine = remember { TestRunnerEngine(context = context, buildRunner = buildRunner, terminalManager = terminalManager) }
  val llamaEngine = remember { LlamaEngine(context) }

  val settingsStore = remember { SettingsStore(context) }
  remember { com.example.agent.Skills.init(context) }
  val scope = rememberCoroutineScope()
  var settings by remember { mutableStateOf(settingsStore.load()) }
  var modelLoaded by remember { mutableStateOf(false) }
  var modelStatus by remember { mutableStateOf<String?>("Loading model...") }
  val orchestrator = remember {
    AgentOrchestrator(
      context = context,
      llamaEngine = llamaEngine,
      selfRepairEngine = selfRepairEngine
    )
  }

  val downloads = remember { ModelDownloadManager(llamaEngine.modelsDir()) }
  val chatStore = remember { ChatStore(context) }

  // Chat history: reopen the latest conversation, then persist changes (debounced) under the current chat id.
  var chatList by remember { mutableStateOf<List<ChatSummary>>(emptyList()) }
  var showHistory by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) {
    val all = withContext(Dispatchers.IO) { chatStore.list() }
    chatList = all
    all.firstOrNull()?.let { latest ->
      val saved = withContext(Dispatchers.IO) { chatStore.load(latest.id) }
      orchestrator.openChat(latest.id, saved)
    }
    orchestrator.messages.collectLatest { msgs ->
      delay(1000)
      withContext(Dispatchers.IO) {
        chatStore.save(orchestrator.chatId, msgs)
        chatList = chatStore.list()
      }
    }
  }

  suspend fun loadModel(s: SettingsState) {
    if (s.backendMode == "remote") {
      modelLoaded = true
      modelStatus = "Remote server: ${s.remoteUrl}"
      return
    }
    withContext(Dispatchers.IO) { llamaEngine.initialize(s) }
    modelLoaded = llamaEngine.isReady
    modelStatus = llamaEngine.statusMessage
    if (modelLoaded) {
      modelStatus = "Measuring speed..."
      val bench = scope.async(Dispatchers.IO) { llamaEngine.benchmark() }
      val result = withTimeoutOrNull(60_000) { bench.await() }
      modelStatus = if (result == null) {
        llamaEngine.stopNow()
        "Speed test did not finish in 60 s, so inference is stuck or extremely slow. Native log:\n" +
          LlamaBridge.instance.debugLog()
      } else {
        result.lineSequence().firstOrNull() ?: ""
      }
    }
  }

  // Initialize projects and llama model
  LaunchedEffect(Unit) {
    com.example.build.ApkPackager.appContext = context.applicationContext
    projectManager.initialize()
    loadModel(settings)
  }

  val activeProject by projectManager.activeProject.collectAsState()

  // Header label for the chat screen: the model in use, or a graceful fallback when there is none.
  val modelLabel = remember(
    settings.backendMode, settings.remoteModel, settings.remoteUrl,
    settings.customModelPath, settings.activeModelId, modelLoaded, modelStatus
  ) {
    if (settings.backendMode == "remote") {
      // v1.2: friendly alias in the header; the full name stays on the Models screen.
      settings.remoteModel.trim().takeIf { it.isNotBlank() }?.let { com.example.ui.components.friendlyModelName(it) } ?: settings.remoteModel.trim().ifBlank {
        runCatching { java.net.URL(settings.remoteUrl).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Remote"
      }
    } else {
      val file = llamaEngine.resolveModelFile(settings)
      if (file.isFile) {
        com.example.ui.components.friendlyModelName(file.name).ifBlank { file.name.removeSuffix(".gguf").removeSuffix(".GGUF") }
      } else {
        "No model"
      }
    }
  }

  var currentDestination by remember { mutableStateOf(AppDestination.AGENT) }
  var isViewingTests by remember { mutableStateOf(false) }
  var isPreviewing by remember { mutableStateOf(false) }

  BackHandler(enabled = showHistory || isPreviewing || isViewingTests || currentDestination != AppDestination.AGENT) {
    if (showHistory) {
      showHistory = false
    } else if (isPreviewing) {
      isPreviewing = false
    } else if (isViewingTests) {
      isViewingTests = false
    } else {
      currentDestination = AppDestination.AGENT
    }
  }

  val glass = rememberGlassState()
  val density = androidx.compose.ui.platform.LocalDensity.current
  // Derived so the screen does not recompose on every frame of the keyboard animation.
  val imeInsets = WindowInsets.ime
  val imeOpen by remember { androidx.compose.runtime.derivedStateOf { imeInsets.getBottom(density) > 0 } }
  val generating by orchestrator.isGenerating.collectAsState()
  LaunchedEffect(generating, imeOpen) { com.example.ui.theme.ThemeController.busy = generating || imeOpen }
  val showBar = !isViewingTests && !isPreviewing && !imeOpen
  var barHeight by remember { mutableStateOf(0.dp) }
  val inset = if (showBar) barHeight else 0.dp

  // v1.2.1: popups (separate windows) read the main glass layer for a real backdrop blur.
  androidx.compose.runtime.CompositionLocalProvider(com.example.ui.components.LocalGlassState provides glass) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .glassSource(glass, MaterialTheme.colorScheme.background)
    ) {
      val previewProject = activeProject
      // v1.2: sub-screens (web preview, tests) fade in and out instead of popping.
      val overlay = when {
        isPreviewing && previewProject != null -> 2
        isViewingTests -> 1
        else -> 0
      }
      AnimatedContent(
        targetState = overlay,
        transitionSpec = { fadeIn(tween(200, delayMillis = 30)) togetherWith fadeOut(tween(140)) },
        label = "subScreen"
      ) { shownOverlay ->
      if (shownOverlay == 2 && previewProject != null) {
        WebPreviewScreen(
          project = previewProject,
          onBack = { isPreviewing = false },
          onFixErrors = { errors ->
            isPreviewing = false
            currentDestination = AppDestination.AGENT
            orchestrator.sendMessage(
              "Fix these JavaScript errors in the app. Output only the files that change.\n$errors",
              previewProject,
              settings,
              scope
            )
          }
        )
      } else if (shownOverlay == 1) {
        TestsScreen(
          testRunnerEngine = testRunnerEngine,
          activeProject = activeProject,
          onBack = { isViewingTests = false }
        )
      } else {
        AnimatedContent(
          targetState = currentDestination,
          transitionSpec = {
            // Fade plus a slight slide in the direction of the tab that was picked.
            val dir = if (targetState.ordinal >= initialState.ordinal) 1 else -1
            (fadeIn(tween(220, delayMillis = 40)) +
              androidx.compose.animation.slideInHorizontally(tween(260)) { w -> dir * w / 14 }) togetherWith
              (fadeOut(tween(120)) +
                androidx.compose.animation.slideOutHorizontally(tween(200)) { w -> -dir * w / 18 })
          },
          label = "screen"
        ) { dest ->
        when (dest) {
          AppDestination.AGENT -> {
            AgentScreen(
              orchestrator = orchestrator,
              projectManager = projectManager,
              activeProject = activeProject,
              settings = settings,
              onPreview = { isPreviewing = true },
              onOpenBuild = { currentDestination = AppDestination.BUILD },
              onOpenHistory = { showHistory = true },
              onSettingsChange = {
                settings = it
                settingsStore.save(it)
              },
              bottomInset = inset,
              modelName = modelLabel
            )
          }
          AppDestination.PROJECT -> {
            ProjectScreen(
              projectManager = projectManager,
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.MODELS -> {
            ModelsScreen(
              modelsDir = llamaEngine.modelsDir(),
              currentPath = settings.customModelPath,
              modelLoaded = modelLoaded,
              modelStatus = modelStatus,
              downloads = downloads,
              bottomInset = inset,
              onSelectModel = { path ->
                val updated = settings.copy(customModelPath = path)
                settings = updated
                settingsStore.save(updated)
                modelLoaded = false
                modelStatus = "Loading model..."
                scope.launch { loadModel(updated) }
              },
              onBenchmark = { llamaEngine.benchmark() },
              settings = settings,
              onUpdateSettings = {
                settings = it
                settingsStore.save(it)
              },
              onUnload = {
                scope.launch {
                  withContext(Dispatchers.IO) { llamaEngine.unload() }
                  modelLoaded = false
                  modelStatus = llamaEngine.statusMessage
                }
              }
            )
          }
          AppDestination.TERMINAL -> {
            TerminalScreen(
              terminalManager = terminalManager,
              activeProject = activeProject,
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.BUILD -> {
            BuildScreen(
              buildRunner = buildRunner,
              selfRepairEngine = selfRepairEngine,
              activeProject = activeProject,
              onNavigateToAgent = { currentDestination = AppDestination.AGENT },
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.SETTINGS -> {
            SettingsScreen(
              settings = settings,
              onUpdateSettings = {
                settings = it
                settingsStore.save(it)
                com.example.ui.theme.ThemeController.mode = it.themeMode
                com.example.ui.theme.ThemeController.blur = it.glassBlur
              },
              onOpenTestRunner = { isViewingTests = true },
              onClearChat = { orchestrator.newChat() },
              bottomInset = inset
            )
          }
        }
        }
      }
      }
    }

    if (showBar) {
      // Fade under the dock so scrolled content never fights the glass (replaces blur when it is off).
      if (!com.example.ui.theme.ThemeController.blurActive) {
        Box(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .height(barHeight + 28.dp)
            .background(
              androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.92f))
              )
            )
        )
      }
      GlassDock(
        glass = glass,
        tabs = AppDestination.values().filter { it != AppDestination.BUILD },
        selected = currentDestination,
        onSelect = { currentDestination = it },
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .onSizeChanged { barHeight = with(density) { it.height.toDp() } }
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp)
      )
    }

    if (showHistory) {
      HistoryOverlay(
        glass = glass,
        chats = chatList,
        currentId = orchestrator.chatId,
        onOpen = { id ->
          scope.launch {
            val msgs = withContext(Dispatchers.IO) { chatStore.load(id) }
            orchestrator.openChat(id, msgs)
            currentDestination = AppDestination.AGENT
            showHistory = false
          }
        },
        onDelete = { id ->
          scope.launch {
            withContext(Dispatchers.IO) { chatStore.delete(id); chatList = chatStore.list() }
            if (id == orchestrator.chatId) orchestrator.newChat()
          }
        },
        onNew = {
          orchestrator.newChat()
          currentDestination = AppDestination.AGENT
          showHistory = false
        },
        onDismiss = { showHistory = false }
      )
    }
  }
  }
}

/**
 * iOS 26 style floating dock: blurred glass pill with a "liquid" lens that springs to the selected
 * tab (stretching while it moves). Dragging a finger across the dock slides the lens too.
 */
@Composable
private fun GlassDock(
  glass: com.example.ui.components.GlassState,
  tabs: List<AppDestination>,
  selected: AppDestination,
  onSelect: (AppDestination) -> Unit,
  modifier: Modifier = Modifier
) {
  val shape = RoundedCornerShape(36.dp)
  val haptics = rememberHaptics()
  val density = androidx.compose.ui.platform.LocalDensity.current
  val padPx = with(density) { 6.dp.toPx() }
  var widthPx by remember { mutableStateOf(0) }
  val itemW = if (widthPx > 0) (widthPx - 2 * padPx) / tabs.size else 0f
  val index = tabs.indexOf(selected).coerceAtLeast(0)
  val offset = remember { androidx.compose.animation.core.Animatable(0f) }
  var placed by remember { mutableStateOf(false) }
  // v1.1.1: while a finger slides across the dock the lens follows the finger directly and only the
  // highlighted tab changes; the screen switches once, on release. Switching screens for every tab the
  // finger crossed (each one composing a full screen under the blurred glass) is what made swipes lag.
  val scope = rememberCoroutineScope()
  var dragging by remember { mutableStateOf(false) }
  var hoverIndex by remember { mutableStateOf(-1) }
  val shownIndex = if (dragging && hoverIndex >= 0) hoverIndex else index
  LaunchedEffect(index, itemW) {
    if (itemW <= 0f || dragging) return@LaunchedEffect
    val target = index * itemW
    if (!placed) {
      offset.snapTo(target)
      placed = true
    } else {
      offset.animateTo(
        target,
        androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 320f)
      )
    }
  }
  val dark = Palette.dark
  val rim = specularBrush()
  val lensFill = if (dark) Color.White.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.55f)
  val lensSheen = androidx.compose.ui.graphics.Brush.verticalGradient(
    listOf(Color.White.copy(alpha = if (dark) 0.22f else 0.70f), Color.Transparent)
  )
  val currentIndex by androidx.compose.runtime.rememberUpdatedState(index)
  val currentSelect by androidx.compose.runtime.rememberUpdatedState(onSelect)

  Box(
    modifier = modifier
      .shadow(28.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.55f), spotColor = Color.Black.copy(alpha = 0.55f))
      .glassSurface(
        glass, shape,
        if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.38f),
        blurRadiusPx = 80f
      )
      .background(
        androidx.compose.ui.graphics.Brush.verticalGradient(
          0f to Color.White.copy(alpha = if (dark) 0.16f else 0.55f),
          0.5f to Color.Transparent,
          1f to Color.White.copy(alpha = if (dark) 0.05f else 0.18f)
        )
      )
      .border(1.dp, rim, shape)
      .padding(1.dp)
      .border(0.5.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.28f else 0.95f), Color.Transparent)), shape)
      .onSizeChanged { widthPx = it.width }
      .drawBehind {
        if (itemW > 0f) {
          val h = size.height - 2 * padPx
          val moving = if (dragging) 0.35f else (kotlin.math.abs(offset.value - index * itemW) / itemW).coerceIn(0f, 1f)
          val w = itemW * (1f + 0.16f * moving)
          val x = padPx + offset.value - (w - itemW) / 2f
          val corner = androidx.compose.ui.geometry.CornerRadius(h / 2f)
          val topLeft = androidx.compose.ui.geometry.Offset(x, padPx)
          val sz = androidx.compose.ui.geometry.Size(w, h)
          drawRoundRect(lensFill, topLeft, sz, corner)
          drawRoundRect(lensSheen, topLeft, sz, corner)
          drawRoundRect(rim, topLeft, sz, corner, style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        }
      }
      // One gesture for tap and drag: the tab under the finger is selected the moment it touches down,
      // so a plain press works with no movement, and sliding the finger still moves the lens.
      .pointerInput(tabs, itemW) {
        if (itemW > 0f) {
          awaitEachGesture {
            fun indexAt(x: Float): Int = ((x - padPx) / itemW).toInt().coerceIn(0, tabs.lastIndex)
            val down = awaitFirstDown(requireUnconsumed = false)
            // A plain tap still selects the moment the finger touches down.
            val first = indexAt(down.position.x)
            if (first != currentIndex) {
              haptics.tick()
              currentSelect(tabs[first])
            }
            down.consume()
            val slop = viewConfiguration.touchSlop
            var hover = first
            var dragged = false
            while (true) {
              val event = awaitPointerEvent()
              val change = event.changes.firstOrNull() ?: break
              if (!dragged && kotlin.math.abs(change.position.x - down.position.x) > slop) {
                dragged = true
                hoverIndex = hover
                dragging = true
              }
              if (dragged) {
                val lensX = (change.position.x - padPx - itemW / 2f).coerceIn(0f, tabs.lastIndex * itemW)
                scope.launch { offset.snapTo(lensX) }
                val i = indexAt(change.position.x)
                if (i != hover) {
                  hover = i
                  hoverIndex = i
                  haptics.tick()
                }
              }
              change.consume()
              if (!change.pressed) break
            }
            if (dragged) {
              dragging = false
              hoverIndex = -1
              if (hover != currentIndex) {
                currentSelect(tabs[hover])
              } else {
                scope.launch {
                  offset.animateTo(
                    currentIndex * itemW,
                    androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 320f)
                  )
                }
              }
            }
          }
        }
      }
      .padding(6.dp)
  ) {
    Row(horizontalArrangement = Arrangement.SpaceEvenly) {
      tabs.forEach { destination ->
        TabItem(
          destination = destination,
          selected = tabs.indexOf(destination) == shownIndex,
          modifier = Modifier.weight(1f)
        )
      }
    }
  }
}

@Composable
private fun TabItem(
  destination: AppDestination,
  selected: Boolean,
  modifier: Modifier = Modifier
) {
  // Inactive tabs use the full-strength secondary label colour (v1.2: raised from 0.92 alpha) so they stay legible on glass.
  val tint by animateColorAsState(
    if (selected) CyberCyanPrimary else androidx.compose.ui.graphics.lerp(com.example.ui.theme.TextSecondary, TextPrimary, 0.3f),
    animationSpec = tween(220),
    label = "tabTint"
  )
  val glowAlpha by androidx.compose.animation.core.animateFloatAsState(
    if (selected) 1f else 0f, animationSpec = tween(260), label = "tabGlow"
  )
  val iconScale by androidx.compose.animation.core.animateFloatAsState(
    if (selected) 1.08f else 1f,
    animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 420f),
    label = "tabScale"
  )
  val lift by androidx.compose.animation.core.animateDpAsState(
    if (selected) (-1).dp else 0.dp, animationSpec = tween(220), label = "tabLift"
  )
  val glow = CyberCyanPrimary
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(26.dp))
      .height(54.dp)
      .padding(vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(width = 44.dp, height = 28.dp)
        .offset(y = lift)
        .drawBehind {
          if (glowAlpha > 0f) {
            drawCircle(
              brush = androidx.compose.ui.graphics.Brush.radialGradient(
                listOf(glow.copy(alpha = 0.42f * glowAlpha), Color.Transparent),
                center = center,
                radius = size.minDimension * 0.95f
              ),
              radius = size.minDimension * 0.95f,
              center = center
            )
          }
        },
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = destination.icon,
        contentDescription = destination.label,
        tint = tint,
        modifier = Modifier
          .size(24.dp)
          .graphicsLayer {
            scaleX = iconScale
            scaleY = iconScale
          }
      )
    }
    Spacer(Modifier.height(2.dp))
    Text(
      destination.label,
      color = tint,
      fontSize = 10.5.sp,
      lineHeight = 13.sp,
      maxLines = 1,
      fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
      modifier = Modifier.offset(y = lift)
    )
  }
}
