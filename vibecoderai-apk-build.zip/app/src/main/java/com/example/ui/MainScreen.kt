package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.ui.layout.onSizeChanged
import com.example.ui.components.glassSource
import com.example.ui.components.glassSurface
import com.example.ui.components.rememberGlassState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.components.pressScale
import com.example.ui.components.specularBrush
import com.example.ui.theme.Palette
import com.example.ui.components.rememberHaptics
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.SettingsStore
import com.example.data.model.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withTimeoutOrNull
import com.example.llama.LlamaBridge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.llama.LlamaEngine
import com.example.project.ProjectManager
import com.example.terminal.TerminalManager
import com.example.testing.TestRunnerEngine
import com.example.ui.screens.AgentScreen
import com.example.ui.screens.WebPreviewScreen
import com.example.ui.screens.BuildScreen
import com.example.ui.screens.ModelsScreen
import com.example.data.downloader.ModelDownloadManager
import com.example.data.local.ChatStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import com.example.ui.screens.ProjectScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.TestsScreen
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class AppDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  AGENT("Chat", Icons.Default.SmartToy),
  PROJECT("Projects", Icons.Default.Folder),
  MODELS("Models", Icons.Default.Memory),
  TERMINAL("Terminal", Icons.Default.Terminal),
  SETTINGS("Settings", Icons.Default.Settings),
  BUILD("Build", Icons.Default.Build)
}

@Composable
fun MainScreen() {
  val context = LocalContext.current

  // Shared instances
  val projectManager = remember { ProjectManager(context) }
  val terminalManager = remember { TerminalManager() }
  val buildRunner = remember { BuildRunner() }
  val selfRepairEngine = remember { SelfRepairEngine(buildRunner = buildRunner) }
  val testRunnerEngine = remember { TestRunnerEngine(context = context, buildRunner = buildRunner, terminalManager = terminalManager) }
  val llamaEngine = remember { LlamaEngine(context) }

  val settingsStore = remember { SettingsStore(context) }
  val scope = rememberCoroutineScope()
  var settings by remember { mutableStateOf(settingsStore.load()) }
  var modelLoaded by remember { mutableStateOf(false) }
  var modelStatus by remember { mutableStateOf<String?>("Loading model...") }
  val orchestrator = remember {
    AgentOrchestrator(
      context = context,
      llamaEngine = llamaEngine,
      selfRepairEngine = selfRepairEngine
    )
  }

  val downloads = remember { ModelDownloadManager(llamaEngine.modelsDir()) }
  val chatStore = remember { ChatStore(context) }

  // Restore chat history, then persist changes (debounced)
  LaunchedEffect(Unit) {
    val saved = withContext(Dispatchers.IO) { chatStore.load() }
    orchestrator.restore(saved)
    orchestrator.messages.collectLatest { msgs ->
      delay(1000)
      withContext(Dispatchers.IO) { chatStore.save(msgs) }
    }
  }

  suspend fun loadModel(s: SettingsState) {
    withContext(Dispatchers.IO) { llamaEngine.initialize(s) }
    modelLoaded = llamaEngine.isReady
    modelStatus = llamaEngine.statusMessage
    if (modelLoaded) {
      modelStatus = "Measuring speed..."
      val bench = scope.async(Dispatchers.IO) { llamaEngine.benchmark() }
      val result = withTimeoutOrNull(60_000) { bench.await() }
      modelStatus = if (result == null) {
        llamaEngine.stopNow()
        "Speed test did not finish in 60 s, so inference is stuck or extremely slow. Native log:\n" +
          LlamaBridge.instance.debugLog()
      } else {
        result.lineSequence().firstOrNull() ?: ""
      }
    }
  }

  // Initialize projects and llama model
  LaunchedEffect(Unit) {
    com.example.build.ApkPackager.appContext = context.applicationContext
    projectManager.initialize()
    loadModel(settings)
  }

  val activeProject by projectManager.activeProject.collectAsState()

  var currentDestination by remember { mutableStateOf(AppDestination.AGENT) }
  var isViewingTests by remember { mutableStateOf(false) }
  var isPreviewing by remember { mutableStateOf(false) }

  BackHandler(enabled = isPreviewing || isViewingTests || currentDestination != AppDestination.AGENT) {
    if (isPreviewing) {
      isPreviewing = false
    } else if (isViewingTests) {
      isViewingTests = false
    } else {
      currentDestination = AppDestination.AGENT
    }
  }

  val glass = rememberGlassState()
  val showBar = !isViewingTests && !isPreviewing
  var barHeight by remember { mutableStateOf(0.dp) }
  val density = androidx.compose.ui.platform.LocalDensity.current
  val inset = if (showBar) barHeight else 0.dp

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .glassSource(glass, MaterialTheme.colorScheme.background)
    ) {
      val previewProject = activeProject
      if (isPreviewing && previewProject != null) {
        WebPreviewScreen(
          project = previewProject,
          onBack = { isPreviewing = false },
          onFixErrors = { errors ->
            isPreviewing = false
            currentDestination = AppDestination.AGENT
            orchestrator.sendMessage(
              "Fix these JavaScript errors in the app. Output only the files that change.\n$errors",
              previewProject,
              settings,
              scope
            )
          }
        )
      } else if (isViewingTests) {
        TestsScreen(
          testRunnerEngine = testRunnerEngine,
          activeProject = activeProject,
          onBack = { isViewingTests = false }
        )
      } else {
        AnimatedContent(
          targetState = currentDestination,
          transitionSpec = {
            (fadeIn(tween(240)) + slideInVertically(tween(280)) { it / 18 }) togetherWith fadeOut(tween(120))
          },
          label = "screen"
        ) { dest ->
        when (dest) {
          AppDestination.AGENT -> {
            AgentScreen(
              orchestrator = orchestrator,
              projectManager = projectManager,
              activeProject = activeProject,
              settings = settings,
              onPreview = { isPreviewing = true },
              onOpenBuild = { currentDestination = AppDestination.BUILD },
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.PROJECT -> {
            ProjectScreen(
              projectManager = projectManager,
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.MODELS -> {
            ModelsScreen(
              modelsDir = llamaEngine.modelsDir(),
              currentPath = settings.customModelPath,
              modelLoaded = modelLoaded,
              modelStatus = modelStatus,
              downloads = downloads,
              bottomInset = inset,
              onSelectModel = { path ->
                val updated = settings.copy(customModelPath = path)
                settings = updated
                settingsStore.save(updated)
                modelLoaded = false
                modelStatus = "Loading model..."
                scope.launch { loadModel(updated) }
              },
              onBenchmark = { llamaEngine.benchmark() },
              onUnload = {
                scope.launch {
                  withContext(Dispatchers.IO) { llamaEngine.unload() }
                  modelLoaded = false
                  modelStatus = llamaEngine.statusMessage
                }
              }
            )
          }
          AppDestination.TERMINAL -> {
            TerminalScreen(
              terminalManager = terminalManager,
              activeProject = activeProject,
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.BUILD -> {
            BuildScreen(
              buildRunner = buildRunner,
              selfRepairEngine = selfRepairEngine,
              activeProject = activeProject,
              onNavigateToAgent = { currentDestination = AppDestination.AGENT },
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.SETTINGS -> {
            SettingsScreen(
              settings = settings,
              onUpdateSettings = {
                settings = it
                settingsStore.save(it)
                com.example.ui.theme.ThemeController.mode = it.themeMode
              },
              onOpenTestRunner = { isViewingTests = true },
              onClearChat = { orchestrator.newChat() },
              bottomInset = inset
            )
          }
        }
        }
      }
    }

    if (showBar) {
      val tabShape = RoundedCornerShape(28.dp)
      val haptics = rememberHaptics()
      Box(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .onSizeChanged { barHeight = with(density) { it.height.toDp() } }
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        Row(
          modifier = Modifier
            .shadow(16.dp, tabShape, clip = false, ambientColor = Color.Black.copy(alpha = 0.25f), spotColor = Color.Black.copy(alpha = 0.25f))
            .glassSurface(glass, tabShape, ObsidianSurface.copy(alpha = 0.55f))
            .border(1.dp, specularBrush(), tabShape)
            .padding(horizontal = 6.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          AppDestination.values().filter { it != AppDestination.BUILD }.forEach { destination ->
            TabItem(
              destination = destination,
              selected = currentDestination == destination,
              onClick = {
                haptics.tick()
                currentDestination = destination
              },
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TabItem(
  destination: AppDestination,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val tint by animateColorAsState(if (selected) CyberCyanPrimary else TextMuted, label = "tabTint")
  val lens by animateColorAsState(
    if (selected) (if (Palette.dark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.07f)) else Color.Transparent,
    label = "tabLens"
  )
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(22.dp))
      .background(lens)
      .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
      .pressScale()
      .padding(vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Icon(imageVector = destination.icon, contentDescription = destination.label, tint = tint, modifier = Modifier.size(24.dp))
    Text(destination.label, color = tint, fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
  }
}
