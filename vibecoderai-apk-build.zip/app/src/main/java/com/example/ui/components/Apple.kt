package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

class Haptics(private val h: HapticFeedback) {
  /** Light tick for toggles and slider steps. */
  fun tick() = h.performHapticFeedback(HapticFeedbackType.TextHandleMove)

  /** Stronger feedback for important actions. */
  fun strong() = h.performHapticFeedback(HapticFeedbackType.LongPress)
}

@Composable
fun rememberHaptics(): Haptics {
  val h = LocalHapticFeedback.current
  return remember(h) { Haptics(h) }
}

/** Spring scale-down while a finger is on the element. Does not consume the touch. */
fun Modifier.pressScale(pressedScale: Float = 0.94f): Modifier = composed {
  var pressed by remember { mutableStateOf(false) }
  val scale by animateFloatAsState(
    targetValue = if (pressed) pressedScale else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "pressScale"
  )
  this
    .graphicsLayer {
      scaleX = scale
      scaleY = scale
    }
    .pointerInput(Unit) {
      awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        pressed = true
        waitForUpOrCancellation()
        pressed = false
      }
    }
}

@Composable
fun LargeTitle(text: String, modifier: Modifier = Modifier) {
  Text(
    text = text,
    color = TextPrimary,
    fontSize = 34.sp,
    lineHeight = 41.sp,
    fontWeight = FontWeight.Bold,
    letterSpacing = (-0.4).sp,
    modifier = modifier.padding(top = 8.dp, bottom = 4.dp)
  )
}

/** iOS grouped list: small caps header above a rounded white/graphite card. */
@Composable
fun GroupedSection(
  title: String,
  modifier: Modifier = Modifier,
  footer: String? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = title.uppercase(),
      color = TextMuted,
      fontSize = 12.sp,
      fontWeight = FontWeight.Medium,
      modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
    )
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .liquidGlass(RoundedCornerShape(22.dp), 8.dp)
        .padding(horizontal = 16.dp, vertical = 10.dp),
      content = content
    )
    if (footer != null) {
      Text(
        text = footer,
        color = TextMuted,
        fontSize = 12.sp,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp)
      )
    }
  }
}

/** Specular rim: bright top-left, soft blue/pink dispersion on the far edges, like light bending through glass. */
@Composable
fun specularBrush(): Brush =
  if (com.example.ui.theme.Palette.dark) {
    Brush.linearGradient(
      listOf(
        Color.White.copy(alpha = 0.60f),
        Color.White.copy(alpha = 0.05f),
        Color(0xFF64D2FF).copy(alpha = 0.22f),
        Color(0xFFBF5AF2).copy(alpha = 0.18f),
        Color.White.copy(alpha = 0.34f)
      )
    )
  } else {
    Brush.linearGradient(
      listOf(
        Color.White,
        Color.White.copy(alpha = 0.25f),
        Color(0xFF64D2FF).copy(alpha = 0.35f),
        Color(0xFFBF5AF2).copy(alpha = 0.25f),
        Color.White.copy(alpha = 0.95f)
      )
    )
  }

/**
 * Apple-style liquid glass, no blur (cheap): a thin translucent body, a top sheen, a faint bottom
 * reflection, an inner highlight line and a refractive rim.
 */
fun Modifier.liquidGlass(shape: Shape, elevation: Dp = 10.dp): Modifier = composed {
  val dark = com.example.ui.theme.Palette.dark
  val shadowColor = Color.Black.copy(alpha = if (dark) 0.50f else 0.10f)
  val sheen = Brush.verticalGradient(
    0f to Color.White.copy(alpha = if (dark) 0.13f else 0.60f),
    0.45f to Color.White.copy(alpha = if (dark) 0.02f else 0.08f),
    1f to Color.White.copy(alpha = if (dark) 0.06f else 0.22f)
  )
  val inner = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = if (dark) 0.22f else 0.9f), Color.Transparent)
  )
  this
    .shadow(elevation, shape, clip = false, ambientColor = shadowColor, spotColor = shadowColor)
    .clip(shape)
    .background(ObsidianSurface)
    .background(sheen)
    .border(1.dp, specularBrush(), shape)
    .padding(1.dp)
    .border(0.5.dp, inner, shape)
}
