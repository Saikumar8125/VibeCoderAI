package com.example.ui.screens

import android.os.Debug
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.ui.components.GroupedSection
import com.example.ui.components.LargeTitle
import com.example.ui.components.pressScale
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
private fun SliderRow(
  label: String,
  valueText: String,
  hint: String?,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  steps: Int = 0,
  onChange: (Float) -> Unit
) {
  val haptics = rememberHaptics()
  var first by remember { mutableStateOf(true) }
  LaunchedEffect(valueText) {
    if (first) first = false else haptics.tick()
  }
  Column(modifier = Modifier.padding(vertical = 6.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, color = TextPrimary, fontSize = 16.sp)
      Text(valueText, color = TextMuted, fontSize = 16.sp)
    }
    Slider(
      value = value.coerceIn(range),
      onValueChange = onChange,
      valueRange = range,
      steps = steps,
      thumb = {
        Box(
          modifier = Modifier
            .size(28.dp)
            .shadow(4.dp, CircleShape)
            .background(Color.White, CircleShape)
        )
      },
      colors = SliderDefaults.colors(
        activeTrackColor = CyberCyanPrimary,
        inactiveTrackColor = ObsidianSurfaceVariant,
        activeTickColor = Color.White.copy(alpha = 0.55f),
        inactiveTickColor = TextMuted.copy(alpha = 0.5f)
      )
    )
    if (hint != null) Text(hint, color = TextMuted, fontSize = 12.sp)
  }
}

@Composable
private fun ToggleRow(label: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
  val haptics = rememberHaptics()
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(label, color = TextPrimary, fontSize = 16.sp)
      Text(hint, color = TextMuted, fontSize = 12.sp)
    }
    Switch(
      checked = checked,
      onCheckedChange = {
        haptics.tick()
        onChange(it)
      },
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = CyberGreenSuccess,
        checkedBorderColor = CyberGreenSuccess,
        uncheckedThumbColor = Color.White,
        uncheckedTrackColor = ObsidianBorder,
        uncheckedBorderColor = ObsidianBorder
      )
    )
  }
}

@Composable
private fun PillButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
  TextButton(
    onClick = onClick,
    modifier = modifier.pressScale(),
    shape = CircleShape
  ) {
    Box(
      modifier = Modifier
        .clip(CircleShape)
        .background(color.copy(alpha = 0.14f))
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Text(text, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
fun SettingsScreen(
  settings: SettingsState,
  onUpdateSettings: (SettingsState) -> Unit,
  onOpenTestRunner: () -> Unit,
  onClearChat: () -> Unit = {},
  bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
  modifier: Modifier = Modifier
) {
  val maxThreads = Runtime.getRuntime().availableProcessors().coerceIn(2, 12)
  val haptics = rememberHaptics()
  val rt = Runtime.getRuntime()
  var heapUsedMb by remember { mutableStateOf((rt.totalMemory() - rt.freeMemory()) / 1048576) }
  var nativeMb by remember { mutableStateOf(Debug.getNativeHeapAllocatedSize() / 1048576) }
  val heapMaxMb = rt.maxMemory() / 1048576

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    LargeTitle("Settings")

    GroupedSection(
      "Generation",
      footer = "Context changes reload the model on the next message."
    ) {
      SliderRow(
        "CPU threads", "${settings.cpuThreads}",
        "This phone reports $maxThreads cores. Speed is usually best near the number of fast cores (often 4).",
        settings.cpuThreads.toFloat(), 1f..maxThreads.toFloat(), steps = maxThreads - 2
      ) { onUpdateSettings(settings.copy(cpuThreads = it.roundToInt())) }
      SliderRow(
        "Context window", "${settings.contextLength}", null,
        settings.contextLength.toFloat(), 1024f..8192f, steps = 6
      ) { onUpdateSettings(settings.copy(contextLength = (it / 1024f).roundToInt() * 1024)) }
      SliderRow(
        "Max output tokens", "${settings.maxOutputTokens}",
        "A complete small web app needs about 1500.",
        settings.maxOutputTokens.toFloat(), 256f..4096f, steps = 14
      ) { onUpdateSettings(settings.copy(maxOutputTokens = (it / 256f).roundToInt() * 256)) }
      SliderRow(
        "Temperature", "%.2f".format(settings.temperature),
        "Lower gives more predictable code. 0 is greedy.",
        settings.temperature, 0f..1.5f
      ) { onUpdateSettings(settings.copy(temperature = (it * 20).roundToInt() / 20f)) }
      SliderRow(
        "Top-P", "%.2f".format(settings.topP), null,
        settings.topP, 0.1f..1f
      ) { onUpdateSettings(settings.copy(topP = (it * 20).roundToInt() / 20f)) }
      SliderRow(
        "Top-K", "${settings.topK}", null,
        settings.topK.toFloat(), 1f..100f
      ) { onUpdateSettings(settings.copy(topK = it.roundToInt())) }
      SliderRow(
        "Repetition penalty", "%.2f".format(settings.repetitionPenalty),
        "1.00 is off. Keep it off for code.",
        settings.repetitionPenalty, 1f..1.5f
      ) { onUpdateSettings(settings.copy(repetitionPenalty = (it * 20).roundToInt() / 20f)) }
    }

    GroupedSection("Agent") {
      ToggleRow(
        "Approve file overwrites", "New files are created directly. Changes to existing files wait for you.",
        settings.requireApprovalForDestructive
      ) { onUpdateSettings(settings.copy(requireApprovalForDestructive = it)) }
      ToggleRow(
        "Rebuild after a fix", "Verifies the project after an approved patch.",
        settings.autoRebuildAfterPatch
      ) { onUpdateSettings(settings.copy(autoRebuildAfterPatch = it)) }
      SliderRow(
        "Max repair attempts", "${settings.maxRepairRetries}", null,
        settings.maxRepairRetries.toFloat(), 1f..5f, steps = 3
      ) { onUpdateSettings(settings.copy(maxRepairRetries = it.roundToInt())) }
    }

    GroupedSection("Memory", footer = "Model weights are memory-mapped by llama.cpp and are not counted here.") {
      val fraction = (heapUsedMb.toFloat() / heapMaxMb.coerceAtLeast(1)).coerceIn(0f, 1f)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("JVM heap", color = TextPrimary, fontSize = 16.sp)
          Text("$heapUsedMb of $heapMaxMb MB, native $nativeMb MB", color = TextMuted, fontSize = 12.sp)
        }
        PillButton("Free RAM", CyberCyanPrimary, onClick = {
          haptics.strong()
          System.gc()
          heapUsedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576
          nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576
        })
      }
      Spacer(modifier = Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { fraction },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
        color = if (fraction > 0.8f) CyberCoralError else CyberCyanPrimary,
        trackColor = ObsidianSurfaceVariant
      )
    }

    GroupedSection("Data & diagnostics") {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        PillButton("Clear chat", CyberCoralError, onClick = {
          haptics.strong()
          onClearChat()
        })
        PillButton("Reset defaults", TextSecondary, onClick = {
          haptics.tick()
          onUpdateSettings(SettingsState(customModelPath = settings.customModelPath))
        })
        PillButton("Self tests", CyberCyanPrimary, onClick = {
          haptics.strong()
          onOpenTestRunner()
        })
      }
    }

    Spacer(modifier = Modifier.height(24.dp + bottomInset))
  }
}
