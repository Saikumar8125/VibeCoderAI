@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.ui.screens

import android.os.Debug
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import com.example.ui.components.liquidGlass
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.ui.components.GroupedSection
import com.example.ui.components.LargeTitle
import com.example.data.model.withLevel
import com.example.ui.components.pressScale
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
private fun SliderRow(
  label: String,
  valueText: String,
  hint: String?,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  steps: Int = 0,
  onChange: (Float) -> Unit
) {
  val haptics = rememberHaptics()
  var first by remember { mutableStateOf(true) }
  LaunchedEffect(valueText) {
    if (first) first = false else haptics.tick()
  }
  Column(modifier = Modifier.padding(vertical = 6.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, color = TextPrimary, fontSize = 16.sp)
      Text(valueText, color = TextSecondary, fontSize = 16.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
    }
    Slider(
      value = value.coerceIn(range),
      onValueChange = onChange,
      valueRange = range,
      steps = steps,
      thumb = {
        Box(
          modifier = Modifier
            .size(28.dp)
            .shadow(4.dp, CircleShape)
            .background(Color.White, CircleShape)
        )
      },
      colors = SliderDefaults.colors(
        activeTrackColor = CyberCyanPrimary,
        inactiveTrackColor = ObsidianSurfaceVariant,
        activeTickColor = Color.White.copy(alpha = 0.55f),
        inactiveTickColor = TextMuted.copy(alpha = 0.5f)
      )
    )
    if (hint != null) Text(hint, color = TextMuted, fontSize = 12.5.sp, lineHeight = 17.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
  }
}

@Composable
private fun ToggleRow(label: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
  val haptics = rememberHaptics()
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(label, color = TextPrimary, fontSize = 16.sp)
      Text(hint, color = TextMuted, fontSize = 12.5.sp, lineHeight = 17.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
    }
    Switch(
      checked = checked,
      onCheckedChange = {
        haptics.tick()
        onChange(it)
      },
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = CyberCyanPrimary,
        checkedBorderColor = CyberCyanPrimary,
        uncheckedThumbColor = Color.White,
        uncheckedTrackColor = ObsidianBorder,
        uncheckedBorderColor = ObsidianBorder
      )
    )
  }
}

@Composable
private fun PillButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
  TextButton(
    onClick = onClick,
    modifier = modifier.pressScale(),
    shape = CircleShape
  ) {
    Box(
      modifier = Modifier
        .clip(CircleShape)
        .background(color.copy(alpha = 0.14f))
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Text(text, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
fun SettingsScreen(
  settings: SettingsState,
  onUpdateSettings: (SettingsState) -> Unit,
  onOpenTestRunner: () -> Unit,
  onClearChat: () -> Unit = {},
  bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
  modifier: Modifier = Modifier
) {
  val maxThreads = Runtime.getRuntime().availableProcessors().coerceIn(2, 12)
  val haptics = rememberHaptics()
  val rt = Runtime.getRuntime()
  var heapUsedMb by remember { mutableStateOf((rt.totalMemory() - rt.freeMemory()) / 1048576) }
  var nativeMb by remember { mutableStateOf(Debug.getNativeHeapAllocatedSize() / 1048576) }
  val heapMaxMb = rt.maxMemory() / 1048576

  var page by remember { mutableStateOf<String?>(null) }
  androidx.activity.compose.BackHandler(enabled = page != null) { page = null }
  val level = com.example.data.model.OutputLevel.from(settings.outputLevel)
  val skillsOn = com.example.agent.Skills.version.let { com.example.agent.Skills.all().count { com.example.agent.Skills.isEnabled(it) } }
  val themeLabel = when (settings.themeMode) { "light" -> "Light"; "dark" -> "Dark (OLED)"; else -> "System" }
  val context = androidx.compose.ui.platform.LocalContext.current
  val appVersion = remember {
    val name = runCatching {
      @Suppress("DEPRECATION")
      context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull()
    "VibeCoder v${name?.takeIf { it.isNotBlank() } ?: "1.0.0"}"
  }

  androidx.compose.animation.AnimatedContent(
    targetState = page,
    modifier = modifier.fillMaxSize(),
    transitionSpec = {
      val forward = targetState != null
      (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(280)) { if (forward) it / 4 else -it / 4 } +
        androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220))) togetherWith
        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(240)) { if (forward) -it / 5 else it / 4 } +
          androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140)))
    },
    label = "settingsPage"
  ) { p ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      if (p == null) {
        LargeTitle("Settings")
        SettingsGroup {
          NavRow(Icons.Default.Palette, Color(0xFF5E5CE6), "Appearance", themeLabel) { haptics.tick(); page = "appearance" }
          NavRow(Icons.Default.Tune, Color(0xFF0A84FF), "Output and generation", "${level.label} · ${settings.contextLength} ctx", last = true) { haptics.tick(); page = "output" }
        }
        SettingsGroup {
          NavRow(Icons.Default.SmartToy, Color(0xFF30D158), "Agent", if (settings.autonomous) "Autonomous" else "Manual") { haptics.tick(); page = "agent" }
          NavRow(Icons.Default.Extension, Color(0xFFFF9F0A), "Agent skills", "$skillsOn on", last = true) { haptics.tick(); page = "skills" }
        }
        SettingsGroup {
          NavRow(Icons.Default.Memory, Color(0xFFFF453A), "Memory", "$heapUsedMb MB") { haptics.tick(); page = "memory" }
          NavRow(Icons.Default.Storage, Color(0xFF8E8E93), "Data and diagnostics", appVersion.removePrefix("VibeCoder "), last = true) { haptics.tick(); page = "data" }
        }
        Text(
          appVersion,
          color = TextMuted,
          fontSize = 13.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        )
      } else {
        Row(
          modifier = Modifier
            .clip(CircleShape)
            .clickable { haptics.tick(); page = null }
            .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .padding(end = 12.dp, top = 4.dp, bottom = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = CyberCyanPrimary, modifier = Modifier.size(22.dp))
          Text("Settings", color = CyberCyanPrimary, fontSize = 16.sp)
        }
        LargeTitle(when (p) {
          "appearance" -> "Appearance"; "output" -> "Output"; "agent" -> "Agent"; "skills" -> "Skills"; "memory" -> "Memory"; else -> "Data"
        })
        when (p) {
          "appearance" -> {
    GroupedSection("Appearance", footer = "Light, Dark (OLED pure black), or follow the phone setting.") {
      val modes = listOf("system" to "System", "light" to "Light", "dark" to "Dark (OLED)")
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(3.dp)
      ) {
        modes.forEach { (key, label) ->
          val selected = settings.themeMode == key
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(CircleShape)
              .background(if (selected) CyberCyanPrimary else Color.Transparent)
              .clickable {
                haptics.tick()
                onUpdateSettings(settings.copy(themeMode = key))
              }
              .padding(vertical = 9.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              label,
              color = if (selected) Color.White else TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    GroupedSection("Performance", footer = "Frosted glass is on by default. Turn it off only if the app feels slow on this phone.") {
      ToggleRow(
        "Real glass blur", "Frosted blur behind the dock and sheets (Android 12+).",
        settings.glassBlur
      ) { onUpdateSettings(settings.copy(glassBlur = it)) }
    }

          }
          "output" -> {
    GroupedSection("Output level", footer = com.example.data.model.OutputLevel.from(settings.outputLevel).blurb) {
      val levels = com.example.data.model.OutputLevel.values()
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(3.dp)
      ) {
        levels.forEach { level ->
          val selected = settings.outputLevel == level.id
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(CircleShape)
              .background(if (selected) CyberCyanPrimary else Color.Transparent)
              .clickable {
                haptics.tick()
                onUpdateSettings(settings.withLevel(level))
              }
              .padding(vertical = 9.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              if (level == com.example.data.model.OutputLevel.ULTRA) "Ultra" else level.label,
              color = if (selected) Color.White else TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 1
            )
          }
        }
      }
    }

    GroupedSection(
      "Generation",
      footer = "Context changes reload the model on the next message."
    ) {
      SliderRow(
        "CPU threads", "${settings.cpuThreads}",
        "This phone reports $maxThreads cores. Speed is usually best near the number of fast cores (often 4).",
        settings.cpuThreads.toFloat(), 1f..maxThreads.toFloat(), steps = maxThreads - 2
      ) { onUpdateSettings(settings.copy(cpuThreads = it.roundToInt())) }
      SliderRow(
        "Context window", "${settings.contextLength}", null,
        settings.contextLength.toFloat(), 1024f..8192f, steps = 6
      ) { onUpdateSettings(settings.copy(contextLength = (it / 1024f).roundToInt() * 1024)) }
      SliderRow(
        "Max output tokens", "${settings.maxOutputTokens}",
        "A complete small web app needs about 1500.",
        settings.maxOutputTokens.toFloat(), 256f..4096f, steps = 14
      ) { onUpdateSettings(settings.copy(maxOutputTokens = (it / 256f).roundToInt() * 256)) }
      SliderRow(
        "Temperature", "%.2f".format(settings.temperature),
        "Lower gives more predictable code. 0 is greedy.",
        settings.temperature, 0f..1.5f
      ) { onUpdateSettings(settings.copy(temperature = (it * 20).roundToInt() / 20f)) }
      SliderRow(
        "Top-P", "%.2f".format(settings.topP), null,
        settings.topP, 0.1f..1f
      ) { onUpdateSettings(settings.copy(topP = (it * 20).roundToInt() / 20f)) }
      SliderRow(
        "Top-K", "${settings.topK}", null,
        settings.topK.toFloat(), 1f..100f
      ) { onUpdateSettings(settings.copy(topK = it.roundToInt())) }
      SliderRow(
        "Repetition penalty", "%.2f".format(settings.repetitionPenalty),
        "1.00 is off. Keep it off for code.",
        settings.repetitionPenalty, 1f..1.5f
      ) { onUpdateSettings(settings.copy(repetitionPenalty = (it * 20).roundToInt() / 20f)) }
    }

          }
          "agent" -> {
    GroupedSection("Agent") {
      ToggleRow(
        "Autonomous mode", "Plans the app in steps, builds each step, then runs it and fixes errors by itself.",
        settings.autonomous
      ) { onUpdateSettings(settings.copy(autonomous = it)) }
      ToggleRow(
        "Approve file overwrites", "New files are created directly. Changes to existing files wait for you.",
        settings.requireApprovalForDestructive
      ) { onUpdateSettings(settings.copy(requireApprovalForDestructive = it)) }
      ToggleRow(
        "Rebuild after a fix", "Verifies the project after an approved patch.",
        settings.autoRebuildAfterPatch
      ) { onUpdateSettings(settings.copy(autoRebuildAfterPatch = it)) }
      SliderRow(
        "Max repair attempts", "${settings.maxRepairRetries}", null,
        settings.maxRepairRetries.toFloat(), 1f..5f, steps = 3
      ) { onUpdateSettings(settings.copy(maxRepairRetries = it.roundToInt())) }
    }

          }
          "skills" -> SkillsSection()
          "memory" -> {
    GroupedSection("Memory", footer = "Model weights are memory-mapped by llama.cpp and are not counted here.") {
      val fraction = (heapUsedMb.toFloat() / heapMaxMb.coerceAtLeast(1)).coerceIn(0f, 1f)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("JVM heap", color = TextPrimary, fontSize = 16.sp)
          Text("$heapUsedMb of $heapMaxMb MB, native $nativeMb MB", color = TextMuted, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
        }
        PillButton("Free RAM", CyberCyanPrimary, onClick = {
          haptics.strong()
          System.gc()
          heapUsedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576
          nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576
        })
      }
      Spacer(modifier = Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { fraction },
        modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
        color = if (fraction > 0.8f) CyberCoralError else CyberCyanPrimary,
        trackColor = ObsidianSurfaceVariant
      )
    }

          }
          else -> {
    GroupedSection("Data & diagnostics") {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        PillButton("Clear chat", CyberCoralError, onClick = {
          haptics.strong()
          onClearChat()
        })
        PillButton("Reset defaults", TextSecondary, onClick = {
          haptics.tick()
          onUpdateSettings(SettingsState(customModelPath = settings.customModelPath, themeMode = settings.themeMode))
        })
        PillButton("Self tests", CyberCyanPrimary, onClick = {
          haptics.strong()
          onOpenTestRunner()
        })
      }
    }

    GroupedSection("About") {
      Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("Version", color = TextPrimary, fontSize = 16.sp)
        Text(appVersion, color = TextSecondary, fontSize = com.example.ui.theme.UiTokens.RowValueSize, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
      }
    }

          }
        }
      }
      Spacer(modifier = Modifier.height(24.dp + bottomInset))
    }
  }
}

/** iOS-style rounded group holding navigation rows. */
@Composable
private fun SettingsGroup(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .liquidGlass(com.example.ui.theme.UiTokens.CardShape, 8.dp)
      .padding(vertical = 4.dp),
    content = content
  )
}

@Composable
private fun NavRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  title: String,
  summary: String,
  last: Boolean = false,
  onClick: () -> Unit
) {
  Column {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable(onClick = onClick)
        .heightIn(min = 52.dp)
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(tint),
        contentAlignment = Alignment.Center
      ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp)) }
      Text(title, color = TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 12.dp))
      if (summary.isNotEmpty()) Text(
        summary,
        color = TextSecondary,
        fontSize = com.example.ui.theme.UiTokens.RowValueSize,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
        maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        modifier = Modifier.widthIn(max = 170.dp).padding(start = 8.dp)
      )
      Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted, modifier = Modifier.size(22.dp))
    }
    if (!last) Box(Modifier.fillMaxWidth().padding(start = 56.dp).height(0.5.dp).background(ObsidianBorder))
  }
}
