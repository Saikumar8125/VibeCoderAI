package com.example.agent.tools

import com.example.data.model.Project
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FileWriteTool(
  private val securityManager: SecurityManager = SecurityManager()
) : Tool {
  override val name = "file_write"
  override val description = "Creates or overwrites a file with content after security checks."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val path = arguments["path"] ?: return@withContext ToolResult(false, "", "Missing 'path' parameter.")
    val content = arguments["content"] ?: return@withContext ToolResult(false, "", "Missing 'content' parameter.")
    val file = if (path.startsWith("/")) File(path) else File(project.rootDir, path)

    if (!securityManager.isPathSafe(file, project.rootDir)) {
      return@withContext ToolResult(false, "", "Security Violation: Write blocked outside workspace.")
    }

    try {
      file.parentFile?.let { if (!it.exists()) it.mkdirs() }

      // Backup existing file if present
      if (file.exists()) {
        val backupDir = File(project.rootDir, ".vibecoder_backups").apply { if (!exists()) mkdirs() }
        val backupFile = File(backupDir, "${file.name}.${System.currentTimeMillis()}.bak")
        file.copyTo(backupFile, overwrite = true)
      }

      file.writeText(content)
      ToolResult(
        success = true,
        output = "Successfully wrote ${content.length} characters to ${file.relativeTo(project.rootDir).path}"
      )
    } catch (e: Exception) {
      ToolResult(false, "", "Failed to write file: ${e.message}")
    }
  }
}
