package com.example.agent

/** Decides whether a message is a normal chat or a request to create/change project files. */
object Intent {
  enum class Mode { CHAT, BUILD }

  private val verbs = Regex(
    "\\b(create|build|make|generate|write|develop|add|implement|fix|change|update|modify|edit|improve|redesign|" +
      "remove|delete|rename|refactor|convert|design|style|code)\\b"
  )
  private val nouns = Regex(
    "\\b(app|application|website|web ?site|web ?page|page|landing|game|calculator|to-?do|todo|tracker|dashboard|" +
      "form|ui|screen|button|layout|css|html|feature|project|file|component|navbar|menu|theme|" +
      "colou?r|animation|bug|errors?|login|quiz|timer|clock|portfolio)\\b"
  )
  // A request for code in another language is a chat answer with a code block, not a web project.
  private val otherLang = Regex("\\b(python|java|kotlin|swift|rust|php|sql|bash|ruby|dart|matlab|golang)\\b|c\\+\\+|c#")
  private val webWords = Regex("\\b(html|css|website|web ?page|webpage|landing|browser|index)\\b")
  private val appOnly = Regex(
    "\\b(to-?do|calculator|game|landing|website|dashboard|tracker|portfolio|quiz|timer|clock|weather)\\b"
  )
  private val questionStart = Regex(
    "^(what|why|how|who|when|where|which|explain|tell|define|is|are|does|do|did|should|difference|meaning|" +
      "describe|hi|hello|hey|hii|thanks|thank|ok|okay|good|yo)\\b"
  )
  private val politeStart = Regex("^(can you|could you|please|pls|will you|would you|just)\\b")
  private val fileRef = Regex("\\b(index\\.html|styles\\.css|app\\.js)\\b")

  fun classify(text: String): Mode {
    val t = text.trim().lowercase()
    if (t.startsWith("fix these javascript errors")) return Mode.BUILD
    if (fileRef.containsMatchIn(t)) return Mode.BUILD
    if (otherLang.containsMatchIn(t) && !webWords.containsMatchIn(t)) return Mode.CHAT
    val polite = politeStart.containsMatchIn(t)
    val isQuestion = !polite && (t.endsWith("?") || questionStart.containsMatchIn(t))
    if (isQuestion) return Mode.CHAT
    if (verbs.containsMatchIn(t) && nouns.containsMatchIn(t)) return Mode.BUILD
    if (appOnly.containsMatchIn(t) && t.split(Regex("\\s+")).size <= 10) return Mode.BUILD
    return Mode.CHAT
  }
}
