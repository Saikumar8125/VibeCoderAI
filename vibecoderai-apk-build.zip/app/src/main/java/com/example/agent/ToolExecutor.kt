package com.example.agent

import com.example.agent.tools.BuildTool
import com.example.agent.tools.FilePatchTool
import com.example.agent.tools.FileReadTool
import com.example.agent.tools.FileSearchTool
import com.example.agent.tools.FileWriteTool
import com.example.agent.tools.TerminalTool
import com.example.agent.tools.Tool
import com.example.agent.tools.ToolResult
import com.example.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Structured tools (file_read, file_write, file_patch, terminal_run, project_build).
 * v1.4: writes to existing files, patches and commands go through [approve] first (ApprovalPolicy);
 * without an approval callback they are refused rather than run silently.
 */
class ToolExecutor(
  private val approve: (suspend (ApprovalRequest) -> Boolean)? = null,
  private val settings: () -> com.example.data.model.SettingsState = { com.example.data.model.SettingsState() }
) {

  private val tools: Map<String, Tool> = listOf(
    FileSearchTool(),
    FileReadTool(),
    FileWriteTool(),
    FilePatchTool(),
    TerminalTool(),
    BuildTool()
  ).associateBy { it.name }

  fun getAvailableTools(): List<Tool> = tools.values.toList()

  suspend fun executeTool(
    toolName: String,
    arguments: Map<String, String>,
    project: Project
  ): ToolResult = withContext(Dispatchers.IO) {
    val tool = tools[toolName]
      ?: return@withContext ToolResult(
        success = false,
        output = "",
        error = "Tool '$toolName' not found. Available tools: ${tools.keys.joinToString(", ")}"
      )

    val kind: ActionKind? = when (toolName) {
      "terminal_run" -> ActionKind.COMMAND
      "file_patch" -> ActionKind.EDIT_FILE
      "file_write" -> {
        val p = arguments["path"].orEmpty()
        val f = if (p.startsWith("/")) java.io.File(p) else java.io.File(project.rootDir, p)
        if (f.exists()) ActionKind.EDIT_FILE else ActionKind.NEW_FILE
      }
      else -> null
    }
    if (kind != null && ApprovalPolicy.needsApproval(kind, settings())) {
      val gate = approve ?: return@withContext ToolResult(false, "", "'$toolName' needs user approval, but no approval UI is attached.")
      val item = if (kind == ActionKind.COMMAND) ApprovalItem(kind, command = arguments["command"])
      else ApprovalItem(kind, path = arguments["path"])
      if (!gate(ApprovalRequest(title = "Allow $toolName?", reason = "Proposed by the agent", items = listOf(item)))) {
        return@withContext ToolResult(false, "", "The user declined '$toolName'.")
      }
    }

    try {
      tool.execute(project, arguments)
    } catch (e: Exception) {
      ToolResult(
        success = false,
        output = "",
        error = "Exception in tool '$toolName': ${e.message}"
      )
    }
  }
}
