package com.example.agent

/** Splits a model reply into its <think> reasoning and the final answer (works while streaming). */
object Thinking {
  const val HINT =
    "\nThinking mode: first reason inside <think>...</think> in at most 8 short lines " +
      "(what is asked, the plan, edge cases). Then write the final answer after </think>. " +
      "Never put file blocks or code inside <think>."

  /** Returns (reasoning or null, answer). An unclosed <think> means the model is still thinking: answer is empty. */
  fun split(raw: String): Pair<String?, String> {
    val open = raw.indexOf("<think>")
    val close = raw.indexOf("</think>")
    return when {
      open >= 0 && close > open ->
        raw.substring(open + 7, close).trim() to (raw.substring(0, open) + raw.substring(close + 8)).trimStart()
      open >= 0 -> raw.substring(open + 7).trim() to raw.substring(0, open).trimStart()
      close >= 0 -> raw.substring(0, close).trim() to raw.substring(close + 8).trimStart() // template pre-filled <think>
      else -> null to raw
    }
  }
}
