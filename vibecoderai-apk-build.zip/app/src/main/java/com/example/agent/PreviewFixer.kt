package com.example.agent

import java.io.File

/**
 * Small models often forget to link their own files or to add a viewport. This makes index.html
 * runnable before it is previewed or packaged: doctype, charset, viewport, and any root-level
 * .css / .js file that exists but is not referenced.
 */
object PreviewFixer {
  fun prepare(root: File) {
    val index = File(root, "index.html")
    if (!index.isFile) {
      // The model wrote scripts or styles but forgot the page: create a minimal one so the app can run.
      val hasAssets = root.listFiles { f -> f.isFile && f.extension.lowercase() in setOf("js", "css") }?.isNotEmpty() == true
      if (!hasAssets) return
      runCatching {
        index.writeText("<!DOCTYPE html>\n<html lang=\"en\">\n<head></head>\n<body>\n<div id=\"app\"></div>\n</body>\n</html>\n")
      }
    }
    runCatching {
      val original = index.readText()
      var html = original

      if (!Regex("<html[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(html)) {
        html = "<html>\n<head></head>\n<body>\n$html\n</body>\n</html>"
      }
      if (!Regex("<!doctype", RegexOption.IGNORE_CASE).containsMatchIn(html)) html = "<!DOCTYPE html>\n$html"
      if (!html.contains("charset", ignoreCase = true)) html = inHead(html, "<meta charset=\"utf-8\">")
      if (!html.contains("name=\"viewport\"", ignoreCase = true) && !html.contains("name='viewport'", ignoreCase = true)) {
        html = inHead(html, "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
      }

      val files = root.listFiles { f -> f.isFile }?.sortedBy { it.name } ?: emptyList()
      for (f in files) {
        if (html.contains(f.name)) continue
        when (f.extension.lowercase()) {
          "css" -> html = inHead(html, "<link rel=\"stylesheet\" href=\"${f.name}\">")
          "js" -> html = beforeBodyEnd(html, "<script src=\"${f.name}\"></script>")
        }
      }

      if (html != original) index.writeText(html)
    }
  }

  private fun inHead(html: String, tag: String): String {
    val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
    if (head != null) return html.substring(0, head.range.last + 1) + "\n  " + tag + html.substring(head.range.last + 1)
    val root = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(html)
    return if (root != null) {
      html.substring(0, root.range.last + 1) + "\n<head>\n  $tag\n</head>" + html.substring(root.range.last + 1)
    } else "$tag\n$html"
  }

  private fun beforeBodyEnd(html: String, tag: String): String {
    val i = html.lastIndexOf("</body>", ignoreCase = true)
    return if (i >= 0) html.substring(0, i) + "  " + tag + "\n" + html.substring(i) else "$html\n$tag\n"
  }
}
