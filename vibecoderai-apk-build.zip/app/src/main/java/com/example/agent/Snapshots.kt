package com.example.agent

import java.io.File

/** Project versions: a copy of the files is taken before the AI changes anything, so a change can be undone. */
object Snapshots {
  private const val KEEP = 15

  fun take(root: File): String? = runCatching {
    val id = System.currentTimeMillis().toString()
    val dest = File(root, ".history/$id").apply { mkdirs() }
    root.walkTopDown()
      .onEnter { it == root || !it.name.startsWith(".") }
      .filter { it.isFile && !it.name.startsWith(".") && it.length() < 512 * 1024 }
      .forEach { f ->
        val t = File(dest, f.relativeTo(root).path)
        t.parentFile?.mkdirs()
        f.copyTo(t, overwrite = true)
      }
    File(root, ".history").listFiles()?.sortedBy { it.name }?.dropLast(KEEP)?.forEach { it.deleteRecursively() }
    id
  }.getOrNull()

  fun restore(root: File, id: String): Boolean = runCatching {
    val src = File(root, ".history/$id")
    if (!src.isDirectory) return false
    root.listFiles()?.filter { !it.name.startsWith(".") }?.forEach { it.deleteRecursively() }
    src.walkTopDown().filter { it.isFile }.forEach { f ->
      val t = File(root, f.relativeTo(src).path)
      t.parentFile?.mkdirs()
      f.copyTo(t, overwrite = true)
    }
    true
  }.getOrDefault(false)
}
