package com.example.agent

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * An agent skill is a short instruction pack added to the system prompt while it is switched on.
 * Built-in skills ship with the app; custom skills are written by the user and stored on the phone.
 * Only enabled skills cost tokens, and the total is capped so small models are not overloaded.
 */
data class Skill(
  val id: String,
  val name: String,
  val description: String,
  val prompt: String,
  val builtIn: Boolean,
  val defaultOn: Boolean = false,
  /** Also applied in plain chat (answers), not only when building. */
  val forChat: Boolean = false
)

object Skills {
  private var prefs: SharedPreferences? = null

  /** Bumped on every change so Compose screens re-read the list. */
  var version by mutableIntStateOf(0)
    private set

  private const val MAX_PROMPT_CHARS = 1500

  val builtIn: List<Skill> = listOf(
    Skill(
      "web-app", "Web app builder",
      "index.html + styles.css + app.js, correctly linked.",
      "Always create index.html, styles.css and app.js. index.html must contain <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">, " +
        "<link rel=\"stylesheet\" href=\"styles.css\"> and <script src=\"app.js\"></script> before </body>. " +
        "Every id or class used by app.js must exist in index.html. Code must run without errors.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "ui-polish", "Clean mobile UI",
      "Rounded cards, big tap targets, fits a 360 px screen.",
      "Design for a 360px wide phone: system-ui font, 16px padding, 14px rounded cards, buttons at least 44px tall, " +
        "flex or grid layout, no horizontal scroll, sizes in %, rem or vw (never fixed widths above 340px).",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "bug-fixer", "Bug fixer",
      "Fix errors by changing only what is broken.",
      "When fixing errors: read the error lines, change only what is broken, keep working code, and output the complete updated files.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "oled-dark", "OLED dark theme",
      "Black background, white text, iOS blue accent.",
      "Use a dark OLED theme: body background #000000, text #ffffff, cards #1c1c1e, accent #0a84ff, subtle 1px borders #2a2a2c.",
      builtIn = true
    ),
    Skill(
      "games", "Games and 3D",
      "Canvas or CSS 3D games with touch controls.",
      "For games use a canvas or CSS grid sized with min(100vw, 100vh), a requestAnimationFrame loop, touch and keyboard controls, " +
        "a score display and a restart button. For 3D use CSS 3D transforms or canvas math, no libraries.",
      builtIn = true
    ),
    Skill(
      "indian-ui", "Telugu / Indian language UI",
      "Correct lang attribute and fonts for Telugu, Hindi.",
      "Write UI text in the language the user asks for. For Telugu use <html lang=\"te\"> and font-family 'Noto Sans Telugu', system-ui, sans-serif; " +
        "for Hindi use lang=\"hi\". Keep text short and large (at least 16px).",
      builtIn = true
    ),
    Skill(
      "storage", "Offline data storage",
      "Save data in localStorage, no network.",
      "Persist user data with localStorage (JSON.stringify / JSON.parse inside try/catch). Never call network APIs or CDNs.",
      builtIn = true
    ),
    Skill(
      "concise-chat", "Short answers",
      "Brief, direct chat replies.",
      "In chat answer briefly and directly, in the same language the user writes in.",
      builtIn = true, defaultOn = true, forChat = true
    )
  )

  fun init(context: Context) {
    if (prefs == null) prefs = context.applicationContext.getSharedPreferences("agent_skills", Context.MODE_PRIVATE)
  }

  fun custom(): List<Skill> = runCatching {
    val arr = JSONArray(prefs?.getString("custom", "[]") ?: "[]")
    (0 until arr.length()).map { i ->
      val o = arr.getJSONObject(i)
      Skill(
        id = o.getString("id"),
        name = o.getString("name"),
        description = "Custom skill",
        prompt = o.getString("prompt"),
        builtIn = false,
        defaultOn = true,
        forChat = false
      )
    }
  }.getOrDefault(emptyList())

  fun all(): List<Skill> = builtIn + custom()

  fun isEnabled(skill: Skill): Boolean = prefs?.getBoolean("on_${skill.id}", skill.defaultOn) ?: skill.defaultOn

  fun setEnabled(skill: Skill, on: Boolean) {
    prefs?.edit()?.putBoolean("on_${skill.id}", on)?.apply()
    version++
  }

  fun addCustom(name: String, prompt: String) {
    if (name.isBlank() || prompt.isBlank()) return
    val arr = runCatching { JSONArray(prefs?.getString("custom", "[]") ?: "[]") }.getOrDefault(JSONArray())
    arr.put(JSONObject().put("id", "c_" + UUID.randomUUID().toString().take(8)).put("name", name.trim().take(40)).put("prompt", prompt.trim().take(600)))
    prefs?.edit()?.putString("custom", arr.toString())?.apply()
    version++
  }

  fun deleteCustom(id: String) {
    val arr = runCatching { JSONArray(prefs?.getString("custom", "[]") ?: "[]") }.getOrDefault(JSONArray())
    val kept = JSONArray()
    for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") != id) kept.put(arr.getJSONObject(i))
    prefs?.edit()?.putString("custom", kept.toString())?.apply()
    version++
  }

  /** Text appended to the system prompt: the enabled skills (chat mode only uses chat skills). */
  fun promptFor(chat: Boolean): String {
    val active = all().filter { isEnabled(it) && (!chat || it.forChat) }
    if (active.isEmpty()) return ""
    return ("\nSkills:\n" + active.joinToString("\n") { "- " + it.prompt }).take(MAX_PROMPT_CHARS)
  }
}
