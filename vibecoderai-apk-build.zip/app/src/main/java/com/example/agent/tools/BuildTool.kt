package com.example.agent.tools

import com.example.build.BuildRunner
import com.example.data.model.BuildStatus
import com.example.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class BuildTool(
  private val buildRunner: BuildRunner = BuildRunner()
) : Tool {
  override val name = "project_build"
  override val description = "Runs project compilation and error verification, returning structured diagnostics."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val buildResult = buildRunner.runBuild(project)

    if (buildResult.status == BuildStatus.SUCCESS) {
      ToolResult(
        success = true,
        output = "Build verified successfully!\nGenerated APK: ${buildResult.apkPath ?: "Verified"}\nDuration: ${buildResult.durationMs}ms",
        metadata = mapOf("apkPath" to (buildResult.apkPath ?: ""), "durationMs" to buildResult.durationMs)
      )
    } else {
      val errorReport = buildResult.errors.joinToString("\n") { err ->
        "- ${err.filePath}:${err.lineNumber}:${err.columnNumber}: ${err.errorMessage}"
      }
      ToolResult(
        success = false,
        output = buildResult.logs.takeLast(10).joinToString("\n"),
        error = "Build failed with ${buildResult.errors.size} error(s):\n$errorReport",
        metadata = mapOf("errorCount" to buildResult.errors.size)
      )
    }
  }
}
