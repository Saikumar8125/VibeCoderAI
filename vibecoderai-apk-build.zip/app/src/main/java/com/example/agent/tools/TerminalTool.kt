package com.example.agent.tools

import com.example.data.model.Project
import com.example.terminal.TerminalManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class TerminalTool(
  private val terminalManager: TerminalManager = TerminalManager()
) : Tool {
  override val name = "terminal_run"
  override val description = "Runs a sandboxed shell command inside the project workspace directory."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val command = arguments["command"] ?: return@withContext ToolResult(false, "", "Missing 'command' parameter.")
    val result = terminalManager.executeCommand(command, project.rootDir)

    if (result.exitCode == 0) {
      ToolResult(
        success = true,
        output = if (result.stdout.isNotEmpty()) result.stdout else "Command completed with exit code 0.",
        metadata = mapOf("exitCode" to result.exitCode, "durationMs" to result.durationMs)
      )
    } else {
      ToolResult(
        success = false,
        output = result.stdout,
        error = if (result.stderr.isNotEmpty()) result.stderr else "Process exited with code ${result.exitCode}",
        metadata = mapOf("exitCode" to result.exitCode, "durationMs" to result.durationMs)
      )
    }
  }
}
