package com.example.agent

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.data.model.TokenUsage
import com.example.data.model.ToolCallInfo
import com.example.llama.LlamaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AgentOrchestrator(
  private val context: Context,
  private val llamaEngine: LlamaEngine,
  private val contextManager: ContextManager = ContextManager(),
  private val selfRepairEngine: SelfRepairEngine = SelfRepairEngine(),
  private val terminalManager: com.example.terminal.TerminalManager = com.example.terminal.TerminalManager(),
  private val buildRunner: com.example.build.BuildRunner = com.example.build.BuildRunner(),
  /** v1.4: called after every local/remote generation with its token usage (logged to Room). */
  private val onUsage: (TokenUsage) -> Unit = {}
) {

  /** v1.4: every overwrite/edit/delete and every agent command waits here for the user's answer. */
  val approvals = ApprovalGate()
  private val toolExecutor: ToolExecutor = ToolExecutor(approve = { approvals.request(it) })

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _telemetry = MutableStateFlow(TelemetryData())
  val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

  private val _pendingPatch = MutableStateFlow<PatchProposal?>(null)
  val pendingPatch: StateFlow<PatchProposal?> = _pendingPatch.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  private val _activity = MutableStateFlow<List<String>>(emptyList())
  /** Live feed of what the agent is doing right now (cleared at the start of every request). */
  val activity: StateFlow<List<String>> = _activity.asStateFlow()
  private fun log(line: String) { _activity.value = (_activity.value + line).takeLast(40) }

  init {
    _messages.value = listOf(
      ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Say hi or ask me anything. Describe an app and I will build it. Everything runs offline on this phone."
      )
    )
  }

  private var job: Job? = null

  /** Id of the conversation on screen; each conversation is saved under its own id. */
  @Volatile
  var chatId: String = UUID.randomUUID().toString()
    private set

  /** False in a fresh chat: its first build request gets its own new project instead of overwriting the last one. */
  @Volatile
  var useActiveProject: Boolean = false

  private val snapIds = java.util.concurrent.ConcurrentHashMap<String, String>()

  fun canUndo(messageId: String): Boolean = snapIds.containsKey(messageId)

  /** Restores the project files to how they were before this reply changed them. */
  fun undoChanges(messageId: String, project: Project) {
    val snap = snapIds[messageId] ?: return
    if (Snapshots.restore(project.rootDir, snap)) {
      snapIds.remove(messageId)
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = m.fileChanges.map { it.copy(status = ChangeStatus.DISCARDED) }) else m
      }
    }
  }

  /** Drops the last reply and asks again. */
  fun regenerate(project: Project?, settings: SettingsState, scope: CoroutineScope) {
    if (_isGenerating.value) return
    val msgs = _messages.value
    val idx = msgs.indexOfLast { it.sender == MessageSender.USER }
    if (idx < 0) return
    val text = msgs[idx].content
    _messages.value = msgs.take(idx)
    sendMessage(text, project, settings, scope)
  }

  /** Adds an assistant note to the chat (e.g. "Project created from template"). */
  fun addNote(text: String) {
    log(text.lineSequence().first().take(80))
    _messages.value = _messages.value + ChatMessage(id = UUID.randomUUID().toString(), sender = MessageSender.AGENT, content = text, thoughts = "note")
  }

  /** Starts a fresh conversation (keeps the welcome message). The old one stays in history. */
  fun newChat() {
    if (_isGenerating.value) return
    useActiveProject = false
    chatId = UUID.randomUUID().toString()
    _messages.value = _messages.value.take(1)
  }

  /** Shows a saved conversation. */
  fun openChat(id: String, history: List<ChatMessage>) {
    if (_isGenerating.value) return
    val welcome = _messages.value[0].content
    val clean = history.filter { !(it.sender == MessageSender.AGENT && (it.content == welcome || it.content.isBlank() && it.fileChanges.isEmpty())) }
    chatId = id
    useActiveProject = true
    _messages.value = _messages.value.take(1) + clean.map { it.copy(isStreaming = false) }
  }

  /** Cancels the running generation (also stops the native model). */
  fun stop() {
    llamaEngine.stopNow()
    approvals.rejectAll()
    job?.cancel()
    // Do not wait for the native thread: the UI becomes usable immediately.
    _isGenerating.value = false
  }

  fun sendMessage(
    userText: String,
    project: Project?,
    settings: SettingsState,
    scope: CoroutineScope,
    displayText: String? = null
  ) {
    if (userText.isBlank() || _isGenerating.value) return

    val raw = displayText ?: userText
    // "continue" / "retry" re-runs the last real request instead of being answered as small talk.
    val redo = raw.trim().lowercase().trimEnd('.', '!') in setOf("continue", "retry", "try again", "again", "go on", "resume")
    val previous = if (redo) _messages.value.lastOrNull { it.sender == MessageSender.USER && it.content.length > 20 }?.content else null
    val task = previous ?: userText
    val mode = Intent.classify(previous ?: raw)
    val history = if (mode == Intent.Mode.CHAT) recentExchanges() else emptyList()

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.USER,
      content = displayText ?: userText
    )
    _activity.value = emptyList()
    log("Request received")
    _isGenerating.value = true
    val role = AgentRoles.from(settings.agentRole)
    job = scope.launch(Dispatchers.IO) {
      if (role.id != "builder" && project != null && raw.trim().length > 12) {
        runAgentLoop(role, task, project, settings)
      } else if (project != null && Intent.isFixRequest(raw) && java.io.File(project.rootDir, "index.html").isFile) {
        runFix(raw, project, settings)
      } else if (mode == Intent.Mode.BUILD && project != null && settings.autonomous) {
        runAutonomous(task, project, settings)
      } else {
        processAgentResponse(task, if (mode == Intent.Mode.BUILD) project else null, settings, mode, history)
      }
    }
  }

  /** Short build plan (2 to 4 steps) from the model; empty if it cannot make one. */
  private suspend fun planSteps(goal: String, settings: SettingsState): List<String> {
    val text = StringBuilder()
    runCatching {
      llamaEngine.generateCompletionStream(
        prompt = goal,
        settings = settings.copy(maxOutputTokens = 220),
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = true,
        history = emptyList(),
        systemOverride = PLAN_PROMPT
      ).collect { text.append(it) }
    }.onFailure { if (it is kotlinx.coroutines.CancellationException) throw it }
    return Regex("""(?m)^\s*\d+[.)]\s*(.{4,160})$""").findAll(text)
      .map { it.groupValues[1].trim() }
      .filter { !it.contains("test", ignoreCase = true) }
      .take(3).toList()
  }

  /** Plan, build every step, run the app headlessly, and repair JavaScript errors until clean or out of attempts. */
  private suspend fun runAutonomous(goal: String, project: Project, settings: SettingsState) {
    // v1.4: no auto-approve. Overwrites still wait for the user (ApprovalPolicy).
    val auto = settings
    try {
      addNote("Working on it. I will plan, build, then test the app myself.")
      val steps = planSteps(goal, settings)
      val list = if (steps.size >= 2) steps else listOf(goal)
      if (steps.size >= 2) addNote("Plan:\n" + steps.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n"))
      list.forEachIndexed { i, step ->
        if (list.size > 1) addNote("Step ${i + 1} of ${list.size}: $step")
        val prompt = if (list.size > 1) "Overall goal: $goal\nDo only this step (${i + 1} of ${list.size}): $step\nOutput the complete file(s) for this step in <file path=\"...\"> blocks." else goal
        processAgentResponse(prompt, project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true)
      }
      testAndRepair(project, auto, settings)
    } finally {
      _isGenerating.value = false
    }
  }

  private suspend fun testAndRepair(project: Project, auto: SettingsState, settings: SettingsState) {
    var attempt = 0
    while (true) {
      addNote("Testing the app...")
      val errors = HeadlessCheck.run(context, project.rootDir)
      if (errors.isEmpty()) {
        addNote("Done. The app loaded with no errors. Tap Preview to try it.")
        return
      }
      if (attempt >= settings.maxRepairRetries) {
        addNote("Stopped after $attempt fix attempts. Remaining problems:\n" + errors.take(3).joinToString("\n") + "\nTap Regenerate or describe what to fix.")
        return
      }
      attempt++
      addNote("Found ${errors.size} problem(s). Fixing, attempt $attempt of ${settings.maxRepairRetries}.")
      processAgentResponse(
        "Fix these errors in the app. Output only the files that change.\n" + errors.take(5).joinToString("\n"),
        project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true
      )
      if (lastApprovalDeclined) {
        addNote("Fix not applied because you declined it. Stopping here.")
        return
      }
    }
  }

  /** "app not working": test the current project first so the model fixes real problems, then verify again. */
  private suspend fun runFix(complaint: String, project: Project, settings: SettingsState) {
    val auto = settings
    try {
      addNote("Checking the app to find what is wrong...")
      val errors = HeadlessCheck.run(context, project.rootDir)
      addNote(if (errors.isEmpty()) "No script errors, so I will look for display and logic problems." else "Found ${errors.size} problem(s). Fixing.")
      val found = if (errors.isEmpty())
        "Testing found no JavaScript errors, so find why nothing shows or works: empty containers, missing render calls, wrong element ids, missing event listeners."
      else "Problems found by testing:\n" + errors.take(5).joinToString("\n")
      processAgentResponse(
        "The user says: \"$complaint\".\n$found\nFix the app. Output only the files that change.",
        project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true
      )
      testAndRepair(project, auto, settings)
    } finally {
      _isGenerating.value = false
    }
  }

  /** Token-lean prompt: the task plus the current project files (which already hold all state, so no chat history). */
  private fun buildPrompt(userText: String, project: Project?, settings: SettingsState): String {
    val promptTokens = (settings.contextLength - settings.maxOutputTokens - 350).coerceAtLeast(300)
    val snapshotBudget = (promptTokens * 3 - userText.length - 100).coerceIn(0, 9000)
    val snapshot = if (project != null && snapshotBudget > 200) ProjectFiles.snapshot(project.rootDir, snapshotBudget, userText) else ""
    return buildString {
      if (snapshot.isNotBlank()) append("Current project files:\n").append(snapshot).append("\n")
      append("Task: ").append(userText)
    }
  }

  /** Last two exchanges (trimmed) so follow-up questions in plain chat keep their context. */
  private fun recentExchanges(): List<Pair<String, String>> =
    _messages.value.drop(1)
      .filter { it.content.isNotBlank() && !it.isStreaming }
      .takeLast(4)
      .map { m ->
        val role = if (m.sender == MessageSender.USER) "user" else "assistant"
        role to FileBlocks.displayText(m.content).take(500)
      }

  private suspend fun processAgentResponse(
    userText: String,
    project: Project?,
    settings: SettingsState,
    mode: Intent.Mode,
    history: List<Pair<String, String>>,
    keepBusy: Boolean = false,
    systemOverride: String? = null,
    rawPrompt: Boolean = false
  ): String {
    val agentMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = agentMsgId,
      sender = MessageSender.AGENT,
      content = "",
      isStreaming = true
    )

    val buffer = StringBuilder()
    var lastUiUpdate = 0L
    var loggedFiles = 0
    var thinkStart = 0L
    var thinkLogged = false
    log(if (_telemetry.value.outputTokens == 0) "Reading prompt" else "Generating")
    var cancelled: kotlinx.coroutines.CancellationException? = null
    val genStart = System.currentTimeMillis()
    val telemetryBefore = _telemetry.value
    try {
      llamaEngine.generateCompletionStream(
        prompt = if (mode == Intent.Mode.CHAT || rawPrompt) userText else buildPrompt(userText, project, settings),
        settings = settings,
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = mode == Intent.Mode.CHAT,
        history = history,
        systemOverride = systemOverride
      ).collect { chunk ->
        buffer.append(chunk)
        if (buffer.length > 120 && buffer.length % 16 == 0 && isLooping(buffer)) throw LoopStop()
        // Redrawing and re-parsing markdown on every token is what makes the UI stutter: update ~10x/second.
        val now = System.currentTimeMillis()
        if (now - lastUiUpdate >= (if (buffer.length > 1500) 250L else 100L)) {
          lastUiUpdate = now
          val (th, ans) = Thinking.split(buffer.toString())
          if (th != null && !thinkLogged) { thinkLogged = true; thinkStart = now; log("Thinking") }
          if (th != null && ans.isNotEmpty() && thinkStart > 0) { log("Thought for ${(now - thinkStart) / 1000}s"); thinkStart = 0 }
          val fc = FILE_OPEN.findAll(ans).count()
          if (fc > loggedFiles) {
            FILE_OPEN.findAll(ans).drop(loggedFiles).forEach { log("Writing ${it.groupValues[1]}") }
            loggedFiles = fc
          }
          updateMessageContent(agentMsgId, ans, isStreaming = true, reasoning = th)
        }
      }
    } catch (e: LoopStop) {
      val keep = buffer.lastIndexOf(" ", maxOf(0, buffer.length - 60)).coerceAtLeast(0)
      buffer.setLength(minOf(buffer.length, maxOf(keep, 40)))
      buffer.append("\n\n[Stopped: the model started repeating itself. Try a bigger model or a shorter prompt.]")
    } catch (e: kotlinx.coroutines.CancellationException) {
      buffer.append(if (buffer.isEmpty()) "[Stopped]" else "\n\n[Stopped]")
      cancelled = e
    } catch (t: Throwable) {
      val msg = if (t is java.net.ConnectException || t is java.net.UnknownHostException || t is java.net.SocketTimeoutException)
        "Cannot reach the remote server (${t.message}). Open Models and switch to \"On this phone\", or start your server."
      else "${t.javaClass.simpleName}: ${t.message}"
      buffer.append("\n\n[Error: $msg]")
    }
    // v1.4: no `return` inside finally any more (it swallowed CancellationException, so Stop did not
    // really stop multi-step flows). The message is finalised, then cancellation is re-thrown.
    val (th, ans) = Thinking.split(buffer.toString())
    val answer = if (ans.isEmpty() && th != null) "[The model only wrote its reasoning. Try again or turn Thinking off.]" else if (ans.isEmpty()) "[The model returned no text.]" else ans
    val needApproval = finishMessage(agentMsgId, answer, project, settings, th)
    log("Reply done")
    // Log usage only when this generation produced telemetry (not the previous reply's numbers again).
    if (_telemetry.value !== telemetryBefore) recordUsage(genStart)
    if (cancelled != null) {
      if (!keepBusy) _isGenerating.value = false
      throw cancelled
    }
    lastApprovalDeclined = false
    try {
      if (project != null && needApproval.isNotEmpty()) awaitFileApproval(agentMsgId, project, needApproval)
    } finally {
      if (!keepBusy) _isGenerating.value = false
    }
    return answer
  }

  /** True when the user declined the last file approval (autonomous repair stops instead of looping). */
  @Volatile
  private var lastApprovalDeclined = false

  private fun recordUsage(start: Long) {
    val t = _telemetry.value
    if (t.outputTokens <= 0 && t.inputTokens <= 0) return
    runCatching {
      onUsage(
        TokenUsage(
          promptTokens = t.inputTokens,
          outputTokens = t.outputTokens,
          tokensPerSecond = t.tokensPerSecond,
          cachedTokens = t.cachedTokens,
          exact = t.promptExact,
          model = t.modelName.ifBlank { t.activeBackend },
          timestamp = System.currentTimeMillis(),
          durationMs = System.currentTimeMillis() - start
        )
      )
    }
  }

  /**
   * Shows the approval dialog for file changes that need it and waits. Approve writes them (with an
   * undo snapshot); reject marks them discarded. Cancellation (Stop) leaves them pending in the card.
   */
  private suspend fun awaitFileApproval(messageId: String, project: Project, changes: List<FileChange>) {
    log("Waiting for your approval")
    val items = changes.map { c ->
      val f = ProjectFiles.resolve(project.rootDir, c.path)
      val old = if (f != null && f.isFile) runCatching { f.readText() }.getOrDefault("") else ""
      ApprovalItem(if (c.isNew) ActionKind.NEW_FILE else ActionKind.EDIT_FILE, path = c.path, diff = com.example.patch.LineDiff.diff(old, c.content))
    }
    val approved = approvals.request(
      ApprovalRequest(
        title = if (changes.size == 1) "Apply changes to ${changes[0].path}?" else "Apply changes to ${changes.size} files?",
        reason = "The agent wants to change existing files.",
        items = items,
        messageId = messageId
      )
    )
    if (approved) {
      writeApproved(messageId, project)
    } else {
      lastApprovalDeclined = true
      discardPending(messageId)
      log("Changes declined")
    }
  }

  private fun writeApproved(messageId: String, project: Project) {
    // Keep the earliest snapshot of this reply, so Undo restores the state before any of its writes.
    Snapshots.take(project.rootDir)?.let { snapIds.putIfAbsent(messageId, it) }
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
    }
    PreviewFixer.prepare(project.rootDir)
  }

  /**
   * Specialist agent loop: the model may call tools (read_file, search, run_check...) one at a time;
   * each result is fed back until it gives a final answer or the turn limit is reached.
   */
  private suspend fun runAgentLoop(role: AgentRole, task: String, project: Project, settings: SettingsState) {
    val env = ToolEnv(settings, terminalManager, buildRunner, role.canWrite) { approvals.request(it) }
    try {
      addNote("${role.name} agent is working.")
      val results = StringBuilder()
      val maxTurns = 5
      for (turn in 1..maxTurns) {
        val files = AgentTools.execute(context, project, ToolCall("ListFiles", ""), env)
        val prompt = buildString {
          append("Task: ").append(task).append("\n\nProject files:\n").append(files)
          if (results.isNotEmpty()) append("\n\nTool results so far:\n").append(results)
          if (turn == maxTurns) append("\n\nNo more tools. Give your final answer now.")
        }
        val text = processAgentResponse(
          prompt, if (role.canWrite) project else null, settings, Intent.Mode.BUILD, emptyList(),
          keepBusy = true, systemOverride = role.system + Skills.promptFor(false), rawPrompt = true
        )
        val call = ToolCalls.parse(text)
        if (call == null || turn == maxTurns) break
        addNote("Tool: ${call.name}" + if (call.arg.isNotBlank()) " ${call.arg.take(40)}" else "")
        log("Running ${call.name}")
        val out = AgentTools.execute(context, project, call, env)
        results.append("[").append(call.name).append(" ").append(call.arg.trim()).append("]\n").append(out.take(2500)).append("\n\n")
        if (results.length > 5000) results.delete(0, results.length - 5000)
      }
      if (role.canWrite) {
        val errors = HeadlessCheck.run(context, project.rootDir)
        addNote(if (errors.isEmpty()) "Tested the app: no errors." else "Still ${errors.size} problem(s): " + errors.take(2).joinToString(" | "))
      }
    } finally {
      _isGenerating.value = false
    }
  }

  /**
   * Extracts file blocks from the reply. v1.4: changes that ApprovalPolicy allows (new files with
   * "Auto-approve new files", edits with "Auto-approve safe edits") are written now; the rest stay
   * PENDING and are returned so the caller can wait for the user's approval.
   */
  private fun finishMessage(id: String, text: String, project: Project?, settings: SettingsState, reasoning: String? = null): List<FileChange> {
    val changes = if (project == null) emptyList() else FileBlocks.parse(text).map { p ->
      val target = ProjectFiles.resolve(project.rootDir, p.path)
      FileChange(path = p.path, content = p.content, isNew = target == null || !target.exists())
    }
    val auto = changes.filter { !ApprovalPolicy.needsApproval(if (it.isNew) ActionKind.NEW_FILE else ActionKind.EDIT_FILE, settings) }
    val ask = changes.filter { it !in auto }
    var finalChanges = changes
    if (project != null && auto.isNotEmpty()) {
      Snapshots.take(project.rootDir)?.let { snapIds[id] = it }
      val written = writeChanges(project, auto)
      finalChanges = changes.map { c -> written.getOrNull(auto.indexOf(c)) ?: c }
      PreviewFixer.prepare(project.rootDir)
    }
    _messages.value = _messages.value.map { m ->
      if (m.id == id) m.copy(content = text, isStreaming = false, fileChanges = finalChanges, reasoning = reasoning) else m
    }
    return ask
  }

  private fun writeChanges(project: Project, changes: List<FileChange>): List<FileChange> =
    changes.map { c ->
      if (c.status != ChangeStatus.PENDING) c
      else ProjectFiles.write(project.rootDir, c).fold(
        onSuccess = { c.copy(status = ChangeStatus.APPLIED) },
        onFailure = { e -> c.copy(status = ChangeStatus.FAILED, error = e.message) }
      )
    }

  fun applyChanges(messageId: String, project: Project, scope: CoroutineScope) {
    // The agent is waiting on this message's approval: answering it lets the agent write and continue.
    if (approvals.resolveForMessage(messageId, true)) return
    scope.launch(Dispatchers.IO) {
      Snapshots.take(project.rootDir)?.let { snapIds.putIfAbsent(messageId, it) }
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
      }
      PreviewFixer.prepare(project.rootDir)
    }
  }

  fun discardChanges(messageId: String) {
    if (approvals.resolveForMessage(messageId, false)) return
    discardPending(messageId)
  }

  private fun discardPending(messageId: String) {
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) {
        m.copy(fileChanges = m.fileChanges.map { c ->
          if (c.status == ChangeStatus.PENDING) c.copy(status = ChangeStatus.DISCARDED) else c
        })
      } else m
    }
  }

  private suspend fun runBuildWorkflow(project: Project) {
    val buildMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = buildMsgId,
      sender = MessageSender.TOOL,
      content = "Executing Gradle build verification for '${project.name}'...",
      toolCall = ToolCallInfo("project_build", mapOf("project" to project.name), "running")
    )

    val toolResult = toolExecutor.executeTool("project_build", emptyMap(), project)
    val updatedToolCall = ToolCallInfo(
      toolName = "project_build",
      arguments = mapOf("project" to project.name),
      status = if (toolResult.success) "success" else "error",
      resultSummary = if (toolResult.success) "Build Successful" else "Build Failed"
    )

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = if (toolResult.success) {
        "Build succeeded!\n${toolResult.output}"
      } else {
        "Build failed. Found errors:\n${toolResult.error}\n\nSay 'repair' to run the 10-step Self-Repair Engine."
      },
      toolCall = updatedToolCall
    )
  }

  private suspend fun runSelfRepairWorkflow(project: Project, settings: SettingsState) {
    val buildRes = selfRepairEngine.rebuildAndVerify(project)

    if (buildRes.errors.isEmpty()) {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: No errors found in workspace. All source files compiled cleanly!"
      )
      return
    }

    val activeError = buildRes.errors.first()
    val patch = selfRepairEngine.generateTargetedPatch(activeError, project)

    if (patch != null) {
      _pendingPatch.value = patch
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Diagnosed error in ${patch.relativePath} at line ${patch.startLine}:\n" +
            "Error: ${activeError.errorMessage}\n" +
            "Rationale: ${patch.rationale}\n\n" +
            "I have prepared a targeted surgical patch. Please review the diff below and approve to apply:",
        patchProposal = patch
      )
    } else {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: Detected error '${activeError.errorMessage}', but unable to generate safe surgical patch automatically."
      )
    }
  }

  fun approveAndApplyPatch(proposal: PatchProposal, project: Project, scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      val success = selfRepairEngine.applyPatch(proposal, project)
      _pendingPatch.value = null

      if (success) {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Patch successfully applied to ${proposal.relativePath}. Rebuilding to verify..."
        )
        // Verify rebuild
        val verifyBuild = selfRepairEngine.rebuildAndVerify(project)
        if (verifyBuild.errors.isEmpty()) {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification PASSED: Project built cleanly without errors!"
          )
        } else {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification FAILED: ${verifyBuild.errors.size} remaining error(s). Unresolved: ${verifyBuild.errors.first().errorMessage}"
          )
        }
      } else {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Failed to apply patch to ${proposal.relativePath}."
        )
      }
    }
  }

  fun rejectPatch(proposal: PatchProposal) {
    _pendingPatch.value = null
    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = "Patch proposal for ${proposal.relativePath} was declined by user."
    )
  }

  private fun updateMessageContent(id: String, newContent: String, isStreaming: Boolean, reasoning: String? = null) {
    _messages.value = _messages.value.map { msg ->
      if (msg.id == id) msg.copy(content = newContent, isStreaming = isStreaming, reasoning = reasoning ?: msg.reasoning) else msg
    }
  }

  companion object {
    private val FILE_OPEN = Regex("<file\\s+path=\"([^\"]+)\"")
    private const val PLAN_PROMPT =
      "You plan small web apps made of index.html, styles.css and app.js. " +
        "Break the request into 2 or 3 build steps. Each step is one short line that names the file it writes, " +
        "for example: 1. index.html: page structure. " +
        "Output only the numbered list. No code and no testing step."
  }
}

private class LoopStop : RuntimeException()

/** True when the tail of the text is the same short chunk repeated 4+ times (small models do this). */
private fun isLooping(b: CharSequence): Boolean {
  val n = b.length
  for (len in intArrayOf(4, 8, 14, 24, 40)) {
    if (n < len * 4) continue
    val tail = b.subSequence(n - len, n).toString()
    var ok = true
    for (k in 2..4) if (b.subSequence(n - len * k, n - len * (k - 1)).toString() != tail) { ok = false; break }
    if (ok) return true
  }
  return false
}
