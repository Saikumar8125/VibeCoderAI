package com.example.agent

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.data.model.ToolCallInfo
import com.example.llama.LlamaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AgentOrchestrator(
  private val context: Context,
  private val llamaEngine: LlamaEngine,
  private val toolExecutor: ToolExecutor = ToolExecutor(),
  private val contextManager: ContextManager = ContextManager(),
  private val selfRepairEngine: SelfRepairEngine = SelfRepairEngine()
) {

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _telemetry = MutableStateFlow(TelemetryData())
  val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

  private val _pendingPatch = MutableStateFlow<PatchProposal?>(null)
  val pendingPatch: StateFlow<PatchProposal?> = _pendingPatch.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  init {
    _messages.value = listOf(
      ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Say hi or ask me anything. Describe an app and I will build it. Everything runs offline on this phone."
      )
    )
  }

  private var job: Job? = null

  /** Id of the conversation on screen; each conversation is saved under its own id. */
  @Volatile
  var chatId: String = UUID.randomUUID().toString()
    private set

  /** False in a fresh chat: its first build request gets its own new project instead of overwriting the last one. */
  @Volatile
  var useActiveProject: Boolean = false

  private val snapIds = java.util.concurrent.ConcurrentHashMap<String, String>()

  fun canUndo(messageId: String): Boolean = snapIds.containsKey(messageId)

  /** Restores the project files to how they were before this reply changed them. */
  fun undoChanges(messageId: String, project: Project) {
    val snap = snapIds[messageId] ?: return
    if (Snapshots.restore(project.rootDir, snap)) {
      snapIds.remove(messageId)
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = m.fileChanges.map { it.copy(status = ChangeStatus.DISCARDED) }) else m
      }
    }
  }

  /** Drops the last reply and asks again. */
  fun regenerate(project: Project?, settings: SettingsState, scope: CoroutineScope) {
    if (_isGenerating.value) return
    val msgs = _messages.value
    val idx = msgs.indexOfLast { it.sender == MessageSender.USER }
    if (idx < 0) return
    val text = msgs[idx].content
    _messages.value = msgs.take(idx)
    sendMessage(text, project, settings, scope)
  }

  /** Adds an assistant note to the chat (e.g. "Project created from template"). */
  fun addNote(text: String) {
    _messages.value = _messages.value + ChatMessage(id = UUID.randomUUID().toString(), sender = MessageSender.AGENT, content = text)
  }

  /** Starts a fresh conversation (keeps the welcome message). The old one stays in history. */
  fun newChat() {
    if (_isGenerating.value) return
    useActiveProject = false
    chatId = UUID.randomUUID().toString()
    _messages.value = _messages.value.take(1)
  }

  /** Shows a saved conversation. */
  fun openChat(id: String, history: List<ChatMessage>) {
    if (_isGenerating.value) return
    val welcome = _messages.value[0].content
    val clean = history.filter { !(it.sender == MessageSender.AGENT && (it.content == welcome || it.content.isBlank() && it.fileChanges.isEmpty())) }
    chatId = id
    useActiveProject = true
    _messages.value = _messages.value.take(1) + clean.map { it.copy(isStreaming = false) }
  }

  /** Cancels the running generation (also stops the native model). */
  fun stop() {
    llamaEngine.stopNow()
    job?.cancel()
    // Do not wait for the native thread: the UI becomes usable immediately.
    _isGenerating.value = false
  }

  fun sendMessage(
    userText: String,
    project: Project?,
    settings: SettingsState,
    scope: CoroutineScope,
    displayText: String? = null
  ) {
    if (userText.isBlank() || _isGenerating.value) return

    val raw = displayText ?: userText
    // "continue" / "retry" re-runs the last real request instead of being answered as small talk.
    val redo = raw.trim().lowercase().trimEnd('.', '!') in setOf("continue", "retry", "try again", "again", "go on", "resume")
    val previous = if (redo) _messages.value.lastOrNull { it.sender == MessageSender.USER && it.content.length > 20 }?.content else null
    val task = previous ?: userText
    val mode = Intent.classify(previous ?: raw)
    val history = if (mode == Intent.Mode.CHAT) recentExchanges() else emptyList()

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.USER,
      content = displayText ?: userText
    )
    _isGenerating.value = true
    val role = AgentRoles.from(settings.agentRole)
    job = scope.launch(Dispatchers.IO) {
      if (role.id != "builder" && project != null && raw.trim().length > 12) {
        runAgentLoop(role, task, project, settings)
      } else if (mode == Intent.Mode.BUILD && project != null && settings.autonomous) {
        runAutonomous(task, project, settings)
      } else {
        processAgentResponse(task, if (mode == Intent.Mode.BUILD) project else null, settings, mode, history)
      }
    }
  }

  /** Short build plan (2 to 4 steps) from the model; empty if it cannot make one. */
  private suspend fun planSteps(goal: String, settings: SettingsState): List<String> {
    val text = StringBuilder()
    runCatching {
      llamaEngine.generateCompletionStream(
        prompt = goal,
        settings = settings.copy(maxOutputTokens = 220),
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = true,
        history = emptyList(),
        systemOverride = PLAN_PROMPT
      ).collect { text.append(it) }
    }.onFailure { if (it is kotlinx.coroutines.CancellationException) throw it }
    return Regex("""(?m)^\s*\d+[.)]\s*(.{4,160})$""").findAll(text)
      .map { it.groupValues[1].trim() }
      .take(4).toList()
  }

  /** Plan, build every step, run the app headlessly, and repair JavaScript errors until clean or out of attempts. */
  private suspend fun runAutonomous(goal: String, project: Project, settings: SettingsState) {
    val auto = settings.copy(requireApprovalForDestructive = false)
    try {
      addNote("Working on it. I will plan, build, then test the app myself.")
      val steps = planSteps(goal, settings)
      val list = if (steps.size >= 2) steps else listOf(goal)
      if (steps.size >= 2) addNote("Plan:\n" + steps.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n"))
      list.forEachIndexed { i, step ->
        if (list.size > 1) addNote("Step ${i + 1} of ${list.size}: $step")
        val prompt = if (list.size > 1) "Overall goal: $goal\nDo only this step (${i + 1} of ${list.size}): $step" else goal
        processAgentResponse(prompt, project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true)
      }
      var attempt = 0
      while (true) {
        addNote("Testing the app...")
        val errors = HeadlessCheck.run(context, project.rootDir)
        if (errors.isEmpty()) {
          addNote("Done. The app loaded with no errors. Tap Preview to try it.")
          break
        }
        if (attempt >= settings.maxRepairRetries) {
          addNote("Stopped after $attempt fix attempts. Remaining problems:\n" + errors.take(3).joinToString("\n") + "\nTap Regenerate or describe what to fix.")
          break
        }
        attempt++
        addNote("Found ${errors.size} problem(s). Fixing, attempt $attempt of ${settings.maxRepairRetries}.")
        processAgentResponse(
          "Fix these errors in the app. Output only the files that change.\n" + errors.take(5).joinToString("\n"),
          project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true
        )
      }
    } finally {
      _isGenerating.value = false
    }
  }

  /** Token-lean prompt: the task plus the current project files (which already hold all state, so no chat history). */
  private fun buildPrompt(userText: String, project: Project?, settings: SettingsState): String {
    val promptTokens = (settings.contextLength - settings.maxOutputTokens - 350).coerceAtLeast(300)
    val snapshotBudget = (promptTokens * 3 - userText.length - 100).coerceIn(0, 9000)
    val snapshot = if (project != null && snapshotBudget > 200) ProjectFiles.snapshot(project.rootDir, snapshotBudget) else ""
    return buildString {
      if (snapshot.isNotBlank()) append("Current project files:\n").append(snapshot).append("\n")
      append("Task: ").append(userText)
    }
  }

  /** Last two exchanges (trimmed) so follow-up questions in plain chat keep their context. */
  private fun recentExchanges(): List<Pair<String, String>> =
    _messages.value.drop(1)
      .filter { it.content.isNotBlank() && !it.isStreaming }
      .takeLast(4)
      .map { m ->
        val role = if (m.sender == MessageSender.USER) "user" else "assistant"
        role to FileBlocks.displayText(m.content).take(500)
      }

  private suspend fun processAgentResponse(
    userText: String,
    project: Project?,
    settings: SettingsState,
    mode: Intent.Mode,
    history: List<Pair<String, String>>,
    keepBusy: Boolean = false,
    systemOverride: String? = null,
    rawPrompt: Boolean = false
  ): String {
    val agentMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = agentMsgId,
      sender = MessageSender.AGENT,
      content = "",
      isStreaming = true
    )

    val buffer = StringBuilder()
    var lastUiUpdate = 0L
    try {
      llamaEngine.generateCompletionStream(
        prompt = if (mode == Intent.Mode.CHAT || rawPrompt) userText else buildPrompt(userText, project, settings),
        settings = settings,
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = mode == Intent.Mode.CHAT,
        history = history,
        systemOverride = systemOverride
      ).collect { chunk ->
        buffer.append(chunk)
        // Redrawing and re-parsing markdown on every token is what makes the UI stutter: update ~10x/second.
        val now = System.currentTimeMillis()
        if (now - lastUiUpdate >= 100) {
          lastUiUpdate = now
          updateMessageContent(agentMsgId, buffer.toString(), isStreaming = true)
        }
      }
    } catch (e: kotlinx.coroutines.CancellationException) {
      buffer.append("\n\n[Stopped]")
      throw e
    } catch (t: Throwable) {
      buffer.append("\n\n[Error: ${t.javaClass.simpleName}: ${t.message}]")
    } finally {
      if (buffer.isEmpty()) buffer.append("[The model returned no text.]")
      finishMessage(agentMsgId, buffer.toString(), project, settings)
      if (!keepBusy) _isGenerating.value = false
    }
    return buffer.toString()
  }

  /**
   * Specialist agent loop: the model may call tools (read_file, search, run_check...) one at a time;
   * each result is fed back until it gives a final answer or the turn limit is reached.
   */
  private suspend fun runAgentLoop(role: AgentRole, task: String, project: Project, settings: SettingsState) {
    val auto = settings.copy(requireApprovalForDestructive = false)
    try {
      addNote("${role.name} agent is working.")
      val results = StringBuilder()
      val maxTurns = 5
      for (turn in 1..maxTurns) {
        val files = AgentTools.execute(context, project, ToolCall("list_files", ""))
        val prompt = buildString {
          append("Task: ").append(task).append("\n\nProject files:\n").append(files)
          if (results.isNotEmpty()) append("\n\nTool results so far:\n").append(results)
          if (turn == maxTurns) append("\n\nNo more tools. Give your final answer now.")
        }
        val text = processAgentResponse(
          prompt, if (role.canWrite) project else null, auto, Intent.Mode.BUILD, emptyList(),
          keepBusy = true, systemOverride = role.system + Skills.promptFor(false), rawPrompt = true
        )
        val call = ToolCalls.parse(text)
        if (call == null || turn == maxTurns) break
        addNote("Tool: ${call.name}" + if (call.arg.isNotBlank()) " ${call.arg.take(40)}" else "")
        val out = AgentTools.execute(context, project, call)
        results.append("[").append(call.name).append(" ").append(call.arg.trim()).append("]\n").append(out.take(2500)).append("\n\n")
        if (results.length > 5000) results.delete(0, results.length - 5000)
      }
      if (role.canWrite) {
        val errors = HeadlessCheck.run(context, project.rootDir)
        addNote(if (errors.isEmpty()) "Tested the app: no errors." else "Still ${errors.size} problem(s): " + errors.take(2).joinToString(" | "))
      }
    } finally {
      _isGenerating.value = false
    }
  }

  /** Extracts file blocks from the reply and applies them (new files directly, overwrites after approval). */
  private fun finishMessage(id: String, text: String, project: Project?, settings: SettingsState) {
    val changes = if (project == null) emptyList() else FileBlocks.parse(text).map { p ->
      val target = ProjectFiles.resolve(project.rootDir, p.path)
      FileChange(path = p.path, content = p.content, isNew = target == null || !target.exists())
    }
    val autoApply = project != null && changes.isNotEmpty() &&
      (changes.all { it.isNew } || !settings.requireApprovalForDestructive)
    if (autoApply) Snapshots.take(project!!.rootDir)?.let { snapIds[id] = it }
    val finalChanges = if (autoApply) writeChanges(project!!, changes) else changes
    if (autoApply) PreviewFixer.prepare(project!!.rootDir)
    _messages.value = _messages.value.map { m ->
      if (m.id == id) m.copy(content = text, isStreaming = false, fileChanges = finalChanges) else m
    }
  }

  private fun writeChanges(project: Project, changes: List<FileChange>): List<FileChange> =
    changes.map { c ->
      if (c.status != ChangeStatus.PENDING) c
      else ProjectFiles.write(project.rootDir, c).fold(
        onSuccess = { c.copy(status = ChangeStatus.APPLIED) },
        onFailure = { e -> c.copy(status = ChangeStatus.FAILED, error = e.message) }
      )
    }

  fun applyChanges(messageId: String, project: Project, scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      Snapshots.take(project.rootDir)?.let { snapIds[messageId] = it }
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
      }
      PreviewFixer.prepare(project.rootDir)
    }
  }

  fun discardChanges(messageId: String) {
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) {
        m.copy(fileChanges = m.fileChanges.map { c ->
          if (c.status == ChangeStatus.PENDING) c.copy(status = ChangeStatus.DISCARDED) else c
        })
      } else m
    }
  }

  private suspend fun runBuildWorkflow(project: Project) {
    val buildMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = buildMsgId,
      sender = MessageSender.TOOL,
      content = "Executing Gradle build verification for '${project.name}'...",
      toolCall = ToolCallInfo("project_build", mapOf("project" to project.name), "running")
    )

    val toolResult = toolExecutor.executeTool("project_build", emptyMap(), project)
    val updatedToolCall = ToolCallInfo(
      toolName = "project_build",
      arguments = mapOf("project" to project.name),
      status = if (toolResult.success) "success" else "error",
      resultSummary = if (toolResult.success) "Build Successful" else "Build Failed"
    )

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = if (toolResult.success) {
        "Build succeeded!\n${toolResult.output}"
      } else {
        "Build failed. Found errors:\n${toolResult.error}\n\nSay 'repair' to run the 10-step Self-Repair Engine."
      },
      toolCall = updatedToolCall
    )
  }

  private suspend fun runSelfRepairWorkflow(project: Project, settings: SettingsState) {
    val buildRes = selfRepairEngine.rebuildAndVerify(project)

    if (buildRes.errors.isEmpty()) {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: No errors found in workspace. All source files compiled cleanly!"
      )
      return
    }

    val activeError = buildRes.errors.first()
    val patch = selfRepairEngine.generateTargetedPatch(activeError, project)

    if (patch != null) {
      _pendingPatch.value = patch
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Diagnosed error in ${patch.relativePath} at line ${patch.startLine}:\n" +
            "Error: ${activeError.errorMessage}\n" +
            "Rationale: ${patch.rationale}\n\n" +
            "I have prepared a targeted surgical patch. Please review the diff below and approve to apply:",
        patchProposal = patch
      )
    } else {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: Detected error '${activeError.errorMessage}', but unable to generate safe surgical patch automatically."
      )
    }
  }

  fun approveAndApplyPatch(proposal: PatchProposal, project: Project, scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      val success = selfRepairEngine.applyPatch(proposal, project)
      _pendingPatch.value = null

      if (success) {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Patch successfully applied to ${proposal.relativePath}. Rebuilding to verify..."
        )
        // Verify rebuild
        val verifyBuild = selfRepairEngine.rebuildAndVerify(project)
        if (verifyBuild.errors.isEmpty()) {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification PASSED: Project built cleanly without errors!"
          )
        } else {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification FAILED: ${verifyBuild.errors.size} remaining error(s). Unresolved: ${verifyBuild.errors.first().errorMessage}"
          )
        }
      } else {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Failed to apply patch to ${proposal.relativePath}."
        )
      }
    }
  }

  fun rejectPatch(proposal: PatchProposal) {
    _pendingPatch.value = null
    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = "Patch proposal for ${proposal.relativePath} was declined by user."
    )
  }

  private fun updateMessageContent(id: String, newContent: String, isStreaming: Boolean) {
    _messages.value = _messages.value.map { msg ->
      if (msg.id == id) msg.copy(content = newContent, isStreaming = isStreaming) else msg
    }
  }

  companion object {
    private const val PLAN_PROMPT =
      "You plan small web apps (index.html, styles.css, app.js) for a phone. " +
        "Break the user's request into 2 to 4 short build steps. " +
        "Output only a numbered list, one short line per step, no code, no extra text."
  }
}
