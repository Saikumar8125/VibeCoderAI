package com.example.agent

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Opens index.html in an invisible WebView and reports JavaScript errors and missing files, so the agent can verify its own work. */
object HeadlessCheck {
  @SuppressLint("SetJavaScriptEnabled")
  suspend fun run(context: Context, root: File): List<String> {
    val index = File(root, "index.html")
    if (!index.isFile) return listOf("index.html is missing. Create index.html, styles.css and app.js.")
    PreviewFixer.prepare(root)
    return withContext(Dispatchers.Main) {
      val errors = mutableListOf<String>()
      val loaded = CompletableDeferred<Unit>()
      val wv = WebView(context.applicationContext)
      try {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = true
        wv.webChromeClient = object : WebChromeClient() {
          override fun onConsoleMessage(m: ConsoleMessage): Boolean {
            if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) errors.add("${m.message()} (line ${m.lineNumber()})")
            return true
          }
        }
        wv.webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            if (!loaded.isCompleted) loaded.complete(Unit)
          }

          override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            errors.add("Missing or unreadable file: ${request?.url?.lastPathSegment ?: "?"}")
          }
        }
        wv.loadUrl("file://" + index.absolutePath)
        withTimeoutOrNull(8000) { loaded.await() }
        delay(1500) // let timers and startup scripts run
      } finally {
        wv.destroy()
      }
      errors.distinct()
    }
  }
}
