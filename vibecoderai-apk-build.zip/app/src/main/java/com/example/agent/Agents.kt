package com.example.agent

import android.content.Context
import com.example.data.model.Project
import java.io.File

/** A specialist agent: its own instructions, and whether it may change files. */
data class AgentRole(val id: String, val name: String, val blurb: String, val system: String, val canWrite: Boolean)

object AgentRoles {
  private const val TOOLS =
    "Tools (use exactly one per reply, then stop and wait for the result):\n" +
      "<tool name=\"list_files\"></tool>\n" +
      "<tool name=\"read_file\">app.js</tool>\n" +
      "<tool name=\"search\">some text</tool>\n"

  val BUILDER = AgentRole(
    "builder", "Builder", "Plans, builds and tests apps by itself.", "", true
  )
  val DEBUGGER = AgentRole(
    "debugger", "Debugger", "Runs the app, finds the error, fixes it.",
    "You are the Debugger agent for a small offline web app (index.html, styles.css, app.js). You find and fix bugs.\n" +
      TOOLS + "<tool name=\"run_check\"></tool> runs the app and returns its JavaScript errors.\n" +
      "Workflow: run_check first, read the broken file, then give the fix as complete files in " +
      "<file path=\"x\">...</file> blocks. The final answer contains only those blocks.",
    true
  )
  val REVIEWER = AgentRole(
    "reviewer", "Reviewer", "Reads your code and lists problems. Changes nothing.",
    "You are the Reviewer agent for a small offline web app. You read the code and report problems; you never change files.\n" +
      TOOLS + "Read the files, then answer in plain text with at most 6 short bullet points: file, problem, fix. " +
      "No code blocks and no <file> blocks.",
    false
  )
  val DESIGNER = AgentRole(
    "designer", "Designer", "Makes the UI look polished, keeps features.",
    "You are the Designer agent for a small offline web app. You improve the visual design: spacing, typography, colours, rounded cards, " +
      "smooth animations, mobile layout. Keep all features, element ids and JavaScript behaviour unchanged.\n" +
      TOOLS + "Read the files first, then give the final answer as complete files in <file path=\"x\">...</file> blocks.",
    true
  )

  val all = listOf(BUILDER, DEBUGGER, REVIEWER, DESIGNER)
  fun from(id: String): AgentRole = all.firstOrNull { it.id == id } ?: BUILDER
}

data class ToolCall(val name: String, val arg: String)

object ToolCalls {
  private val CLOSED = Regex("""<tool\s+name\s*=\s*["']?(\w+)["']?\s*(?:/>|>(.*?)</tool>)""", RegexOption.DOT_MATCHES_ALL)
  private val OPEN_TAIL = Regex("""<tool\b.*\z""", RegexOption.DOT_MATCHES_ALL)

  fun parse(text: String): ToolCall? =
    CLOSED.find(text)?.let { ToolCall(it.groupValues[1].lowercase(), it.groupValues[2].trim()) }

  /** Removes tool tags from text shown in the chat. */
  fun strip(text: String): String = OPEN_TAIL.replace(CLOSED.replace(text, ""), "")
}

/** The actions an agent can take on the project. */
object AgentTools {
  suspend fun execute(context: Context, project: Project, call: ToolCall): String {
    val root = project.rootDir
    return when (call.name) {
      "list_files" -> {
        val files = root.walkTopDown()
          .onEnter { it == root || !it.name.startsWith(".") }
          .filter { it.isFile && !it.name.startsWith(".") }
          .map { it.relativeTo(root).path + " (" + it.length() + " bytes)" }
          .take(60).toList()
        if (files.isEmpty()) "The project has no files yet." else files.joinToString("\n")
      }
      "read_file" -> {
        val f = ProjectFiles.resolve(root, call.arg)
        if (f == null || !f.isFile) "File not found: ${call.arg}. Use list_files."
        else f.readText().take(5000)
      }
      "search" -> {
        val q = call.arg.lowercase()
        if (q.isBlank()) "Give some text to search for." else {
          val hits = mutableListOf<String>()
          root.walkTopDown().onEnter { it == root || !it.name.startsWith(".") }
            .filter { it.isFile && it.length() < 200_000 && it.extension.lowercase() in setOf("html", "css", "js", "json", "md", "txt") }
            .forEach { f ->
              f.readLines().forEachIndexed { i, line ->
                if (hits.size < 15 && line.lowercase().contains(q)) hits.add("${f.relativeTo(root).path}:${i + 1}: ${line.trim().take(120)}")
              }
            }
          if (hits.isEmpty()) "No matches." else hits.joinToString("\n")
        }
      }
      "run_check" -> {
        val errors = HeadlessCheck.run(context, root)
        if (errors.isEmpty()) "The app loaded with no errors." else errors.take(6).joinToString("\n")
      }
      else -> "Unknown tool '${call.name}'. Available: list_files, read_file, search, run_check."
    }
  }
}
