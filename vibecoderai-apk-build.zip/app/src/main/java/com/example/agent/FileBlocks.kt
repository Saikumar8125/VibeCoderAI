package com.example.agent

/**
 * The model returns files as <file path="index.html">...</file> blocks.
 * This parses them and produces chat-friendly text with the bodies removed.
 */
object FileBlocks {
  data class Parsed(val path: String, val content: String)

  private val CLOSED = Regex("""<file\s+(?:path|name)\s*=\s*["']?([^"'<>\s]+)["']?\s*>\r?\n?(.*?)</file>""", RegexOption.DOT_MATCHES_ALL)
  private val OPEN_TAIL = Regex("""<file\s+(?:path|name)\s*=\s*["']?[^"'<>\s]*["']?\s*>.*\z""", RegexOption.DOT_MATCHES_ALL)
  private val PARTIAL_TAG = Regex("""<f(i(l(e[^>]*)?)?)?\z""")
  private val FENCED_CSS = Regex("```css\\s*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)
  private val FENCED_JS = Regex("```(?:js|javascript)\\s*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)
  private val FENCED_HTML = Regex("""```html\s*\n(.*?)```""", RegexOption.DOT_MATCHES_ALL)

  fun parse(text: String): List<Parsed> {
    val found = CLOSED.findAll(text)
      .map { Parsed(it.groupValues[1].trim(), clean(it.groupValues[2])) }
      .toList()
    if (found.isNotEmpty()) return found

    // Fallback for replies without <file> tags: fenced html / css / js blocks become the project files.
    val out = mutableListOf<Parsed>()
    FENCED_HTML.findAll(text).map { it.groupValues[1] }.firstOrNull {
      it.contains("<html", ignoreCase = true) || it.contains("<!doctype", ignoreCase = true) || it.contains("<body", ignoreCase = true)
    }?.let { out += Parsed("index.html", clean(it)) }
    FENCED_CSS.find(text)?.let { out += Parsed("styles.css", clean(it.groupValues[1])) }
    FENCED_JS.find(text)?.let { out += Parsed("app.js", clean(it.groupValues[1])) }
    return out
  }

  /** Text for display: file bodies replaced by [[file:path]] markers; an unfinished block shows as [[file:...]]. */
  fun displayText(text: String): String {
    var out = CLOSED.replace(text) { "\n[[file:${it.groupValues[1].trim()}]]\n" }
    out = OPEN_TAIL.replace(out, "\n[[file:...]]\n")
    out = PARTIAL_TAG.replace(out, "")
    return out.trim()
  }

  private fun clean(raw: String): String {
    var s = raw.trimEnd()
    val lines = s.lines()
    if (lines.size >= 2 && lines.first().trimStart().startsWith("```") && lines.last().trim() == "```") {
      s = lines.drop(1).dropLast(1).joinToString("\n")
    }
    return s.trimEnd('\n', '\r') + "\n"
  }
}
