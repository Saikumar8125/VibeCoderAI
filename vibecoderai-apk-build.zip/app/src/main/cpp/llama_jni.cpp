#include <cstring>
// Real llama.cpp JNI bridge for VibeCoderAI (fully offline; CPU inference, optional Vulkan offload).
// v1.4: the llama context is kept between turns and the KV cache is reused for the common prompt prefix
// (llama_memory_seq_rm), exact token counting, GPU layer count from Kotlin, llama_supports_gpu_offload.
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <exception>
#include <mutex>
#include <new>
#include <string>
#include <vector>

#include "llama.h"

#define TAG "VibeCoderLlamaJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::mutex g_dbg_lock;
std::string g_dbg;
const auto g_t0 = std::chrono::steady_clock::now();

// Timeline of what the native side is doing, readable from Kotlin without taking the engine lock.
void dbg(const char *fmt, ...) {
    char buf[480];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - g_t0).count();
    char line[520];
    std::snprintf(line, sizeof(line), "[%lld.%03lld] %s\n", ms / 1000, ms % 1000, buf);
    {
        std::lock_guard<std::mutex> g(g_dbg_lock);
        g_dbg += line;
        if (g_dbg.size() > 3500) g_dbg.erase(0, g_dbg.size() - 3500);
    }
    LOGI("%s", buf);
}

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 0;
    // v1.4: tokens currently held in KV cache sequence 0 (prompt + decoded output), in order.
    std::vector<llama_token> cache_tokens;
    std::atomic<int> last_cached{0};
    std::atomic<bool> stop{false};
    std::mutex lock;  // serialises generate / free
};

std::once_flag g_backend_once;
std::mutex g_error_lock;
std::string g_last_error;

void set_error(const std::string &msg) {
    std::lock_guard<std::mutex> g(g_error_lock);
    g_last_error = msg;
    LOGE("%s", msg.c_str());
}

std::string jstr(JNIEnv *env, jstring s) {
    if (s == nullptr) return {};
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

// Returns how many leading bytes of `s` form complete UTF-8 sequences.
size_t utf8_complete_prefix(const std::string &s) {
    size_t n = s.size();
    if (n == 0) return 0;
    // Look back at most 3 bytes for an incomplete multi-byte sequence start.
    for (size_t back = 1; back <= std::min<size_t>(3, n); ++back) {
        unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue;  // continuation byte, keep looking
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        return (need > back) ? n - back : n;
    }
    return n;
}

jbyteArray to_jbytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr != nullptr && !s.empty()) {
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()),
                                reinterpret_cast<const jbyte *>(s.data()));
    }
    return arr;
}

Engine *as_engine(jlong h) { return reinterpret_cast<Engine *>(h); }

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_llama_LlamaBridge_nativeLoad(JNIEnv *env, jobject, jstring model_path,
                                              jint n_threads, jint n_ctx, jint n_gpu_layers) {
    std::call_once(g_backend_once, []() { llama_backend_init(); });

    std::string path = jstr(env, model_path);
    const bool gpu = n_gpu_layers > 0 && llama_supports_gpu_offload();
    LOGI("Loading model: %s (threads=%d ctx=%d gpu_layers=%d)", path.c_str(), n_threads, n_ctx, gpu ? n_gpu_layers : 0);

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = gpu ? static_cast<int32_t>(n_gpu_layers) : 0;

    llama_model *model = nullptr;
    try {
        model = llama_model_load_from_file(path.c_str(), mparams);
    } catch (const std::bad_alloc &) {
        set_error("Out of memory while loading the model.");
        return 0;
    } catch (const std::exception &ex) {
        set_error(std::string("Model load failed: ") + ex.what());
        return 0;
    }
    if (model == nullptr) {
        set_error("Failed to load GGUF model (file corrupt, unsupported architecture, or out of memory).");
        return 0;
    }

    dbg("model weights mapped");
    int ctx_len = n_ctx > 0 ? n_ctx : 2048;
    int threads = n_threads > 0 ? n_threads : 4;

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(ctx_len);
    cparams.n_batch = static_cast<uint32_t>(std::min(512, ctx_len));
    cparams.n_ubatch = cparams.n_batch;
    cparams.n_threads = threads;
    cparams.n_threads_batch = threads;

    llama_context *ctx = nullptr;
    try {
        ctx = llama_init_from_model(model, cparams);
    } catch (const std::bad_alloc &) {
        ctx = nullptr;
    } catch (const std::exception &) {
        ctx = nullptr;
    }
    if (ctx == nullptr) {
        llama_model_free(model);
        set_error("Failed to create llama context (try a smaller context length; likely out of memory).");
        return 0;
    }

    auto *e = new Engine();
    e->model = model;
    e->ctx = ctx;
    e->vocab = llama_model_get_vocab(model);
    e->n_ctx = static_cast<int>(llama_n_ctx(ctx));
    e->n_batch = static_cast<int>(cparams.n_batch);
    dbg("context ready: n_ctx=%d n_batch=%d threads=%d gpu_layers=%d", e->n_ctx, e->n_batch, threads, mparams.n_gpu_layers);
    dbg("cpu: %s", llama_print_system_info());
    // Lets Stop interrupt a long llama_decode (prompt processing) instead of waiting for it to finish.
    llama_set_abort_callback(ctx, [](void *data) -> bool {
        return static_cast<Engine *>(data)->stop.load();
    }, e);
    return reinterpret_cast<jlong>(e);
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeFree(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return;
    e->stop = true;
    std::lock_guard<std::mutex> g(e->lock);  // wait for any running generation
    llama_free(e->ctx);
    llama_model_free(e->model);
    delete e;
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeStop(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e != nullptr) e->stop = true;
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeLastError(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> g(g_error_lock);
    return env->NewStringUTF(g_last_error.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeDebug(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> g(g_dbg_lock);
    return env->NewStringUTF(g_dbg.c_str());
}

// Decodes a short fixed prompt and reports CPU features and speed (for diagnosing slow devices).
JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeBench(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewStringUTF("No model loaded.");
    std::lock_guard<std::mutex> guard(e->lock);
    e->stop = false;
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cache_tokens.clear();
    const std::string text = "The quick brown fox jumps over the lazy dog. Write a function that adds two numbers.";
    std::vector<llama_token> tokens(64);
    int n = llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(),
                           static_cast<int32_t>(tokens.size()), false, true);
    if (n <= 0) return env->NewStringUTF("Tokenization failed.");
    if (n > 16) n = 16;
    auto t0 = std::chrono::steady_clock::now();
    int rc = llama_decode(e->ctx, llama_batch_get_one(tokens.data(), n));
    long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
    llama_memory_clear(llama_get_memory(e->ctx), true);
    char out[1536];
    std::snprintf(out, sizeof(out), "%d tokens decoded in %lld ms (rc=%d) = %.1f tok/s\nCPU: %s",
                  n, ms, rc, ms > 0 ? n * 1000.0 / static_cast<double>(ms) : 0.0, llama_print_system_info());
    return env->NewStringUTF(out);
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeSetThreads(JNIEnv *, jobject, jlong handle, jint threads) {
    Engine *e = as_engine(handle);
    if (e == nullptr || threads <= 0) return;
    llama_set_n_threads(e->ctx, threads, threads);
}

// v1.4: true when this build has a GPU backend (Vulkan) with at least one usable device.
JNIEXPORT jboolean JNICALL
Java_com_example_llama_LlamaBridge_nativeHasGpu(JNIEnv *, jobject) {
    std::call_once(g_backend_once, []() { llama_backend_init(); });
    return llama_supports_gpu_offload() ? JNI_TRUE : JNI_FALSE;
}

// v1.4: exact prompt token count (same tokenizer flags as generation). -1 on failure.
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeCountTokens(JNIEnv *env, jobject, jlong handle, jstring text) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return -1;
    std::string s = jstr(env, text);
    if (s.empty()) return 0;
    int n = llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), nullptr, 0, false, true);
    // With a null buffer llama_tokenize returns minus the number of tokens it needs.
    return n <= 0 ? static_cast<jint>(-n) : static_cast<jint>(n);
}

// v1.4: prompt tokens reused from the KV cache by the last generation.
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeCachedTokens(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    return e == nullptr ? 0 : static_cast<jint>(e->last_cached.load());
}

// v1.4: drops the KV cache (next generation re-reads the whole prompt).
JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeResetCache(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return;
    e->stop = true;
    std::lock_guard<std::mutex> g(e->lock);
    e->stop = false;
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cache_tokens.clear();
    e->last_cached = 0;
}

JNIEXPORT jintArray JNICALL
Java_com_example_llama_LlamaBridge_nativeTokenize(JNIEnv *env, jobject, jlong handle, jstring text) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewIntArray(0);
    std::string s = jstr(env, text);
    int n = -llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), nullptr, 0, false, true);
    if (n <= 0) return env->NewIntArray(0);
    std::vector<llama_token> toks(static_cast<size_t>(n));
    int got = llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), toks.data(), n, false, true);
    if (got < 0) return env->NewIntArray(0);
    jintArray out = env->NewIntArray(got);
    env->SetIntArrayRegion(out, 0, got, reinterpret_cast<const jint *>(toks.data()));
    return out;
}

// Applies the model's own chat template. Returns null if it cannot be applied.
JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeApplyChatTemplate(JNIEnv *env, jobject, jlong handle,
                                                           jobjectArray roles, jobjectArray contents) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return nullptr;

    jsize n = env->GetArrayLength(roles);
    std::vector<std::string> role_s, content_s;
    for (jsize i = 0; i < n; ++i) {
        auto r = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto c = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        role_s.push_back(jstr(env, r));
        content_s.push_back(jstr(env, c));
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
    }
    std::vector<llama_chat_message> msgs(static_cast<size_t>(n));
    size_t total = 0;
    for (jsize i = 0; i < n; ++i) {
        msgs[i].role = role_s[i].c_str();
        msgs[i].content = content_s[i].c_str();
        total += content_s[i].size() + role_s[i].size();
    }

    const char *tmpl = llama_model_chat_template(e->model, nullptr);
    if (tmpl == nullptr) tmpl = "chatml";

    // Gemma 4 (<|turn>role ... <turn|>) is not in llama.cpp's built-in list; format it by hand
    // so it is not wrongly sent as ChatML (which makes the model echo <|im_end|> and never stop).
    if (std::strstr(tmpl, "<|turn>") != nullptr) {
        std::string g;
        for (jsize i = 0; i < n; ++i) {
            std::string role = role_s[i] == "assistant" ? "model" : role_s[i];
            g += "<|turn>" + role + "\n" + content_s[i] + "<turn|>\n";
        }
        g += "<|turn>model\n";
        return env->NewStringUTF(g.c_str());
    }

    std::vector<char> buf(total * 2 + 1024);
    int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                            static_cast<int32_t>(buf.size()));
    if (len > static_cast<int32_t>(buf.size())) {
        buf.resize(static_cast<size_t>(len) + 1);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                        static_cast<int32_t>(buf.size()));
    }
    if (len < 0) {
        // Template not in llama.cpp's built-in list: fall back to ChatML.
        len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(),
                                        static_cast<int32_t>(buf.size()));
        if (len > static_cast<int32_t>(buf.size())) {
            buf.resize(static_cast<size_t>(len) + 1);
            len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(),
                                            static_cast<int32_t>(buf.size()));
        }
    }
    if (len < 0) return nullptr;
    std::string out(buf.data(), static_cast<size_t>(len));
    return env->NewStringUTF(out.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeInfo(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewStringUTF("{}");
    char desc[256] = {0};
    llama_model_desc(e->model, desc, sizeof(desc));
    char out[640];
    std::snprintf(out, sizeof(out),
                  "{\"desc\":\"%s\",\"sizeBytes\":%llu,\"params\":%llu,\"nCtx\":%d,\"nCtxTrain\":%d,\"nVocab\":%d}",
                  desc, static_cast<unsigned long long>(llama_model_size(e->model)),
                  static_cast<unsigned long long>(llama_model_n_params(e->model)), e->n_ctx,
                  llama_model_n_ctx_train(e->model), llama_vocab_n_tokens(e->vocab));
    return env->NewStringUTF(out);
}

// Streams generated text to callback.onPiece(byte[]): boolean (false = stop).
// Returns number of generated tokens, or -1 on error (see nativeLastError).
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeGenerate(JNIEnv *env, jobject, jlong handle, jstring prompt,
                                                  jint max_tokens, jfloat temp, jfloat top_p,
                                                  jint top_k, jfloat repeat_penalty,
                                                  jobject callback) {
    Engine *e = as_engine(handle);
    if (e == nullptr) {
        set_error("No model loaded.");
        return -1;
    }
    std::lock_guard<std::mutex> guard(e->lock);
    e->stop = false;

    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID on_piece = env->GetMethodID(cb_cls, "onPiece", "([B)Z");
    jmethodID on_progress = env->GetMethodID(cb_cls, "onProgress", "(II)Z");
    if (on_piece == nullptr || on_progress == nullptr) {
        env->ExceptionClear();
        set_error("Callback is missing onPiece/onProgress");
        return -1;
    }

    std::string text = jstr(env, prompt);
    llama_memory_t mem = llama_get_memory(e->ctx);

    int n_tok = -llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), nullptr, 0, false, true);
    if (n_tok <= 0) {
        set_error("Prompt tokenization failed.");
        return -1;
    }
    std::vector<llama_token> tokens(static_cast<size_t>(n_tok));
    if (llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(), n_tok, false, true) < 0) {
        set_error("Prompt tokenization failed.");
        return -1;
    }

    // Keep the newest tokens if the prompt does not fit; reserve room to answer.
    int reserve = std::max(32, std::min(static_cast<int>(max_tokens), e->n_ctx / 2));
    int max_prompt = e->n_ctx - reserve;
    if (max_prompt < 8) max_prompt = std::max(1, e->n_ctx - 8);
    if (static_cast<int>(tokens.size()) > max_prompt) {
        LOGI("Prompt truncated from %zu to %d tokens", tokens.size(), max_prompt);
        tokens.erase(tokens.begin(), tokens.end() - max_prompt);
    }

    // v1.4 prompt cache: keep the KV entries of the longest common prefix with the previous turn and
    // decode only the new tail. If the cache bookkeeping and the memory disagree (an aborted decode), or a
    // partial removal is not supported (recurrent / SWA memory), fall back to a clean cache.
    {
        const llama_pos pos_max = llama_memory_seq_pos_max(mem, 0);
        if (static_cast<long>(pos_max) + 1 != static_cast<long>(e->cache_tokens.size())) {
            llama_memory_clear(mem, true);
            e->cache_tokens.clear();
        }
    }
    size_t n_keep = 0;
    while (n_keep < e->cache_tokens.size() && n_keep < tokens.size() && e->cache_tokens[n_keep] == tokens[n_keep]) ++n_keep;
    // Always decode at least one prompt token so the sampler has fresh logits.
    if (n_keep >= tokens.size()) n_keep = tokens.size() - 1;
    if (n_keep < e->cache_tokens.size()) {
        if (!llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(n_keep), -1)) {
            llama_memory_clear(mem, true);
            n_keep = 0;
            e->cache_tokens.clear();
        } else {
            e->cache_tokens.resize(n_keep);
        }
    }
    e->last_cached = static_cast<int>(n_keep);

    dbg("generate: prompt=%zu tokens, cached=%zu", tokens.size(), n_keep);

    // Sampler chain.
    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    llama_sampler *smpl = llama_sampler_chain_init(sparams);
    if (repeat_penalty > 1.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(e->vocab), 256, repeat_penalty, 0.0f, 0.1f));
    }
    if (temp <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        if (top_k > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    int generated = 0;
    int result = 0;
    int n_past = static_cast<int>(n_keep);

    // Decode the new part of the prompt in batches.
    size_t pos = n_keep;
    while (pos < tokens.size()) {
        if (e->stop) goto done;
        int chunk = static_cast<int>(std::min<size_t>(static_cast<size_t>(std::min(e->n_batch, 32)), tokens.size() - pos));
        llama_batch batch = llama_batch_get_one(tokens.data() + pos, chunk);
        dbg("decode start pos=%zu chunk=%d", pos, chunk);
        if (llama_decode(e->ctx, batch) != 0) {
            if (e->stop) goto done;
            set_error("llama_decode failed while processing the prompt.");
            result = -1;
            goto done;
        }
        e->cache_tokens.insert(e->cache_tokens.end(), tokens.begin() + static_cast<long>(pos), tokens.begin() + static_cast<long>(pos) + chunk);
        pos += static_cast<size_t>(chunk);
        n_past += chunk;
        dbg("decode done pos=%zu", pos);
        {
            jboolean go = env->CallBooleanMethod(callback, on_progress, static_cast<jint>(pos),
                                                 static_cast<jint>(tokens.size()));
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                goto done;
            }
            if (!go) goto done;
        }
    }

    {
        std::string pending;
        char piece[256];
        const int limit = std::min(static_cast<int>(max_tokens), e->n_ctx - n_past);
        bool keep_going = true;

        while (keep_going && generated < limit && !e->stop) {
            llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
            if (llama_vocab_is_eog(e->vocab, tok)) break;

            int plen = llama_token_to_piece(e->vocab, tok, piece, sizeof(piece), 0, false);
            if (plen > 0) pending.append(piece, static_cast<size_t>(plen));
            ++generated;

            size_t ready = utf8_complete_prefix(pending);
            if (ready > 0) {
                jbyteArray bytes = to_jbytes(env, pending.substr(0, ready));
                pending.erase(0, ready);
                jboolean cont = env->CallBooleanMethod(callback, on_piece, bytes);
                env->DeleteLocalRef(bytes);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    keep_going = false;
                } else if (!cont) {
                    keep_going = false;
                }
            }
            if (!keep_going) break;

            llama_batch next = llama_batch_get_one(&tok, 1);
            if (llama_decode(e->ctx, next) != 0) {
                if (e->stop) break;
                set_error("llama_decode failed during generation.");
                result = -1;
                break;
            }
            e->cache_tokens.push_back(tok);
            ++n_past;
        }
    }

done:
    llama_sampler_free(smpl);
    return result < 0 ? -1 : generated;
}

}  // extern "C"
